import mongoose from 'mongoose';
import logger from './logger.js';

class DatabaseManager {
  constructor() {
    this.isConnected = false;
    this.poolMetrics = {
      activeConnections: 0,
      totalConnections: 0,
      queueLength: 0,
    };
  }

  async connect(uri, options = {}) {
    try {
      // Enhanced connection options with pooling
      const mongoOptions = {
        // Connection pool — keep small for Atlas M0 (max 100 connections)
        minPoolSize: 1,
        maxPoolSize: 10,

        // Timeout settings
        serverSelectionTimeoutMS: 30000,
        socketTimeoutMS: 45000,
        connectTimeoutMS: 30000,
        waitQueueTimeoutMS: 30000,
        maxIdleTimeMS: 30000,

        // Keep connection alive
        heartbeatFrequencyMS: 10000,
        ...options,
      };

      // SSL certificate validation (environment-aware)
      if (uri && uri.includes('mongodb.net')) {
        if (process.env.NODE_ENV === 'production') {
          logger.info('✅ Production mode: SSL certificate validation enabled');
        } else {
          process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
          logger.warn('⚠️  Development mode: SSL certificate validation disabled');
        }
      }

      await mongoose.connect(uri, mongoOptions);
      this.isConnected = true;

      logger.info('✅ MongoDB Connected');
      logger.info(`📊 Connection Pool: Min=${mongoOptions.minPoolSize}, Max=${mongoOptions.maxPoolSize}`);

      // Migrate TTL index: ensure candles expire after 24h not 2h
      try {
        const candleCol = mongoose.connection.collection('candles');
        const indexes   = await candleCol.indexes();
        const oldTTL    = indexes.find(ix => ix.key?.openTime === 1 && ix.expireAfterSeconds === 7200);
        if (oldTTL) {
          await candleCol.dropIndex(oldTTL.name);
          await candleCol.createIndex({ openTime: 1 }, { expireAfterSeconds: 86400 });
          logger.info('✅ Candle TTL index migrated: 2h → 24h');
        }
      } catch (e) {
        logger.warn('⚠️ TTL index migration skipped:', e.message);
      }

      // Set up connection event listeners
      mongoose.connection.on('connected', () => {
        logger.info('Mongoose connected to MongoDB');
      });

      mongoose.connection.on('error', (err) => {
        logger.error('Mongoose connection error:', err);
      });

      mongoose.connection.on('disconnected', () => {
        logger.warn('Mongoose disconnected from MongoDB');
        this.isConnected = false;
        // Auto-reconnect after 3 seconds
        setTimeout(() => {
          if (!this.isConnected) {
            logger.info('🔄 Attempting reconnect...');
            mongoose.connect(uri, mongoOptions).catch(() => {});
          }
        }, 3000);
      });

      // Start logging pool metrics every 60 seconds
      this.startMetricsLogging();

      return true;
    } catch (error) {
      logger.error('❌ MongoDB Connection Error:', error);
      throw error;
    }
  }

  async disconnect() {
    try {
      await mongoose.disconnect();
      this.isConnected = false;
      logger.info('MongoDB disconnected');
      return true;
    } catch (error) {
      logger.error('MongoDB disconnect error:', error);
      throw error;
    }
  }

  getPoolMetrics() {
    if (!this.isConnected) {
      return {
        isConnected: false,
        activeConnections: 0,
        totalConnections: 0,
        queueLength: 0,
      };
    }

    // Get connection pool stats from mongoose
    const db = mongoose.connection.db;
    const client = mongoose.connection.getClient();

    return {
      isConnected: this.isConnected,
      readyState: mongoose.connection.readyState,
      activeConnections: client?.topology?.s?.pool?.totalConnectionCount || 0,
      availableConnections: client?.topology?.s?.pool?.availableConnectionCount || 0,
      pendingOperations: client?.topology?.s?.pool?.waitQueueSize || 0,
    };
  }

  startMetricsLogging() {
    // Log pool metrics every 60 seconds
    setInterval(() => {
      const metrics = this.getPoolMetrics();
      logger.info('📊 Connection Pool Metrics:', metrics);
    }, 60000);
  }

  logPoolStats() {
    const metrics = this.getPoolMetrics();
    logger.info('Connection Pool Statistics:', metrics);
  }
}

// Export singleton instance
export default new DatabaseManager();
