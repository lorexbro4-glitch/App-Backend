# Investment App Backend

## Overview
Node.js/Express REST API backend for an investment mobile application. Uses MongoDB Atlas for data persistence and JWT for authentication.

## Architecture
- **Runtime**: Node.js 20
- **Framework**: Express.js
- **Database**: MongoDB (via Mongoose) — requires `MONGODB_URI` secret
- **Auth**: JWT (jsonwebtoken) + bcryptjs — requires `JWT_SECRET` secret
- **Email**: Nodemailer
- **Scheduling**: node-cron (daily profit distribution at midnight Bangladesh time / 18:00 UTC)

## Project Structure
```
server.js           - Main Express server entry point
keep_alive.js       - UptimeRobot health check routes (/ping, /health)
routes/             - API route handlers
  auth.js           - Phone-based authentication
  authEmail.js      - Email-based authentication
  user.js           - User profile management
  deposit.js        - Deposit management
  withdraw.js       - Withdrawal management
  transactions.js   - Transaction history
  referral.js       - Referral system
  leaderboard.js    - Leaderboard
  verification.js   - KYC verification
  admin.js          - Admin panel routes
  notifications.js  - Push notifications
  support.js        - Support tickets
  agent.js          - Agent management
  settings.js       - App settings
  appDistribution.js - App distribution pages
models/             - Mongoose data models
middleware/         - Express middleware (auth, error handling, rate limiting)
services/           - Business logic (email, notifications, caching, pagination)
config/             - Database and logger config
constants/          - App constants
scripts/            - Utility scripts (createAdmin, etc.)
```

## API Port
- **Development & Production**: Port 5000

## Required Secrets
- `MONGODB_URI` — MongoDB Atlas connection string
- `JWT_SECRET` — Secret key for JWT token signing

## Environment Variables
- `PORT` — Server port (set to 5000)
- `NODE_ENV` — Set to "development" for dev mode

## Key Features
- Phone and email-based registration/login
- Daily profit distribution cron job (12% monthly rate)
- Referral system with 5% monthly bonus
- File uploads via Multer
- Rate limiting
- CORS configured for mobile app access
- Redis-optional caching (graceful fallback if Redis not available)

## Start Command
```sh
node server.js
```
