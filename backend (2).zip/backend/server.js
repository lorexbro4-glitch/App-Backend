﻿import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import cron from 'node-cron';
import dotenv from 'dotenv';
dotenv.config();

// Polyfill for File global (required for undici/node-fetch in Node.js < 20)
if (typeof global.File === 'undefined') {
  global.File = class File {
    constructor(parts, name, options) {
      this.parts = parts;
      this.name = name;
      this.options = options;
    }
  };
}

import databaseManager from './config/database.js';
import logger from './config/logger.js';
import { errorHandler, notFound } from './middleware/errorHandler.js';

const app = express();

// CORS Configuration
// For development: Allow all origins (mobile apps need this)
// For production: Restrict to specific domains
const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);
    
    // In production, check against whitelist
    if (process.env.NODE_ENV === 'production') {
      const allowedOrigins = [
        process.env.FRONTEND_URL,
        'http://localhost:5173', // AdminPanel local
        'http://localhost:3000', // Development
        'http://192.168.1.101:5173', // Local network AdminPanel
      ].filter(Boolean); // Remove undefined values
      
      if (allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    } else {
      // Development: Allow all origins
      callback(null, true);
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' })); // Increase limit for image uploads
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve uploaded files statically
app.use('/uploads', express.static('uploads'));

// Serve app distribution pages (path is relative to backend/ folder, so go up one level)
app.use('/app-distribution', express.static('../app-distribution'));

// Request logging middleware (sanitized for production)
app.use((req, res, next) => {
  if (process.env.NODE_ENV === 'production') {
    // Production: Only log basic request info (no sensitive data)
    logger.info(`${req.method} ${req.url}`);
  } else {
    // Development: Log everything for debugging
    logger.info(`${req.method} ${req.url}`, {
      body: req.body,
      query: req.query,
    });
  }
  next();
});

// MongoDB Connection with enhanced pooling
databaseManager
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/investment_app')
  .then(() => {
    logger.info('✅ Database connection established');
    // Start trade price tick engine once DB is ready
    tradeRoutes.startTickEngine();
  })
  .catch(err => {
    logger.error('❌ Database connection failed:', err);
    process.exit(1);
  });

// Routes
const authRoutes = await import('./routes/auth.js');
const authEmailRoutes = await import('./routes/authEmail.js');
app.use('/api/auth', authRoutes.default);
app.use('/api/auth', authEmailRoutes.default); // Email authentication

// Test endpoint to verify server is reachable
app.get('/api/test', (req, res) => {
  logger.info('Test endpoint hit');
  res.json({ 
    message: 'Server is reachable!', 
    timestamp: new Date(),
    port: PORT 
  });
});

const userRoutes = await import('./routes/user.js');
const depositRoutes = await import('./routes/deposit.js');
const withdrawRoutes = await import('./routes/withdraw.js');
const transactionsRoutes = await import('./routes/transactions.js');
const referralRoutes = await import('./routes/referral.js');
const leaderboardRoutes = await import('./routes/leaderboard.js');
const verificationRoutes = await import('./routes/verification.js');
const adminRoutes = await import('./routes/admin.js');
const notificationsRoutes = await import('./routes/notifications.js');
const supportRoutes = await import('./routes/support.js');
const agentRoutes = await import('./routes/agent.js');
const settingsRoutes = await import('./routes/settings.js');
const appDistributionRoutes = await import('./routes/appDistribution.js');
const keepAliveRoutes = await import('./keep_alive.js');
const tradeRoutes = await import('./routes/trade.js');

app.use('/api/trade', tradeRoutes.default);

app.use('/api/user', userRoutes.default);
app.use('/api/deposit', depositRoutes.default);
app.use('/api/withdraw', withdrawRoutes.default);
app.use('/api/transactions', transactionsRoutes.default);
app.use('/api/referral', referralRoutes.default);
app.use('/api/leaderboard', leaderboardRoutes.default);
app.use('/api/verification', verificationRoutes.default);
app.use('/api/admin', adminRoutes.default);
app.use('/api/notifications', notificationsRoutes.default);
app.use('/api/support', supportRoutes.default);
app.use('/api/agent', agentRoutes.default);
app.use('/api/settings', settingsRoutes.default);
app.use('/api/app-distribution', appDistributionRoutes.default);

// Keep-alive routes for UptimeRobot
app.use('/', keepAliveRoutes.default);

app.use('/api/trade', tradeRoutes.default);

// Legacy health check
app.get('/health', (req, res) => {
  const poolMetrics = databaseManager.getPoolMetrics();
  res.json({
    status: 'healthy',
    timestamp: new Date(),
    database: poolMetrics,
  });
});

// Error handling middleware (must be after all routes)
app.use(notFound);
app.use(errorHandler);

// ─── Profit Distribution ────────────────────────────────────────────────────

// Helper: get today's date string in Bangladesh time (UTC+6) as 'YYYY-MM-DD'
function getBDDateString(date = new Date()) {
  const bd = new Date(date.getTime() + 6 * 60 * 60 * 1000);
  return bd.toISOString().slice(0, 10);
}

// Core profit distribution function — returns { success, usersProcessed, totalDistributed }
async function runProfitDistribution(multiplier = 1) {
  const User = (await import('./models/User.js')).default;
  const users = await User.find({
    $or: [{ capital: { $gt: 0 } }, { depositTotal: { $gt: 0 } }]
  });

  let usersProcessed = 0;
  let totalDistributed = 0;

  for (const user of users) {
    try {
      const userCapital = user.capital || user.depositTotal || 0;
      if (userCapital > 0) {
        const dailyProfit = Math.floor((userCapital * 0.16) / 30) * multiplier;
        user.balance = (user.balance || 0) + dailyProfit;
        user.totalProfit = (user.totalProfit || 0) + dailyProfit;
        user.profitTotal = (user.profitTotal || 0) + dailyProfit;
        await user.save();
        totalDistributed += dailyProfit;
        usersProcessed++;
      }

      // Referral bonus
      if (user.referredBy && (user.capital || user.depositTotal || 0) > 0) {
        if (mongoose.Types.ObjectId.isValid(user.referredBy)) {
          const referrer = await User.findById(user.referredBy);
          if (referrer) {
            const userCapital = user.capital || user.depositTotal || 0;
            const dailyReferralBonus = Math.floor((userCapital * 0.05) / 30) * multiplier;
            if (dailyReferralBonus > 0) {
              referrer.balance = (referrer.balance || 0) + dailyReferralBonus;
              referrer.referralIncome = (referrer.referralIncome || 0) + dailyReferralBonus; // referral page
              referrer.totalProfit = (referrer.totalProfit || 0) + dailyReferralBonus;       // balance card
              referrer.profitTotal = (referrer.profitTotal || 0) + dailyReferralBonus;       // legacy
              await referrer.save();
            }
          }
        }
      }
    } catch (err) {
      logger.error(`❌ Profit error for user ${user._id}:`, err);
    }
  }

  return { success: true, usersProcessed, totalDistributed };
}

// Scheduled profit with retry + missed-day catchup
// Runs every 10 minutes — handles scheduling, retries, and missed days
cron.schedule('*/10 * * * *', async () => {
  try {
    const Settings = (await import('./models/Settings.js')).default;
    const settings = await Settings.findOne() || new Settings();

    const todayBD = getBDDateString();
    const nowUTC = new Date();
    const bdHour = (nowUTC.getUTCHours() + 6) % 24; // current hour in BD time

    // Already distributed today — nothing to do
    if (settings.lastProfitDate === todayBD) return;

    // Only start trying after midnight BD time (hour >= 0, i.e. always true once day changes)
    // But respect: only run at/after 00:00 BD (18:00 UTC previous day)
    // We check: if bdHour is 0-23 and today hasn't been distributed yet → try
    logger.info(`⏰ Profit check: today=${todayBD}, last=${settings.lastProfitDate}, bdHour=${bdHour}`);

    // Check for missed days — if last distribution was more than 1 day ago, pay multiple days
    let multiplier = 1;
    if (settings.lastProfitDate) {
      const last = new Date(settings.lastProfitDate + 'T00:00:00+06:00');
      const today = new Date(todayBD + 'T00:00:00+06:00');
      const missedDays = Math.round((today - last) / (1000 * 60 * 60 * 24));
      if (missedDays > 1) {
        multiplier = missedDays;
        logger.info(`📅 Missed ${missedDays - 1} day(s) — distributing ${multiplier}x profit`);
      }
    }

    logger.info(`💰 Running profit distribution (${multiplier}x)...`);
    const result = await runProfitDistribution(multiplier);

    if (result.success) {
      settings.lastProfitDate = todayBD;
      settings.profitDistributionFailed = false;
      await settings.save();
      logger.info(`✅ Profit distributed: ${result.usersProcessed} users, ৳${result.totalDistributed} total (${multiplier}x)`);
    }
  } catch (error) {
    logger.error('❌ Profit distribution error (will retry in 10 min):', error);
    try {
      const Settings = (await import('./models/Settings.js')).default;
      await Settings.updateOne({}, { profitDistributionFailed: true }, { upsert: true });
    } catch (_) {}
  }
});

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`🚀 Server running on port ${PORT}`);
  logger.info(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});
