import express from 'express';
import auth from '../middleware/auth.js';
import Transaction from '../models/Transaction.js';
import Deposit from '../models/Deposit.js';
import Withdraw from '../models/Withdraw.js';
import excelExportService from '../services/excelExportService.js';

const router = express.Router();

// Get All Transactions (Consolidated View)
router.get('/', auth, async (req, res) => {
  try {
    const { type, limit = 50 } = req.query;

    let allTransactions = [];

    // Helper function to get status text in English
    const getStatusText = (status) => {
      switch (status) {
        case 'pending':
          return 'Pending';
        case 'approved':
          return 'Approved';
        case 'rejected':
          return 'Rejected';
        default:
          return status;
      }
    };

    // If filtering by deposit, only get deposits
    if (type === 'deposit') {
      const deposits = await Deposit.find({
        $or: [{ userId: req.userId }, { user: req.userId }]
      })
        .sort({ createdAt: -1 })
        .limit(parseInt(limit));

      allTransactions = deposits.map(d => ({
        _id: d._id,
        type: 'deposit',
        amount: d.amount,
        description: `${d.method} ডিপোজিট - ${d.transactionId}`,
        status: d.status,
        displayStatus: getStatusText(d.status),
        createdAt: d.createdAt,
        updatedAt: d.processedAt || d.updatedAt || d.createdAt,
      }));
    }
    // If filtering by withdrawal, only get withdrawals
    else if (type === 'withdrawal') {
      const withdrawals = await Withdraw.find({
        $or: [{ userId: req.userId }, { user: req.userId }]
      })
        .sort({ createdAt: -1 })
        .limit(parseInt(limit));

      allTransactions = withdrawals.map(w => ({
        _id: w._id,
        type: 'withdrawal',
        amount: w.amount,
        description: `${w.method} উইথড্র - ${w.type === 'profit' ? 'প্রফিট' : 'মূলধন'}`,
        status: w.status,
        displayStatus: getStatusText(w.status),
        createdAt: w.createdAt,
        updatedAt: w.processedAt || w.updatedAt || w.createdAt,
      }));
    }
    // If 'all' or no filter, get everything
    else {
      // Get deposits (consolidated - one record per deposit)
      const deposits = await Deposit.find({
        $or: [{ userId: req.userId }, { user: req.userId }]
      })
        .sort({ createdAt: -1 })
        .limit(parseInt(limit));

      // Get withdrawals (consolidated - one record per withdrawal)
      const withdrawals = await Withdraw.find({
        $or: [{ userId: req.userId }, { user: req.userId }]
      })
        .sort({ createdAt: -1 })
        .limit(parseInt(limit));

      // Combine and format all transactions (consolidated view)
      allTransactions = [
        ...deposits.map(d => ({
          _id: d._id,
          type: 'deposit',
          amount: d.amount,
          description: `${d.method} ডিপোজিট - ${d.transactionId}`,
          status: d.status,
          displayStatus: getStatusText(d.status),
          createdAt: d.createdAt,
          updatedAt: d.processedAt || d.updatedAt || d.createdAt,
        })),
        ...withdrawals.map(w => ({
          _id: w._id,
          type: 'withdrawal',
          amount: w.amount,
          description: `${w.method} উইথড্র - ${w.type === 'profit' ? 'প্রফিট' : 'মূলধন'}`,
          status: w.status,
          displayStatus: getStatusText(w.status),
          createdAt: w.createdAt,
          updatedAt: w.processedAt || w.updatedAt || w.createdAt,
        })),
      ];

      // Sort by date (newest first)
      allTransactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    // Apply limit
    const limitedTransactions = allTransactions.slice(0, parseInt(limit));

    res.json({ 
      transactions: limitedTransactions,
      total: allTransactions.length
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Transaction Statistics
router.get('/stats', auth, async (req, res) => {
  try {
    const deposits = await Deposit.find({
      $or: [{ userId: req.userId }, { user: req.userId }],
      status: 'approved'
    });

    const withdrawals = await Withdraw.find({
      $or: [{ userId: req.userId }, { user: req.userId }],
      status: 'approved'
    });

    const totalDeposits = deposits.reduce((sum, d) => sum + d.amount, 0);
    const totalWithdrawals = withdrawals.reduce((sum, w) => sum + w.amount, 0);

    const pendingDeposits = await Deposit.countDocuments({
      $or: [{ userId: req.userId }, { user: req.userId }],
      status: 'pending'
    });

    const pendingWithdrawals = await Withdraw.countDocuments({
      $or: [{ userId: req.userId }, { user: req.userId }],
      status: 'pending'
    });

    res.json({
      totalDeposits,
      totalWithdrawals,
      pendingDeposits,
      pendingWithdrawals,
      depositsCount: deposits.length,
      withdrawalsCount: withdrawals.length,
    });
  } catch (error) {
    console.error('Get transaction stats error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Export transactions to Excel
router.post('/export', auth, async (req, res) => {
  try {
    const { startDate, endDate, types, format = 'xlsx' } = req.body;

    // Validate format
    if (format !== 'xlsx') {
      return res.status(400).json({ 
        success: false,
        message: 'Only xlsx format is supported' 
      });
    }

    // Generate export
    const result = await excelExportService.generateTransactionExport(req.userId, {
      startDate,
      endDate,
      types
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Export transactions error:', error);
    res.status(500).json({ 
      success: false,
      message: 'সার্ভার ত্রুটি' 
    });
  }
});

// Download exported file
router.get('/download/:fileName', auth, async (req, res) => {
  try {
    const { fileName } = req.params;

    // Get file path
    const filePath = await excelExportService.getExportFile(fileName);

    // Send file
    res.download(filePath, fileName, (err) => {
      if (err) {
        console.error('Download error:', err);
        if (!res.headersSent) {
          res.status(404).json({ 
            success: false,
            message: 'File not found or expired' 
          });
        }
      }
    });
  } catch (error) {
    console.error('Download file error:', error);
    res.status(404).json({ 
      success: false,
      message: 'File not found or expired' 
    });
  }
});

export default router;
