import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production';

// Register
router.post('/register', async (req, res) => {
  try {
    const {phone, password, referredBy} = req.body;

    // Validate input
    if (!phone || !password) {
      return res.status(400).json({message: 'সব ফিল্ড পূরণ করুন'});
    }

    // Check if user exists
    const existingUser = await User.findOne({phone});
    if (existingUser) {
      return res.status(400).json({message: 'এই নম্বর ইতিমধ্যে নিবন্ধিত'});
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = new User({
      phone,
      password: hashedPassword,
      referredBy: referredBy || null,
    });

    await user.save();

    // Update referrer count
    if (referredBy) {
      await User.findByIdAndUpdate(referredBy, {
        $inc: {referralCount: 1},
      });
    }

    // Generate token
    const token = jwt.sign({userId: user._id}, JWT_SECRET, {expiresIn: '30d'});

    res.status(201).json({
      message: 'নিবন্ধন সফল',
      token,
      userId: user._id,
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({message: 'সার্ভার ত্রুটি'});
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const {phone, password} = req.body;

    // Validate input
    if (!phone || !password) {
      return res.status(400).json({message: 'সব ফিল্ড পূরণ করুন'});
    }

    // Find user
    const user = await User.findOne({phone});
    if (!user) {
      return res.status(400).json({message: 'ভুল ফোন নম্বর বা পাসওয়ার্ড'});
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({message: 'ভুল ফোন নম্বর বা পাসওয়ার্ড'});
    }

    // Check if banned
    if (user.banned) {
      return res.status(403).json({message: 'আপনার অ্যাকাউন্ট নিষিদ্ধ করা হয়েছে'});
    }

    // Generate token
    const token = jwt.sign({userId: user._id}, JWT_SECRET, {expiresIn: '30d'});

    res.json({
      message: 'লগইন সফল',
      token,
      userId: user._id,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({message: 'সার্ভার ত্রুটি'});
  }
});

// Verify Token
router.get('/verify', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({message: 'টোকেন নেই'});
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-password');

    if (!user) {
      return res.status(404).json({message: 'ব্যবহারকারী পাওয়া যায়নি'});
    }

    res.json({user});
  } catch (error) {
    res.status(401).json({message: 'অবৈধ টোকেন'});
  }
});

export default router;
