/**
 * Test Suite: Referral Relationship Creation
 * 
 * This test suite verifies that the backend properly creates referral relationships
 * when a new user registers with a valid referral code.
 * 
 * Requirements: 10.1
 */

import request from 'supertest';
import mongoose from 'mongoose';
import express from 'express';
import User from '../models/User.js';
import authEmailRouter from './authEmail.js';

// Create Express app for testing
const app = express();
app.use(express.json());
app.use('/auth', authEmailRouter);

describe('Referral Relationship Creation', () => {
  let referrerUser;
  let referrerUserId;
  let referralCode;

  beforeAll(async () => {
    // Connect to test database
    const mongoUri = process.env.MONGO_URI_TEST || 'mongodb://localhost:27017/investment-app-test';
    await mongoose.connect(mongoUri);
  });

  afterAll(async () => {
    // Clean up and close connection
    await mongoose.connection.close();
  });

  beforeEach(async () => {
    // Clear users collection
    await User.deleteMany({});

    // Create a referrer user
    referrerUser = new User({
      email: 'referrer@example.com',
      username: 'referrer123',
      password: '$2a$10$abcdefghijklmnopqrstuvwxyz', // Hashed password
      name: 'Referrer User',
      emailVerified: true,
      authProvider: 'email',
      referralCount: 0
    });
    await referrerUser.save();
    
    referrerUserId = referrerUser._id.toString();
    // Use first 8 characters of ObjectId as referral code
    referralCode = referrerUserId.substring(0, 8);

    console.log('Test setup complete:');
    console.log('  Referrer ID:', referrerUserId);
    console.log('  Referral Code:', referralCode);
  });

  afterEach(async () => {
    // Clean up after each test
    await User.deleteMany({});
  });

  describe('Valid Referral Code', () => {
    it('should create referral relationship when registering with valid 8-char referral code', async () => {
      // Register a new user with referral code
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: referralCode
        });

      // Should succeed
      expect(response.status).toBe(201);
      expect(response.body.message).toContain('Registration successful');

      // Find the newly created user
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee).toBeTruthy();

      // Verify referral relationship exists
      expect(referee.referredBy).toBeTruthy();
      expect(referee.referredBy.toString()).toBe(referrerUserId);

      // Verify referrer's count was incremented
      const updatedReferrer = await User.findById(referrerUserId);
      expect(updatedReferrer.referralCount).toBe(1);
    });

    it('should create referral relationship when registering with full 24-char ObjectId', async () => {
      // Register with full ObjectId
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee2@example.com',
          username: 'referee456',
          password: 'password123',
          name: 'Referee User 2',
          referredBy: referrerUserId
        });

      // Should succeed
      expect(response.status).toBe(201);

      // Find the newly created user
      const referee = await User.findOne({ email: 'referee2@example.com' });
      expect(referee).toBeTruthy();

      // Verify referral relationship exists
      expect(referee.referredBy).toBeTruthy();
      expect(referee.referredBy.toString()).toBe(referrerUserId);

      // Verify referrer's count was incremented
      const updatedReferrer = await User.findById(referrerUserId);
      expect(updatedReferrer.referralCount).toBe(1);
    });

    it('should store referredBy as ObjectId reference in database', async () => {
      // Register with referral code
      await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee3@example.com',
          username: 'referee789',
          password: 'password123',
          name: 'Referee User 3',
          referredBy: referralCode
        });

      // Get referee from database
      const referee = await User.findOne({ email: 'referee3@example.com' });

      // Verify referredBy is an ObjectId
      expect(referee.referredBy).toBeInstanceOf(mongoose.Types.ObjectId);

      // Verify we can populate the referrer
      const refereeWithReferrer = await User.findById(referee._id).populate('referredBy');
      expect(refereeWithReferrer.referredBy).toBeTruthy();
      expect(refereeWithReferrer.referredBy.email).toBe('referrer@example.com');
      expect(refereeWithReferrer.referredBy.username).toBe('referrer123');
    });
  });

  describe('Invalid Referral Code', () => {
    it('should reject registration with non-existent 8-char referral code', async () => {
      // Try to register with invalid referral code
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: 'invalid8'
        });

      // Should fail with 400
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid referral code');

      // User should not be created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee).toBeNull();
    });

    it('should reject registration with non-existent full ObjectId', async () => {
      // Create a valid-looking but non-existent ObjectId
      const fakeObjectId = new mongoose.Types.ObjectId().toString();

      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: fakeObjectId
        });

      // Should fail with 400
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid referral code');

      // User should not be created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee).toBeNull();
    });

    it('should reject registration with malformed referral code', async () => {
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: 'abc@123!'
        });

      // Should fail with 400
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid referral code format');

      // User should not be created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee).toBeNull();
    });

    it('should allow registration without referral code', async () => {
      // Register without referral code
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'noreferral@example.com',
          username: 'noreferral',
          password: 'password123',
          name: 'No Referral User'
        });

      // Should succeed
      expect(response.status).toBe(201);

      // Find the user
      const user = await User.findOne({ email: 'noreferral@example.com' });
      expect(user).toBeTruthy();

      // Verify no referral relationship
      expect(user.referredBy).toBeNull();

      // Verify referrer's count unchanged
      const updatedReferrer = await User.findById(referrerUserId);
      expect(updatedReferrer.referralCount).toBe(0);
    });
  });

  describe('Database Relationship Structure', () => {
    it('should maintain referral relationship after referee verifies email', async () => {
      // Register with referral code
      const registerResponse = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: referralCode
        });

      expect(registerResponse.status).toBe(201);

      // Get the OTP from the database (in real scenario, it would be sent via email)
      const referee = await User.findOne({ email: 'referee@example.com' });
      const otp = referee.emailVerificationToken;

      // Verify email
      const verifyResponse = await request(app)
        .post('/auth/email/verify-email')
        .send({
          email: 'referee@example.com',
          otp: otp
        });

      expect(verifyResponse.status).toBe(200);

      // Check that referral relationship still exists after verification
      const verifiedReferee = await User.findOne({ email: 'referee@example.com' });
      expect(verifiedReferee.referredBy).toBeTruthy();
      expect(verifiedReferee.referredBy.toString()).toBe(referrerUserId);
      expect(verifiedReferee.emailVerified).toBe(true);
    });

    it('should allow querying all referees of a referrer', async () => {
      // Create multiple referees
      const referees = [
        { email: 'referee1@example.com', username: 'referee001', name: 'Referee 1' },
        { email: 'referee2@example.com', username: 'referee002', name: 'Referee 2' },
        { email: 'referee3@example.com', username: 'referee003', name: 'Referee 3' }
      ];

      for (const referee of referees) {
        await request(app)
          .post('/auth/email/register')
          .send({
            ...referee,
            password: 'password123',
            referredBy: referralCode
          });
      }

      // Query all users referred by the referrer
      const referredUsers = await User.find({ referredBy: referrerUserId });

      expect(referredUsers).toHaveLength(3);
      expect(referredUsers.map(u => u.email)).toEqual(
        expect.arrayContaining([
          'referee1@example.com',
          'referee2@example.com',
          'referee3@example.com'
        ])
      );

      // Verify referrer's count
      const updatedReferrer = await User.findById(referrerUserId);
      expect(updatedReferrer.referralCount).toBe(3);
    });

    it('should handle case-insensitive referral codes', async () => {
      // Try with uppercase referral code
      const uppercaseCode = referralCode.toUpperCase();

      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: uppercaseCode
        });

      // Should succeed (case-insensitive matching)
      expect(response.status).toBe(201);

      // Verify relationship created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee.referredBy).toBeTruthy();
      expect(referee.referredBy.toString()).toBe(referrerUserId);
    });

    it('should handle mixed-case referral codes', async () => {
      // Try with mixed case
      const mixedCaseCode = referralCode.split('').map((char, i) => 
        i % 2 === 0 ? char.toUpperCase() : char.toLowerCase()
      ).join('');

      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: mixedCaseCode
        });

      // Should succeed
      expect(response.status).toBe(201);

      // Verify relationship created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee.referredBy).toBeTruthy();
      expect(referee.referredBy.toString()).toBe(referrerUserId);
    });
  });

  describe('Edge Cases', () => {
    it('should handle whitespace in referral code', async () => {
      // Try with whitespace
      const codeWithSpaces = `  ${referralCode}  `;

      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: codeWithSpaces
        });

      // Should succeed (trimmed)
      expect(response.status).toBe(201);

      // Verify relationship created
      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee.referredBy).toBeTruthy();
      expect(referee.referredBy.toString()).toBe(referrerUserId);
    });

    it('should not allow self-referral', async () => {
      // Try to register with own referral code (edge case)
      // First, create a user
      const response1 = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'user@example.com',
          username: 'user123',
          password: 'password123',
          name: 'User'
        });

      expect(response1.status).toBe(201);

      // Get the user's ID
      const user = await User.findOne({ email: 'user@example.com' });
      const userCode = user._id.toString().substring(0, 8);

      // Try to update with self-referral (this would need to be tested in a different endpoint)
      // For registration, this scenario doesn't apply since the user doesn't exist yet
      // But we can verify the logic doesn't break
      expect(user.referredBy).toBeNull();
    });

    it('should handle very long referral code input', async () => {
      const longCode = 'a'.repeat(100);

      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: longCode
        });

      // Should fail with invalid format
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Invalid referral code format');
    });

    it('should handle empty string referral code', async () => {
      const response = await request(app)
        .post('/auth/email/register')
        .send({
          email: 'referee@example.com',
          username: 'referee123',
          password: 'password123',
          name: 'Referee User',
          referredBy: ''
        });

      // Should succeed without referral (empty string treated as no referral)
      expect(response.status).toBe(201);

      const referee = await User.findOne({ email: 'referee@example.com' });
      expect(referee.referredBy).toBeNull();
    });
  });
});
