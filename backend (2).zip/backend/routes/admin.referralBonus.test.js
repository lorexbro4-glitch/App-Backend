/**
 * Test file for referral bonus credit logic
 * 
 * Tests Requirements 10.2 and 10.3:
 * - Immediate 5% bonus on first deposit approval
 * - Monthly 5% bonus calculation (distributed daily)
 * - Bonus credit failure handling
 */

import { jest } from '@jest/globals';

// Mock dependencies before imports
const mockUser = {
  _id: 'user123',
  name: 'Test User',
  phone: '01712345678',
  email: 'test@example.com',
  referredBy: 'referrer123',
  balance: 1000,
  capital: 5000,
  referralIncome: 0,
  save: jest.fn().mockResolvedValue(true)
};

const mockReferrer = {
  _id: 'referrer123',
  name: 'Referrer User',
  phone: '01787654321',
  email: 'referrer@example.com',
  balance: 2000,
  referralIncome: 500,
  save: jest.fn().mockResolvedValue(true)
};

const mockDeposit = {
  _id: 'deposit123',
  user: 'user123',
  amount: 10000,
  status: 'pending',
  save: jest.fn().mockResolvedValue(true)
};

const mockTransaction = {
  _id: 'transaction123',
  user: 'referrer123',
  type: 'referral_bonus',
  amount: 500,
  status: 'completed'
};

// Mock User model
const mockUserModel = {
  findById: jest.fn((id) => {
    if (id === 'user123') return Promise.resolve(mockUser);
    if (id === 'referrer123') return Promise.resolve(mockReferrer);
    return Promise.resolve(null);
  }),
  find: jest.fn().mockResolvedValue([mockUser])
};

// Mock Deposit model
const mockDepositModel = {
  findById: jest.fn().mockResolvedValue(mockDeposit)
};

// Mock Transaction model
const mockTransactionModel = {
  create: jest.fn().mockResolvedValue(mockTransaction)
};

// Mock push notification service
const mockPushNotificationService = {
  createAndSendNotification: jest.fn().mockResolvedValue({ success: true })
};

// Mock email service
const mockEmailService = {
  sendReferralBonusEmail: jest.fn().mockResolvedValue(true)
};

describe('Referral Bonus Credit Logic', () => {
  let testUser;
  let testReferrer;
  
  beforeEach(() => {
    // Reset all mocks before each test
    jest.clearAllMocks();
    
    // Create fresh mock objects for each test
    testUser = {
      _id: 'user123',
      name: 'Test User',
      phone: '01712345678',
      email: 'test@example.com',
      referredBy: 'referrer123',
      balance: 1000,
      capital: 5000,
      referralIncome: 0,
      save: jest.fn().mockResolvedValue(true)
    };
    
    testReferrer = {
      _id: 'referrer123',
      name: 'Referrer User',
      phone: '01787654321',
      email: 'referrer@example.com',
      balance: 2000,
      referralIncome: 500,
      save: jest.fn().mockResolvedValue(true)
    };
    
    // Update mock functions to return fresh objects
    mockUserModel.findById = jest.fn((id) => {
      if (id === 'user123') return Promise.resolve(testUser);
      if (id === 'referrer123') return Promise.resolve(testReferrer);
      return Promise.resolve(null);
    });
  });

  describe('Requirement 10.2: Immediate 5% bonus on first deposit', () => {
    test('should credit 5% of deposit amount to referrer when deposit is approved', async () => {
      // Arrange
      const depositAmount = 10000;
      const expectedBonus = Math.floor(depositAmount * 0.05); // 500
      
      // Act - Simulate deposit approval logic from admin.js
      const user = await mockUserModel.findById('user123');
      let referrer = null;
      
      if (user.referredBy) {
        referrer = await mockUserModel.findById(user.referredBy);
        if (referrer) {
          const referralBonus = Math.floor(depositAmount * 0.05);
          referrer.referralIncome = (referrer.referralIncome || 0) + referralBonus;
          referrer.balance = (referrer.balance || 0) + referralBonus;
          await referrer.save();
          
          await mockTransactionModel.create({
            user: referrer._id,
            type: 'referral_bonus',
            amount: referralBonus,
            description: `Referral bonus from ${user.name || user.phone}`,
            status: 'completed'
          });
        }
      }
      
      // Assert
      expect(referrer).not.toBeNull();
      expect(referrer.referralIncome).toBe(500 + expectedBonus);
      expect(referrer.balance).toBe(2000 + expectedBonus);
      expect(referrer.save).toHaveBeenCalledTimes(1);
      expect(mockTransactionModel.create).toHaveBeenCalledWith(
        expect.objectContaining({
          user: 'referrer123',
          type: 'referral_bonus',
          amount: expectedBonus,
          status: 'completed'
        })
      );
    });

    test('should handle case when referrer does not exist', async () => {
      // Arrange
      testUser.referredBy = 'nonexistent';
      mockUserModel.findById = jest.fn((id) => {
        if (id === 'user123') return Promise.resolve(testUser);
        if (id === 'nonexistent') return Promise.resolve(null);
        return Promise.resolve(null);
      });
      
      // Act
      const user = await mockUserModel.findById('user123');
      let bonusCredited = false;
      
      if (user.referredBy) {
        const referrer = await mockUserModel.findById(user.referredBy);
        if (referrer) {
          bonusCredited = true;
        }
      }
      
      // Assert
      expect(bonusCredited).toBe(false);
      expect(mockTransactionModel.create).not.toHaveBeenCalled();
    });

    test('should handle case when user has no referrer', async () => {
      // Arrange
      testUser.referredBy = null;
      
      // Act
      const user = await mockUserModel.findById('user123');
      let bonusCredited = false;
      
      if (user.referredBy) {
        bonusCredited = true;
      }
      
      // Assert
      expect(bonusCredited).toBe(false);
      expect(mockUserModel.findById).toHaveBeenCalledTimes(1);
      expect(mockTransactionModel.create).not.toHaveBeenCalled();
    });

    test('should calculate correct bonus for various deposit amounts', () => {
      const testCases = [
        { deposit: 10000, expectedBonus: 500 },
        { deposit: 999, expectedBonus: 49 }, // Test floor rounding
      ];

      testCases.forEach(({ deposit, expectedBonus }) => {
        const calculatedBonus = Math.floor(deposit * 0.05);
        expect(calculatedBonus).toBe(expectedBonus);
      });
    });
  });

  describe('Requirement 10.3: Monthly 5% bonus calculation and credit', () => {
    test('should calculate daily referral bonus as 5% of capital divided by 30', () => {
      // Arrange
      const refereeCapital = 30000;
      const monthlyRate = 0.05;
      const daysInMonth = 30;
      
      // Act
      const dailyReferralBonus = Math.floor((refereeCapital * monthlyRate) / daysInMonth);
      
      // Assert
      const expectedDailyBonus = Math.floor((30000 * 0.05) / 30); // 50
      expect(dailyReferralBonus).toBe(expectedDailyBonus);
      expect(dailyReferralBonus).toBe(50);
    });

    test('should credit daily referral bonus to referrer balance and referralIncome', async () => {
      // Arrange
      const userCapital = 30000;
      testUser.capital = userCapital;
      const expectedDailyBonus = Math.floor((userCapital * 0.05) / 30); // 50
      const initialBalance = 2000;
      const initialReferralIncome = 500;
      
      // Act - Simulate daily cron job logic from server.js
      const user = await mockUserModel.findById('user123');
      
      if (user.referredBy && user.capital > 0) {
        const referrer = await mockUserModel.findById(user.referredBy);
        if (referrer) {
          const dailyReferralBonus = Math.floor((user.capital * 0.05) / 30);
          referrer.balance = (referrer.balance || 0) + dailyReferralBonus;
          referrer.referralIncome = (referrer.referralIncome || 0) + dailyReferralBonus;
          await referrer.save();
        }
      }
      
      // Assert
      expect(testReferrer.balance).toBe(initialBalance + expectedDailyBonus);
      expect(testReferrer.referralIncome).toBe(initialReferralIncome + expectedDailyBonus);
      expect(testReferrer.save).toHaveBeenCalledTimes(1);
    });

    test('should not credit bonus if referee has zero capital', async () => {
      // Arrange
      testUser.capital = 0;
      
      // Act
      const user = await mockUserModel.findById('user123');
      let bonusCredited = false;
      
      if (user.referredBy && user.capital > 0) {
        bonusCredited = true;
      }
      
      // Assert
      expect(bonusCredited).toBe(false);
    });

    test('should calculate correct daily bonus for various capital amounts', () => {
      const testCases = [
        { capital: 30000, expectedDaily: 50 },  // (30000 * 0.05) / 30 = 50
        { capital: 100000, expectedDaily: 166 }, // (100000 * 0.05) / 30 = 166.67 -> 166
      ];

      testCases.forEach(({ capital, expectedDaily }) => {
        const calculatedDaily = Math.floor((capital * 0.05) / 30);
        expect(calculatedDaily).toBe(expectedDaily);
      });
    });

    test('should accumulate monthly bonus over 30 days', () => {
      // Arrange
      const capital = 30000;
      const dailyBonus = Math.floor((capital * 0.05) / 30);
      const days = 30;
      
      // Act
      const totalMonthlyBonus = dailyBonus * days;
      const expectedMonthlyBonus = capital * 0.05;
      
      // Assert
      // Due to floor rounding, total might be slightly less than exact 5%
      expect(totalMonthlyBonus).toBeGreaterThanOrEqual(expectedMonthlyBonus - days);
      expect(totalMonthlyBonus).toBeLessThanOrEqual(expectedMonthlyBonus);
    });
  });

  describe('Bonus credit failure handling', () => {
    test('should handle referrer save failure gracefully', async () => {
      // Arrange
      const saveError = new Error('Database error');
      testReferrer.save = jest.fn().mockRejectedValue(saveError);
      
      // Act & Assert
      const user = await mockUserModel.findById('user123');
      
      if (user.referredBy) {
        const referrer = await mockUserModel.findById(user.referredBy);
        if (referrer) {
          let errorCaught = false;
          try {
            const referralBonus = Math.floor(10000 * 0.05);
            referrer.referralIncome = (referrer.referralIncome || 0) + referralBonus;
            referrer.balance = (referrer.balance || 0) + referralBonus;
            await referrer.save();
          } catch (error) {
            // Error should be caught and logged, but not throw
            errorCaught = true;
            expect(error.message).toBe('Database error');
          }
          expect(errorCaught).toBe(true);
        }
      }
      
      expect(testReferrer.save).toHaveBeenCalled();
    });

    test('should handle transaction creation failure gracefully', async () => {
      // Arrange
      mockTransactionModel.create = jest.fn().mockRejectedValue(new Error('Transaction creation failed'));
      
      // Act & Assert
      const user = await mockUserModel.findById('user123');
      
      if (user.referredBy) {
        const referrer = await mockUserModel.findById(user.referredBy);
        if (referrer) {
          try {
            const referralBonus = Math.floor(10000 * 0.05);
            referrer.referralIncome = (referrer.referralIncome || 0) + referralBonus;
            referrer.balance = (referrer.balance || 0) + referralBonus;
            await referrer.save();
            
            await mockTransactionModel.create({
              user: referrer._id,
              type: 'referral_bonus',
              amount: referralBonus,
              description: `Referral bonus from ${user.name || user.phone}`,
              status: 'completed'
            });
          } catch (error) {
            // Error should be caught and logged
            expect(error.message).toBe('Transaction creation failed');
          }
        }
      }
    });

    test('should handle notification failure gracefully', async () => {
      // Arrange
      mockPushNotificationService.createAndSendNotification = jest.fn()
        .mockRejectedValue(new Error('Notification failed'));
      
      // Act & Assert
      try {
        await mockPushNotificationService.createAndSendNotification(
          'referrer123',
          'referral_bonus',
          'রেফারেল বোনাস',
          'Test User এর রেফারেল থেকে ৳500 বোনাস পেয়েছেন',
          { referralName: 'Test User', amount: 500 }
        );
      } catch (error) {
        // Notification failure should not prevent bonus credit
        expect(error.message).toBe('Notification failed');
      }
    });

    test('should handle email failure gracefully', async () => {
      // Arrange
      mockEmailService.sendReferralBonusEmail = jest.fn()
        .mockRejectedValue(new Error('Email failed'));
      
      // Act & Assert
      try {
        await mockEmailService.sendReferralBonusEmail(
          'referrer@example.com',
          'Referrer User',
          500,
          'Test User'
        );
      } catch (error) {
        // Email failure should not prevent bonus credit
        expect(error.message).toBe('Email failed');
      }
    });
  });

  describe('Edge cases and validation', () => {
    test('should handle very small deposit amounts correctly', () => {
      const smallDeposit = 100;
      const bonus = Math.floor(smallDeposit * 0.05);
      expect(bonus).toBe(5);
    });

    test('should handle very large deposit amounts correctly', () => {
      const largeDeposit = 1000000;
      const bonus = Math.floor(largeDeposit * 0.05);
      expect(bonus).toBe(50000);
    });

    test('should handle zero capital correctly', () => {
      const capital = 0;
      const dailyBonus = Math.floor((capital * 0.05) / 30);
      expect(dailyBonus).toBe(0);
    });

    test('should use floor rounding consistently', () => {
      // Test that fractional amounts are always rounded down
      const testCases = [
        { amount: 999, expected: 49 },   // 999 * 0.05 = 49.95 -> 49
        { amount: 1999, expected: 99 },  // 1999 * 0.05 = 99.95 -> 99
      ];

      testCases.forEach(({ amount, expected }) => {
        const bonus = Math.floor(amount * 0.05);
        expect(bonus).toBe(expected);
      });
    });
  });
});
