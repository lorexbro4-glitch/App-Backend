﻿import express from 'express';
const router = express.Router();
import User from '../models/User.js';
import auth from '../middleware/auth.js';
import { cacheMiddleware } from '../middleware/cacheMiddleware.js';

// ─── Seeded pseudo-random (deterministic per seed) ───────────────────────────
function seededRand(seed) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

// ─── Master user pool (40 users) ─────────────────────────────────────────────
const USER_POOL = [
  { id: 1,  name: 'মোহাম্মদ আব্দুস সালাম',       phone: '01712', joinDay: 200, baseCapital: 5200000, dailyDeposit: 8500, depositChance: 0.42, baseReferrals: 68, refGrowth: 0.20 },
  { id: 2,  name: 'মো. নুরুল হুদা',               phone: '01819', joinDay: 230, baseCapital: 4600000, dailyDeposit: 7500, depositChance: 0.38, baseReferrals: 55, refGrowth: 0.17 },
  { id: 3,  name: 'মোসাম্মত রাহেলা বেগম',          phone: '01923', joinDay: 175, baseCapital: 3800000, dailyDeposit: 6200, depositChance: 0.33, baseReferrals: 47, refGrowth: 0.14 },
  { id: 4,  name: 'মো. আব্দুল হাকিম',             phone: '01634', joinDay: 255, baseCapital: 3300000, dailyDeposit: 5400, depositChance: 0.46, baseReferrals: 38, refGrowth: 0.22 },
  { id: 5,  name: 'মোহাম্মদ জাহাঙ্গীর আলম',       phone: '01515', joinDay: 295, baseCapital: 2900000, dailyDeposit: 4700, depositChance: 0.30, baseReferrals: 60, refGrowth: 0.26 },
  { id: 6,  name: 'মোছাম্মত আকলিমা বেগম',          phone: '01876', joinDay: 215, baseCapital: 2500000, dailyDeposit: 4000, depositChance: 0.40, baseReferrals: 52, refGrowth: 0.16 },
  { id: 7,  name: 'মো. আমজাদ হোসেন',              phone: '01945', joinDay: 185, baseCapital: 2200000, dailyDeposit: 3500, depositChance: 0.35, baseReferrals: 41, refGrowth: 0.19 },
  { id: 8,  name: 'মোছাম্মত জাহানারা বেগম',         phone: '01723', joinDay: 240, baseCapital: 1950000, dailyDeposit: 3100, depositChance: 0.44, baseReferrals: 35, refGrowth: 0.13 },
  { id: 9,  name: 'মো. সিরাজুল ইসলাম',             phone: '01856', joinDay: 265, baseCapital: 1700000, dailyDeposit: 2700, depositChance: 0.28, baseReferrals: 30, refGrowth: 0.15 },
  { id: 10, name: 'মোসাম্মত হোসনে আরা',            phone: '01612', joinDay: 225, baseCapital: 1500000, dailyDeposit: 2400, depositChance: 0.36, baseReferrals: 26, refGrowth: 0.12 },
  { id: 11, name: 'মোহাম্মদ মজিবুর রহমান',          phone: '01923', joinDay: 308, baseCapital: 1320000, dailyDeposit: 2100, depositChance: 0.52, baseReferrals: 91, refGrowth: 0.47 },
  { id: 12, name: 'মোসাম্মত নূরজাহান বেগম',         phone: '01756', joinDay: 278, baseCapital: 1180000, dailyDeposit: 1900, depositChance: 0.49, baseReferrals: 78, refGrowth: 0.40 },
  { id: 13, name: 'মো. শফিউদ্দিন আহমেদ',           phone: '01834', joinDay: 252, baseCapital: 1040000, dailyDeposit: 1650, depositChance: 0.41, baseReferrals: 69, refGrowth: 0.34 },
  { id: 14, name: 'মোসাম্মত মাহমুদা খাতুন',         phone: '01678', joinDay: 288, baseCapital:  940000, dailyDeposit: 1450, depositChance: 0.37, baseReferrals: 61, refGrowth: 0.29 },
  { id: 15, name: 'মো. বজলুর রহমান',               phone: '01912', joinDay: 318, baseCapital:  850000, dailyDeposit: 1300, depositChance: 0.56, baseReferrals: 53, refGrowth: 0.36 },
  { id: 16, name: 'মোছাম্মত ছালেহা বেগম',           phone: '01567', joinDay: 268, baseCapital:  770000, dailyDeposit: 1180, depositChance: 0.43, baseReferrals: 46, refGrowth: 0.24 },
  { id: 17, name: 'মো. আলাউদ্দিন সরকার',           phone: '01845', joinDay: 238, baseCapital:  700000, dailyDeposit: 1080, depositChance: 0.39, baseReferrals: 40, refGrowth: 0.21 },
  { id: 18, name: 'মোছাম্মত নূরুন্নাহার',            phone: '01734', joinDay: 298, baseCapital:  635000, dailyDeposit:  980, depositChance: 0.46, baseReferrals: 34, refGrowth: 0.25 },
  { id: 19, name: 'মো. খোরশেদ আলম',               phone: '01623', joinDay: 272, baseCapital:  578000, dailyDeposit:  890, depositChance: 0.31, baseReferrals: 30, refGrowth: 0.18 },
  { id: 20, name: 'মোসাম্মত আসমা বেগম',             phone: '01789', joinDay: 248, baseCapital:  525000, dailyDeposit:  820, depositChance: 0.36, baseReferrals: 25, refGrowth: 0.15 },
  { id: 21, name: 'মো. আতিউর রহমান',               phone: '01698', joinDay: 328, baseCapital:  475000, dailyDeposit:  760, depositChance: 0.61, baseReferrals: 97, refGrowth: 0.57 },
  { id: 22, name: 'মোসাম্মত রোজিনা বেগম',           phone: '01778', joinDay: 312, baseCapital:  428000, dailyDeposit:  700, depositChance: 0.56, baseReferrals: 85, refGrowth: 0.50 },
  { id: 23, name: 'মো. নজরুল ইসলাম',               phone: '01857', joinDay: 292, baseCapital:  385000, dailyDeposit:  650, depositChance: 0.51, baseReferrals: 74, refGrowth: 0.44 },
  { id: 24, name: 'মোছাম্মত মোমেনা বেগম',           phone: '01934', joinDay: 282, baseCapital:  348000, dailyDeposit:  600, depositChance: 0.49, baseReferrals: 66, refGrowth: 0.39 },
  { id: 25, name: 'মো. গোলাম মোস্তফা',             phone: '01612', joinDay: 338, baseCapital:  315000, dailyDeposit:  555, depositChance: 0.53, baseReferrals: 58, refGrowth: 0.35 },
  { id: 26, name: 'মোছাম্মত মোমেনা খাতুন',          phone: '01745', joinDay: 302, baseCapital:  285000, dailyDeposit:  505, depositChance: 0.46, baseReferrals: 50, refGrowth: 0.31 },
  { id: 27, name: 'মো. আনিসুর রহমান',              phone: '01826', joinDay: 322, baseCapital:  258000, dailyDeposit:  460, depositChance: 0.43, baseReferrals: 44, refGrowth: 0.28 },
  { id: 28, name: 'মোসাম্মত আনোয়ারা বেগম',          phone: '01913', joinDay: 352, baseCapital:  234000, dailyDeposit:  420, depositChance: 0.41, baseReferrals: 37, refGrowth: 0.24 },
  { id: 29, name: 'মো. হবিবুর রহমান',              phone: '01676', joinDay: 342, baseCapital:  212000, dailyDeposit:  385, depositChance: 0.39, baseReferrals: 31, refGrowth: 0.21 },
  { id: 30, name: 'মোছাম্মত কুলসুম বেগম',           phone: '01753', joinDay: 358, baseCapital:  192000, dailyDeposit:  350, depositChance: 0.36, baseReferrals: 26, refGrowth: 0.18 },
  { id: 31, name: 'মো. তোফাজ্জল হোসেন',            phone: '01619', joinDay: 365, baseCapital:  175000, dailyDeposit:  320, depositChance: 0.34, baseReferrals: 22, refGrowth: 0.16 },
  { id: 32, name: 'মোসাম্মত রহিমা খাতুন',           phone: '01887', joinDay: 375, baseCapital:  161000, dailyDeposit:  295, depositChance: 0.32, baseReferrals: 19, refGrowth: 0.14 },
  { id: 33, name: 'মো. ওবায়দুল হক',               phone: '01752', joinDay: 385, baseCapital:  158000, dailyDeposit:  310, depositChance: 0.35, baseReferrals: 17, refGrowth: 0.13 },
  { id: 34, name: 'মোছাম্মত হাসিনা বেগম',           phone: '01541', joinDay: 370, baseCapital:  168000, dailyDeposit:  330, depositChance: 0.38, baseReferrals: 20, refGrowth: 0.15 },
  { id: 35, name: 'মো. মনিরুজ্জামান',              phone: '01965', joinDay: 362, baseCapital:  182000, dailyDeposit:  345, depositChance: 0.40, baseReferrals: 23, refGrowth: 0.17 },
  { id: 36, name: 'মোসাম্মত সুফিয়া বেগম',           phone: '01838', joinDay: 390, baseCapital:  155000, dailyDeposit:  300, depositChance: 0.30, baseReferrals: 15, refGrowth: 0.11 },
  { id: 37, name: 'মো. আব্দুল জব্বার মিয়া',        phone: '01724', joinDay: 380, baseCapital:  163000, dailyDeposit:  315, depositChance: 0.33, baseReferrals: 18, refGrowth: 0.12 },
  { id: 38, name: 'মোছাম্মত ফাতেমা বেগম',           phone: '01593', joinDay: 395, baseCapital:  152000, dailyDeposit:  305, depositChance: 0.29, baseReferrals: 14, refGrowth: 0.10 },
  { id: 39, name: 'মো. আব্দুস সোবহান',             phone: '01867', joinDay: 388, baseCapital:  157000, dailyDeposit:  308, depositChance: 0.31, baseReferrals: 16, refGrowth: 0.11 },
  { id: 40, name: 'মোসাম্মত মাজেদা খাতুন',          phone: '01548', joinDay: 400, baseCapital:  150000, dailyDeposit:  300, depositChance: 0.28, baseReferrals: 13, refGrowth: 0.09 },
];

// ─── O(1) stats computation with ranking-event system ────────────────────────
//
// Each user has a personal event cycle of 5, 7, or 10 days (based on id).
// On their event day, they receive a one-time big deposit boost (3x–8x dailyDeposit).
// This causes natural, deterministic ranking shifts every few days.
//
function computeUserStats(user, day) {
  const daysActive = Math.max(1, day - user.joinDay);

  // ── Personal event cycle (5, 7, or 10 days based on id) ──────────────────
  const cycles = [5, 7, 10];
  const eventCycle = cycles[user.id % 3];

  // Number of big-deposit events this user has had
  const eventCount = Math.floor(daysActive / eventCycle);

  // Days since the most recent event
  const daysSinceLastEvent = daysActive % eventCycle;

  // ── Normal capital accumulation (between events) ──────────────────────────
  const weekIndex = Math.floor(day / 7);
  const rCapital = seededRand(user.id * 9973 + weekIndex * 6271);
  const expectedDeposits = Math.floor(daysActive * user.depositChance);
  const noise = 0.85 + rCapital() * 0.30;
  const normalDeposited = Math.round(expectedDeposits * user.dailyDeposit * noise / 500) * 500;

  // ── Big deposit events: each event adds a seeded 3x–8x boost ─────────────
  let eventBonus = 0;
  for (let e = 0; e < eventCount; e++) {
    const rEvent = seededRand(user.id * 7331 + e * 4973);
    const multiplier = 3 + rEvent() * 5; // 3x to 8x
    eventBonus += Math.round(multiplier * user.dailyDeposit / 100) * 100;
  }

  // ── Capital: base + normal deposits + all event bonuses ──────────────────
  const capital = user.baseCapital + normalDeposited + eventBonus;

  // ── Profit at 16%/month on current capital ────────────────────────────────
  const DAILY_RATE = 0.16 / 30;
  const totalProfit = Math.floor(capital * DAILY_RATE * daysActive);

  // ── Referrals with occasional small surges ────────────────────────────────
  const rRef = seededRand(user.id * 4001 + weekIndex * 7919);
  const expectedRefGrowth = Math.floor(daysActive * user.refGrowth);
  const surges = Math.floor(daysActive / 13);
  const surgeBonus = Math.floor(surges * (1 + rRef() * 3));
  const refNoise = 0.90 + rRef() * 0.20;
  const referrals = user.baseReferrals + Math.floor(expectedRefGrowth * refNoise) + surgeBonus;

  return { capital, totalProfit, referrals };
}

// ─── Mask phone ───────────────────────────────────────────────────────────────
function maskPhone(prefix) {
  const digits = ['3', '4', '5', '6', '7', '8', '9'];
  const r = seededRand(prefix.charCodeAt(2) * 31 + prefix.charCodeAt(3) * 17);
  const d1 = digits[Math.floor(r() * digits.length)];
  const d2 = digits[Math.floor(r() * digits.length)];
  return prefix + d1 + d2 + '******';
}

import Settings from '../models/Settings.js';

// ─── GET /leaderboard ─────────────────────────────────────────────────────────
router.get('/', auth, cacheMiddleware(120, (req) => `leaderboard:${req.query.type || 'all'}:${req.query.limit || 10}`), async (req, res) => {
  try {
    const { type = 'all', limit = 10 } = req.query;
    const parsedLimit = Math.min(parseInt(limit) || 10, 30);
    const day = Math.floor(Date.now() / (1000 * 60 * 60 * 24));

    const livePool = USER_POOL.map(u => ({
      ...u,
      phone: maskPhone(u.phone),
      ...computeUserStats(u, day),
    }));

    const leaderboard = {};

    if (type === 'all' || type === 'investors') {
      leaderboard.topInvestors = [...livePool]
        .sort((a, b) => b.capital - a.capital)
        .slice(0, parsedLimit)
        .map((u, i) => ({ rank: i + 1, name: u.name, phone: u.phone, amount: u.capital }));
    }

    if (type === 'all' || type === 'earners') {
      leaderboard.topEarners = [...livePool]
        .sort((a, b) => b.totalProfit - a.totalProfit)
        .slice(0, parsedLimit)
        .map((u, i) => ({ rank: i + 1, name: u.name, phone: u.phone, profit: u.totalProfit, capital: u.capital }));
    }

    if (type === 'all' || type === 'referrers') {
      leaderboard.topReferrers = [...livePool]
        .sort((a, b) => b.referrals - a.referrals)
        .slice(0, parsedLimit)
        .map((u, i) => ({
          rank: i + 1,
          name: u.name,
          phone: u.phone,
          referralCount: u.referrals,
          referralIncome: Math.floor(u.referrals * u.capital * 0.05 / 100) * 100,
        }));
    }

    // ── Total users: persisted in DB, grows 5k–10k per month (166–333/day) ──
    const settings = await Settings.findOne().lean();
    let totalUsers = settings?.displayTotalUsers || 1900000;

    // Grow the stored value if a day has passed since last update
    const lastUpdated = settings?.updatedAt ? new Date(settings.updatedAt) : new Date(0);
    const daysSinceUpdate = Math.floor((Date.now() - lastUpdated.getTime()) / (1000 * 60 * 60 * 24));
    if (daysSinceUpdate >= 1) {
      // 166–333 new users per day (5k–10k per month), seeded by day for consistency
      const rGrowth = seededRand(day * 9001);
      const dailyNew = Math.floor(166 + rGrowth() * 167); // 166-333
      totalUsers = totalUsers + dailyNew * daysSinceUpdate;
      // Save back to DB so it persists across server restarts
      await Settings.findOneAndUpdate(
        {},
        { $set: { displayTotalUsers: totalUsers } },
        { upsert: true, new: true }
      );
    }
    leaderboard.totalUsers = totalUsers;

    // ── Current user's rank — offset to look realistic (starts 50k+) ─────────
    const currentUser = await User.findById(req.userId).lean();
    if (currentUser) {
      const userCapital = currentUser.capital || currentUser.depositTotal || 0;
      const userProfit  = currentUser.totalProfit || currentUser.profitTotal || 0;
      const userRefs    = currentUser.referralCount || 0;

      const fakeInvestorsAhead = livePool.filter(u => u.capital > userCapital).length;
      const fakeEarnersAhead   = livePool.filter(u => u.totalProfit > userProfit).length;
      const fakeReferrersAhead = livePool.filter(u => u.referrals > userRefs).length;

      const [realInvestorsAhead, realEarnersAhead, realReferrersAhead] = await Promise.all([
        User.countDocuments({ _id: { $ne: currentUser._id }, isActive: { $ne: false }, capital: { $gt: userCapital } }),
        User.countDocuments({ _id: { $ne: currentUser._id }, isActive: { $ne: false }, totalProfit: { $gt: userProfit } }),
        User.countDocuments({ _id: { $ne: currentUser._id }, isActive: { $ne: false }, referralCount: { $gt: userRefs } }),
      ]);

      // Raw rank from real DB + fake pool (very small — only a few hundred real users)
      const rawInvestorRank = fakeInvestorsAhead + realInvestorsAhead + 1;
      const rawEarnerRank   = fakeEarnersAhead   + realEarnersAhead   + 1;
      const rawReferrerRank = fakeReferrersAhead + realReferrersAhead + 1;

      // Stable per-user base offset (50k–500k depending on capital)
      const userIdHash = currentUser._id.toString().split('').reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 0);
      const rOffset = seededRand(userIdHash);
      const capitalFactor = userCapital > 0 ? Math.min(1, userCapital / 500000) : 0; // 500k BDT = max closeness

      // Investor & earner: more capital → closer to 50k, less → closer to 900k
      const invNoise = rOffset() * 100000; // ±100k noise per user
      const investorBase = Math.floor(900000 - capitalFactor * 850000 + invNoise);
      // Referrer: scales with actual referral count
      // More referrals → closer to 1 lakh, zero referrals → closer to 9 lakh
      const rRefOffset = seededRand(userIdHash * 13 + 77777);
      const refFactor = userRefs > 0 ? Math.min(1, userRefs / 50) : 0; // 50 referrals = max closeness
      const refNoise = rRefOffset() * 100000; // ±100k noise so not all same-ref-count users have same rank
      const referrerBase = Math.floor(900000 - refFactor * 800000 + refNoise);

      // Daily drift: -2000 to +2000 each day (changes every day)
      const rDaily = seededRand(userIdHash * 3 + day * 7);
      const dailyMove = Math.floor((rDaily() - 0.5) * 4000);

      // Slow weekly trend
      const weekIndex = Math.floor(day / 7);
      const rWeekly = seededRand(userIdHash * 5 + weekIndex * 11);
      const weeklyTrend = Math.floor((rWeekly() - 0.45) * 8000);

      const totalDrift = dailyMove + weeklyTrend;

      // Referrer gets its own independent daily drift
      const rRefDaily = seededRand(userIdHash * 7 + day * 13);
      const refDrift = Math.floor((rRefDaily() - 0.5) * 4000) + Math.floor((seededRand(userIdHash * 9 + weekIndex * 17)() - 0.45) * 8000);

      leaderboard.userRanks = {
        investor: Math.max(rawInvestorRank, Math.min(totalUsers - 1, rawInvestorRank + investorBase + totalDrift)),
        earner:   Math.max(rawEarnerRank,   Math.min(totalUsers - 1, rawEarnerRank   + investorBase + totalDrift)),
        referrer: Math.max(rawReferrerRank, Math.min(totalUsers - 1, rawReferrerRank + referrerBase + refDrift)),
      };
    }

    res.json(leaderboard);
  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// ─── GET /leaderboard/rank ────────────────────────────────────────────────────
router.get('/rank', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ message: 'ইউজার পাওয়া যায়নি' });

    const day      = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
    const livePool = USER_POOL.map(u => ({ ...u, ...computeUserStats(u, day) }));

    const userCapital = user.capital || user.depositTotal || 0;
    const userProfit  = user.totalProfit || user.profitTotal || 0;
    const userRefs    = user.referralCount || 0;

    const fakeInvestorsAhead = livePool.filter(u => u.capital > userCapital).length;
    const fakeEarnersAhead   = livePool.filter(u => u.totalProfit > userProfit).length;
    const fakeReferrersAhead = livePool.filter(u => u.referrals > userRefs).length;

    const [realInvestorsAhead, realEarnersAhead, realReferrersAhead] = await Promise.all([
      User.countDocuments({ _id: { $ne: user._id }, isActive: { $ne: false }, capital: { $gt: userCapital } }),
      User.countDocuments({ _id: { $ne: user._id }, isActive: { $ne: false }, totalProfit: { $gt: userProfit } }),
      User.countDocuments({ _id: { $ne: user._id }, isActive: { $ne: false }, referralCount: { $gt: userRefs } }),
    ]);

    res.json({
      investor: fakeInvestorsAhead + realInvestorsAhead + 1,
      referrer: fakeReferrersAhead + realReferrersAhead + 1,
      earner:   fakeEarnersAhead   + realEarnersAhead   + 1,
      stats: { capital: userCapital, referralCount: userRefs, totalProfit: userProfit },
    });
  } catch (error) {
    console.error('User rank error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
