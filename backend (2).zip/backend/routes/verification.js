import express from 'express';
const router = express.Router();
import auth from '../middleware/auth.js';
import Verification from '../models/Verification.js';
import User from '../models/User.js';
import { createKYCSubmissionNotification, notifyAdminNewKYC } from '../services/notificationService.js';
import pushNotificationService from '../services/pushNotificationService.js';
import { notifyVerificationRequest } from '../services/telegramNotificationService.js';
import { notifyAdminVerificationRequest } from '../services/adminEmailNotificationService.js';
import { sendVerificationSubmissionEmail } from '../services/requestEmailService.js';

// Submit KYC Verification
router.post('/', auth, async (req, res) => {
  try {
    const { name, phone, nidNumber, dateOfBirth, address, withdrawPassword, nidFrontImage, nidBackImage, selfieImage } = req.body;

    // Validate required fields
    if (!name || !phone || !nidNumber || !dateOfBirth || !address || !withdrawPassword || !nidFrontImage || !nidBackImage || !selfieImage) {
      return res.status(400).json({ message: 'সব ফিল্ড পূরণ করুন এবং সব ছবি আপলোড করুন' });
    }

    // Check if user already submitted KYC
    const existingVerification = await Verification.findOne({ user: req.userId });
    if (existingVerification) {
      if (existingVerification.status === 'pending') {
        return res.status(400).json({ 
          message: 'আপনার KYC ভেরিফিকেশন ইতিমধ্যে পেন্ডিং আছে',
          verification: existingVerification
        });
      }
      if (existingVerification.status === 'approved') {
        return res.status(400).json({ 
          message: 'আপনার KYC ইতিমধ্যে অনুমোদিত হয়েছে',
          verification: existingVerification
        });
      }
      // If rejected, allow resubmission by updating existing record
      existingVerification.name = name;
      existingVerification.phone = phone;
      existingVerification.nidNumber = nidNumber;
      existingVerification.dateOfBirth = new Date(dateOfBirth);
      existingVerification.address = address;
      existingVerification.withdrawPassword = withdrawPassword;
      existingVerification.nidFrontImage = nidFrontImage;
      existingVerification.nidBackImage = nidBackImage;
      existingVerification.selfieImage = selfieImage;
      existingVerification.status = 'pending';
      existingVerification.rejectionReason = null;
      await existingVerification.save();

      // Send KYC resubmission notification
      try {
        await createKYCSubmissionNotification(req.userId);
        const user = await User.findById(req.userId);
        await notifyAdminNewKYC(user.name || user.phone, nidNumber);
        
        // Send Telegram notification to admin
        await notifyVerificationRequest({
          userName: user.name,
          userPhone: user.phone,
          nidNumber: nidNumber,
          createdAt: existingVerification.createdAt,
        });
        
        // Send Email notification to admin
        await notifyAdminVerificationRequest({
          userName: user.name,
          userPhone: user.phone,
          nidNumber: nidNumber,
          createdAt: existingVerification.createdAt,
        });
        
        // Send push notification to all admin devices
        await pushNotificationService.sendToAdmins({
          title: 'নতুন KYC ভেরিফিকেশন',
          body: `${user.name || user.phone} - NID: ${nidNumber}`,
          data: {
            type: 'verification_request',
            userId: req.userId.toString(),
            verificationId: existingVerification._id.toString(),
            nidNumber: nidNumber,
          },
        });
        console.log('Admin push notification sent for KYC resubmission');
        
        // Send submission confirmation email to user
        if (user.email) {
          await sendVerificationSubmissionEmail(user.email, user.name, nidNumber);
          console.log('KYC resubmission email sent to user');
        }
      } catch (notifError) {
        console.error('⚠️ Failed to send KYC resubmission notification:', notifError);
        // Don't fail the submission if notification fails
      }

      return res.status(200).json({
        message: 'KYC ভেরিফিকেশন পুনরায় সাবমিট হয়েছে',
        verification: existingVerification
      });
    }

    // Create new verification
    const verification = new Verification({
      user: req.userId,
      userId: req.userId,
      name,
      phone,
      nidNumber,
      dateOfBirth: new Date(dateOfBirth),
      address,
      withdrawPassword,
      nidFrontImage,
      nidBackImage,
      selfieImage,
      status: 'pending'
    });

    await verification.save();

    // Send KYC submission notification
    try {
      await createKYCSubmissionNotification(req.userId);
      // Notify admin about new KYC verification
      const user = await User.findById(req.userId);
      await notifyAdminNewKYC(user.name || user.phone, nidNumber);
      
      // Send Telegram notification to admin
      await notifyVerificationRequest({
        userName: user.name,
        userPhone: user.phone,
        nidNumber: nidNumber,
        createdAt: verification.createdAt,
      });
      
      // Send Email notification to admin
      await notifyAdminVerificationRequest({
        userName: user.name,
        userPhone: user.phone,
        nidNumber: nidNumber,
        createdAt: verification.createdAt,
      });
      
      // Send push notification to all admin devices
      await pushNotificationService.sendToAdmins({
        title: 'নতুন KYC ভেরিফিকেশন',
        body: `${user.name || user.phone} - NID: ${nidNumber}`,
        data: {
          type: 'verification_request',
          userId: req.userId.toString(),
          verificationId: verification._id.toString(),
          nidNumber: nidNumber,
        },
      });
      console.log('Admin push notification sent for new KYC verification');
      
      // Send submission confirmation email to user
      if (user.email) {
        await sendVerificationSubmissionEmail(user.email, user.name, nidNumber);
        console.log('KYC submission email sent to user');
      }
    } catch (notifError) {
      console.error('⚠️ Failed to send KYC notification:', notifError);
      // Don't fail the submission if notification fails
    }

    res.status(201).json({
      message: 'KYC ভেরিফিকেশন সাবমিট হয়েছে। অনুমোদনের জন্য অপেক্ষা করুন',
      verification
    });
  } catch (error) {
    console.error('Verification submission error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Verification Status
router.get('/status', auth, async (req, res) => {
  try {
    const verification = await Verification.findOne({ user: req.userId });
    
    if (!verification) {
      return res.json({ 
        status: 'not_submitted',
        message: 'KYC ভেরিফিকেশন সাবমিট করা হয়নি'
      });
    }

    res.json({
      status: verification.status,
      verification,
      message: verification.status === 'pending' 
        ? 'আপনার KYC ভেরিফিকেশন পেন্ডিং আছে'
        : verification.status === 'approved'
        ? 'আপনার KYC অনুমোদিত হয়েছে'
        : `আপনার KYC রিজেক্ট হয়েছে। কারণ: ${verification.rejectionReason || 'তথ্য সঠিক নয়'}`
    });
  } catch (error) {
    console.error('Get verification status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Verification Details
router.get('/', auth, async (req, res) => {
  try {
    const verification = await Verification.findOne({ user: req.userId });
    
    if (!verification) {
      return res.status(404).json({ 
        message: 'KYC ভেরিফিকেশন পাওয়া যায়নি'
      });
    }

    res.json({ verification });
  } catch (error) {
    console.error('Get verification error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
