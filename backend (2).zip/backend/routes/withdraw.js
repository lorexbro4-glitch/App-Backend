import express from 'express';
const router = express.Router();
import Withdraw from '../models/Withdraw.js';
import User from '../models/User.js';
import auth from '../middleware/auth.js';
import { validate, schemas } from '../middleware/validation.js';
import { createWithdrawalSubmissionNotification, notifyAdminNewWithdrawal } from '../services/notificationService.js';
import { idempotencyMiddleware, updateIdempotencyCache } from '../middleware/idempotency.js';
import requestValidationService from '../services/requestValidationService.js';
import transactionHistoryService from '../services/transactionHistoryService.js';
import pushNotificationService from '../services/pushNotificationService.js';
import { notifyWithdrawRequest } from '../services/telegramNotificationService.js';
import { notifyAdminWithdrawRequest } from '../services/adminEmailNotificationService.js';
import { sendWithdrawalSubmissionEmail } from '../services/requestEmailService.js';
import BENGALI_TEXT from '../constants/bengaliText.js';
import logger from '../config/logger.js';

// Create Withdrawal Request
router.post('/', auth, validate(schemas.withdrawal), idempotencyMiddleware({ model: 'Withdraw' }), async (req, res, next) => {
  try {
    const { amount, type, method, accountNumber, withdrawPassword } = req.body;

    // ── Bangladesh Time Window Check (09:00 – 21:00 BD time) ──────────────────
    const nowUTC = new Date();
    const bdHour = (nowUTC.getUTCHours() + 6) % 24; // UTC+6
    if (bdHour < 9 || bdHour >= 21) {
      return res.status(403).json({
        message: 'উইথড্র সেবা বর্তমানে বন্ধ আছে। সকাল ৯টা থেকে রাত ৯টার মধ্যে উইথড্র করুন।',
        withdrawClosed: true,
      });
    }
    // ─────────────────────────────────────────────────────────────────────────

    // Validation is now handled by middleware, but keep these checks for backward compatibility
    if (!amount || !type || !method || !accountNumber || !withdrawPassword) {
      return res.status(400).json({ message: 'সব ফিল্ড পূরণ করুন' });
    }

    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'ইউজার পাওয়া যায়নি' });
    }

    // Check KYC verification - MUST be approved to withdraw
    const Verification = (await import('../models/Verification.js')).default;
    const verification = await Verification.findOne({ user: req.userId });
    
    if (!verification) {
      return res.status(403).json({ 
        message: 'উইথড্র করার আগে KYC ভেরিফিকেশন সম্পন্ন করুন',
        requiresKYC: true,
        kycStatus: 'not_submitted'
      });
    }

    if (verification.status === 'pending') {
      return res.status(403).json({ 
        message: 'আপনার KYC ভেরিফিকেশন পেন্ডিং আছে। অনুগ্রহ করে অপেক্ষা করুন',
        requiresKYC: true,
        kycStatus: 'pending'
      });
    }

    if (verification.status === 'rejected') {
      return res.status(403).json({ 
        message: `আপনার KYC রিজেক্ট হয়েছে। কারণ: ${verification.rejectionReason || 'তথ্য সঠিক নয়'}`,
        requiresKYC: true,
        kycStatus: 'rejected',
        rejectionReason: verification.rejectionReason
      });
    }

    // Verify withdraw password
    if (verification.withdrawPassword !== withdrawPassword) {
      return res.status(401).json({ 
        message: 'উইথড্র পাসওয়ার্ড ভুল',
        incorrectPassword: true
      });
    }

    // Check for pending withdrawal request
    const hasPending = await requestValidationService.hasPendingWithdrawal(req.userId);
    if (hasPending) {
      return res.status(400).json({
        message: BENGALI_TEXT.PENDING_WITHDRAWAL_EXISTS,
        hasPendingRequest: true,
      });
    }

    // Check if user has enough balance
    if (type === 'profit' && user.totalProfit < amount) {
      return res.status(400).json({ message: 'পর্যাপ্ত প্রফিট নেই' });
    }

    if (type === 'capital' && user.capital < amount) {
      return res.status(400).json({ message: 'পর্যাপ্ত ক্যাপিটাল নেই' });
    }

    // Validate capital lock for capital withdrawals
    const lockValidation = await requestValidationService.validateCapitalLock(req.userId, type);
    if (type === 'capital' && lockValidation.isLocked) {
      return res.status(403).json({
        message: lockValidation.message,
        capitalLocked: true,
        lockUntil: lockValidation.lockUntil,
      });
    }

    const withdraw = new Withdraw({
      user: req.userId,
      userId: req.userId,
      amount,
      type,
      method,
      accountNumber,
      idempotencyKey: req.idempotencyKey,
    });

    await withdraw.save();

    // **IMMEDIATELY DEDUCT MONEY FROM USER BALANCE**
    if (type === 'profit') {
      user.totalProfit = (user.totalProfit || 0) - amount;
    } else {
      user.capital = (user.capital || 0) - amount;
    }
    user.balance = (user.balance || 0) - amount;
    await user.save();

    // Update idempotency cache
    if (req.idempotencyKey) {
      updateIdempotencyCache(req.idempotencyKey, withdraw._id.toString());
    }

    // Create submission transaction
    const submissionTransaction = await transactionHistoryService.createRequestTransaction(
      req.userId,
      'withdrawal',
      amount,
      withdraw._id
    );

    // Link transaction to withdrawal
    withdraw.submissionTransactionId = submissionTransaction._id;
    await withdraw.save();

    // Update user's pending withdrawal flag
    await requestValidationService.updatePendingFlag(req.userId, 'withdrawal', true);

    // Send withdrawal submission notification
    try {
      await createWithdrawalSubmissionNotification(req.userId, amount);
      
      // Send Telegram notification to admin
      await notifyWithdrawRequest({
        amount: amount,
        method: method,
        userName: user.name,
        accountNumber: accountNumber,
        createdAt: withdraw.createdAt,
      });
      
      // Send Email notification to admin
      await notifyAdminWithdrawRequest({
        amount: amount,
        method: method,
        type: type,
        userName: user.name,
        userPhone: user.phone,
        createdAt: withdraw.createdAt,
      });
      
      // Send push notification to all admin devices
      const adminNotifResult = await pushNotificationService.sendToAdmins({
        title: 'নতুন উইথড্র রিকোয়েস্ট',
        body: `${user.name || user.phone} - ৳${amount} (${method}) - ${type === 'profit' ? 'Profit' : 'Capital'}`,
        data: {
          type: 'withdrawal_request',
          userId: user._id.toString(),
          withdrawalId: withdraw._id.toString(),
          amount: amount,
          withdrawalType: type,
        },
      });
      
      if (adminNotifResult.sent > 0) {
        logger.info(`Admin notification sent for new withdrawal: sent=${adminNotifResult.sent}, failed=${adminNotifResult.failed}`);
      } else {
        logger.warn(`Failed to send admin notification for withdrawal: ${JSON.stringify(adminNotifResult.errors)}`);
      }
      
      // Send submission confirmation email to user
      if (user.email) {
        await sendWithdrawalSubmissionEmail(user.email, user.name, amount, type, method);
        logger.info('Withdrawal submission email sent to user');
      }
    } catch (notifError) {
      logger.error('Failed to send withdrawal notification:', notifError);
      // Don't fail the withdrawal if notification fails
    }

    res.status(201).json({
      message: BENGALI_TEXT.WITHDRAWAL_SUBMITTED,
      withdraw,
    });
  } catch (error) {
    logger.error('Withdraw error:', error);
    next(error);
  }
});

// Get Withdrawal History
router.get('/history', auth, async (req, res, next) => {
  try {
    const withdraws = await Withdraw.find({
      $or: [{ userId: req.userId }, { user: req.userId }]
    })
      .sort({ createdAt: -1 })
      .limit(20);

    res.json({ withdraws });
  } catch (error) {
    logger.error('Get withdraw history error:', error);
    next(error);
  }
});

export default router;
