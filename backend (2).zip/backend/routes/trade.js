/**
 * Trade routes — binary option trading
 *
 * All users see the SAME candles (server is the single source of price truth).
 * Balance = (capital + totalProfit) / 125  BDT→USD conversion.
 * Trade deduction: cut from totalProfit first, then capital.
 * Win:  profit credited to totalProfit.
 * Loss: amount already deducted, nothing more needed.
 *
 * Endpoints:
 *   GET  /api/trade/assets
 *   GET  /api/trade/price/:assetId
 *   GET  /api/trade/candles/:assetId
 *   POST /api/trade/place
 *   POST /api/trade/settle/:tradeId
 *   GET  /api/trade/open
 *   GET  /api/trade/history
 *   GET  /api/trade/balance
 *   POST /api/trade/demo/place    (demo trade, no real money)
 *   POST /api/trade/demo/settle/:demoId
 */

import express from 'express';
const router = express.Router();

import auth from '../middleware/auth.js';
import Trade from '../models/Trade.js';
import Candle from '../models/Candle.js';
import User from '../models/User.js';
import logger from '../config/logger.js';
import { _candleSchedule } from './admin.js';

// ─── BDT → USD conversion ─────────────────────────────────────────────────────
const BDT_PER_USD = 125;

/** Convert user BDT balance (capital + profit) to USD for trading */
function bdtToUsd(bdt) {
  return parseFloat((bdt / BDT_PER_USD).toFixed(2));
}
/** Convert USD trade amount back to BDT */
function usdToBdt(usd) {
  return parseFloat((usd * BDT_PER_USD).toFixed(2));
}

/** Get effective USD trading balance from user record */
function getUserTradingBalance(user) {
  const totalBdt = (user.totalProfit || 0) + (user.capital || 0);
  return bdtToUsd(totalBdt);
}

// ─── Asset definitions ────────────────────────────────────────────────────────
export const ASSETS = {
  'EUR/USD': { label: 'EUR/USD', payout: 82, basePrice: 1.08502, vol: 0.0018, dec: 5 },
  'GBP/USD': { label: 'GBP/USD', payout: 78, basePrice: 1.26198, vol: 0.0020, dec: 5 },
  'USD/JPY': { label: 'USD/JPY', payout: 80, basePrice: 157.423, vol: 0.0022, dec: 3 },
  'BTC/USD': { label: 'BTC/USD', payout: 75, basePrice: 67412.0, vol: 0.0050, dec: 1 },
  'XAU/USD': { label: 'Gold',    payout: 80, basePrice: 2341.50, vol: 0.0025, dec: 2 },
  'ETH/USD': { label: 'ETH/USD', payout: 76, basePrice: 3480.0,  vol: 0.0045, dec: 2 },
};

// ─── Shared live price (same for ALL users) ───────────────────────────────────
const livePrice = {};
Object.keys(ASSETS).forEach(id => { livePrice[id] = ASSETS[id].basePrice; });

// ─── Current open candle per asset ───────────────────────────────────────────
const openCandle = {};

const TICK_MS        = 250;    // price tick interval — smooth in-memory movement
const SAVE_INTERVAL  = 5000;   // save to DB every 5s
const CANDLE_BUCKET  = 10_000; // 10-second candles
let   lastSaveTime   = 0;
let   dbHealthy      = true;   // tracks DB connectivity for tick engine

function floorToBucket(date) {
  const ms = Math.floor(date.getTime() / CANDLE_BUCKET) * CANDLE_BUCKET;
  return new Date(ms);
}

async function upsertCandle(assetId, price, now) {
  const bucketTime = floorToBucket(now);

  // New minute bucket — close the previous candle first
  if (!openCandle[assetId] || openCandle[assetId].openTime.getTime() !== bucketTime.getTime()) {
    if (openCandle[assetId]) {
      try {
        await Candle.findOneAndUpdate(
          { assetId, openTime: openCandle[assetId].openTime },
          { $set: { close: openCandle[assetId].close, high: openCandle[assetId].high, low: openCandle[assetId].low, isLive: false } },
          { upsert: true, new: true }
        );
      } catch (err) {
        if (err.code !== 11000) logger.warn('Candle close:', err.message);
      }
    }
    // Open new candle bucket
    openCandle[assetId] = {
      assetId, openTime: bucketTime,
      open: price, high: price, low: price, close: price, isLive: true,
    };
  } else {
    // Update current candle
    const c = openCandle[assetId];
    c.close = price;
    if (price > c.high) c.high = price;
    if (price < c.low)  c.low  = price;
  }

  // Save current live candle to DB
  try {
    await Candle.findOneAndUpdate(
      { assetId, openTime: openCandle[assetId].openTime },
      {
        $setOnInsert: { assetId, openTime: openCandle[assetId].openTime, open: openCandle[assetId].open },
        $set: { close: openCandle[assetId].close, high: openCandle[assetId].high, low: openCandle[assetId].low, isLive: true },
      },
      { upsert: true, new: true }
    );
  } catch (err) {
    if (err.code !== 11000) logger.warn('Candle upsert:', err.message);
  }
}

// ─── House edge — Trade outcome controller ────────────────────────────────────
const CYCLE_RESET_MS = 12 * 60 * 60 * 1000; // 12 hours

async function getTradeOutcome(userId, amount, payout, activeUserCount, tradeDirection) {
  const user = await User.findById(userId).select('tradeControl');
  if (!user) return 'natural';

  const tc = user.tradeControl || {};

  // ── PRIORITY 1: Admin direct override ────────────────────────────────────
  if (tc.adminOverride === 'force_loss' || tc.adminOverride === 'force_win') {
    const outcome = tc.adminOverride;
    // Decrement override count if not permanent
    if (tc.overrideTrades > 0) {
      const remaining = tc.overrideTrades - 1;
      await User.findByIdAndUpdate(userId, {
        $inc: { 'tradeControl.totalTrades': 1 },
        $set: {
          'tradeControl.overrideTrades': remaining,
          'tradeControl.adminOverride':  remaining <= 0 ? null : tc.adminOverride,
        },
      });
    } else {
      // Permanent override — keep it, just count the trade
      await User.findByIdAndUpdate(userId, { $inc: { 'tradeControl.totalTrades': 1 } });
    }
    return outcome;
  }

  // ── PRIORITY 2: Multiple users — bigger bet loses ─────────────────────────
  if (activeUserCount >= 2) {
    // Find all active trades on this asset to compare amounts
    const activeTrades = Object.values(_exposure).flat()
      .filter(t => new Date(t.expiresAt).getTime() > Date.now());

    // Find the biggest trade on the opposite direction
    const opposite  = tradeDirection === 'up' ? 'down' : 'up';
    const maxOppAmt = activeTrades
      .filter(t => t.direction === opposite)
      .reduce((max, t) => Math.max(max, t.amount), 0);

    // If current user's trade is bigger than opposite → LOSS (house keeps more)
    // If smaller or equal → WIN (house still profits from the bigger loser)
    const outcome = amount >= maxOppAmt ? 'force_loss' : 'force_win';
    await User.findByIdAndUpdate(userId, { $inc: { 'tradeControl.totalTrades': 1 } });
    return outcome;
  }

  // ── PRIORITY 3: Single user — 12h cycle ───────────────────────────────────
  const lastReset  = tc.lastReset ? new Date(tc.lastReset).getTime() : 0;
  const now        = Date.now();
  const needsReset = (now - lastReset) >= CYCLE_RESET_MS;

  // FIX #6: Use 'tradesInCycle' to track whether this is truly the first trade.
  // 'houseTaken === 0' alone is wrong — it stays 0 after the first trade wins.
  let houseTaken    = needsReset ? 0 : (tc.houseTaken || 0);
  let userProfit    = needsReset ? 0 : (tc.userProfit || 0);
  let tradesInCycle = needsReset ? 0 : (tc.tradesInCycle || 0);

  const potentialPayout = parseFloat(((amount * payout) / 100).toFixed(2));

  let outcome;
  if (tradesInCycle === 0) {
    // Truly first trade of this cycle — apply first-trade rules
    // ≤ $10 → 80% loss, 20% win (random feel)
    // > $10 → always loss (protect house on big first bets)
    const isSmall   = amount <= 10;
    const firstLose = isSmall ? Math.random() < 0.80 : true;

    if (firstLose) {
      outcome    = 'force_loss';
      houseTaken += amount;
    } else {
      // Small bet wins first — track profit so next loss compensates
      outcome    = 'force_win';
      userProfit += potentialPayout;
    }
  } else {
    // Subsequent trade — check if user has "earned back" what the house banked
    const projectedProfit = userProfit + potentialPayout;
    if (projectedProfit < houseTaken) {
      // House still has more than user — eligible to win.
      // Apply 70/30: 70% chance win, 30% chance loss anyway (house keeps edge).
      if (Math.random() < 0.70) {
        outcome    = 'force_win';
        userProfit = projectedProfit;
      } else {
        outcome    = 'force_loss';
        houseTaken += amount;
      }
    } else {
      outcome    = 'force_loss';
      houseTaken += amount;
    }
  }

  await User.findByIdAndUpdate(userId, {
    $inc: { 'tradeControl.totalTrades': 1 },
    $set: {
      'tradeControl.houseTaken':    houseTaken,
      'tradeControl.userProfit':    userProfit,
      'tradeControl.tradesInCycle': tradesInCycle + 1,
      'tradeControl.lastReset':     needsReset ? new Date() : (tc.lastReset || new Date()),
    },
  });

  return outcome;
}

// Tracks all active trades per asset. Near expiry, biases price toward
// the direction that makes the MAJORITY of money LOSE — maximizing house profit.
// Bias is subtle (capped at 1.5× vol), looks like normal market movement.

const _exposure = {}; // { assetId: [{ id, direction, amount, entryPrice, expiresAt }] }

export function registerTrade(assetId, trade) {
  if (!_exposure[assetId]) _exposure[assetId] = [];
  _exposure[assetId].push(trade);
}

export function unregisterTrade(assetId, tradeId) {
  if (_exposure[assetId]) {
    _exposure[assetId] = _exposure[assetId].filter(t => t.id !== tradeId);
  }
}

function getHouseBias(assetId, currentPrice, now) {
  const trades = _exposure[assetId];
  if (!trades || trades.length === 0) return 0;

  const nowMs = typeof now === 'number' ? now : now.getTime();

  let upUsd   = 0;
  let downUsd = 0;

  for (const t of trades) {
    const expiresMs  = new Date(t.expiresAt).getTime();
    const secsLeft   = (expiresMs - nowMs) / 1000;
    if (secsLeft <= 0) continue;

    // Only apply bias in last 8 seconds — before that, pure market
    if (secsLeft > 8) continue;

    // Urgency peaks at 1s left, very gentle at 8s
    const urgency = Math.max(0.05, Math.min(0.6, 2.5 / Math.max(2, secsLeft)));

    if (t.direction === 'up')   upUsd   += t.amount * urgency;
    else                        downUsd += t.amount * urgency;
  }

  const total = upUsd + downUsd;
  if (total < 1) return 0;

  const imbalance = (upUsd - downUsd) / total; // -1 to +1
  const biasDir   = -Math.sign(imbalance);

  // MAX bias strength: 0.4× vol — subtle, not guaranteed loss
  // This gives house ~60-65% win rate, user wins ~35-40%
  const strength = Math.abs(imbalance) * 0.4;

  // 30% of the time, skip the bias entirely — keeps it unpredictable
  if (Math.random() < 0.30) return 0;

  return biasDir * strength;
}

// ─── Price engine — fast, flow, occasional jumps ─────────────────────────────
const _m = {};

// Candle direction control per asset:
// { assetId: { targetDir: 'up'|'down', entryPrice, expiresAt, totalSeconds } }
// When a trade is placed, we decide WHERE the candle should end up.
// The price engine steers toward that target. Outcome follows naturally from price.
const _candleTargets = {}; // assetId → { targetDir, entryPrice, expiresAt, totalSeconds, tradeIds[] }

export function registerCandleTarget(tradeId, assetId, direction, entryPrice, expiresAt, totalSeconds, targetDir, amount, userId) {
  if (!_candleTargets[assetId]) {
    // First trade in this window — use the cycle-determined target direction
    _candleTargets[assetId] = {
      tradeIds:     [],
      userIds:      new Set(),
      targetDir,          // set by cycle (force_win/loss logic)
      entryPrice,
      expiresAt:    new Date(expiresAt).getTime(),
      totalSeconds,
      totalUp:      0,
      totalDown:    0,
      multiUser:    false,
    };
  }
  const t = _candleTargets[assetId];
  t.tradeIds.push(tradeId);
  if (userId) t.userIds.add(String(userId));

  if (direction === 'up')   t.totalUp   += amount;
  else                       t.totalDown += amount;

  const expMs = new Date(expiresAt).getTime();
  if (expMs > t.expiresAt) { t.expiresAt = expMs; t.totalSeconds = totalSeconds; }

  // FIX #3: Only override targetDir when MULTIPLE DIFFERENT USERS exist in this window.
  // Same user trading the same asset twice keeps the cycle-determined direction.
  const distinctUsers = t.userIds ? t.userIds.size : 0;
  if (distinctUsers >= 2) {
    t.multiUser = true;
    // Multi-user: candle goes AGAINST majority money direction
    t.targetDir = t.totalUp >= t.totalDown ? 'down' : 'up';
  }
  // Single user (even with multiple trades): keep the original cycle targetDir
}

export function clearCandleTarget(tradeId, assetId) {
  if (!_candleTargets[assetId]) return;
  const t = _candleTargets[assetId];
  t.tradeIds = t.tradeIds.filter(id => id !== tradeId);
  if (t.tradeIds.length === 0) {
    delete _candleTargets[assetId];
    return;
  }
  // Rebuild userIds from remaining trades in _exposure so multiUser state stays accurate
  if (t.userIds) {
    const remainingUserIds = new Set(
      (_exposure[assetId] || [])
        .filter(e => t.tradeIds.includes(e.id))
        .map(e => String(e.userId))
    );
    t.userIds = remainingUserIds;
    // If we're back to one user, disable multi-user mode
    if (remainingUserIds.size < 2) {
      t.multiUser = false;
      // targetDir stays as-is from the last cycle decision — don't recompute here
      // because we can't know which user's cycle decision to use
    }
  }
}

function nextPrice(assetId, prev, vol, tickNowMs) {
  const nowMs = tickNowMs || Date.now();

  if (!_m[assetId]) {
    _m[assetId] = { vel: 0, modeTimer: 0, mode: 'normal' };
  }
  const st = _m[assetId]; // use 'st' to avoid shadowing in schedule block

  // ── Candle schedule override — admin-forced direction window ──────────────
  const schedule = _candleSchedule.find(sc => nowMs >= sc.from && nowMs <= sc.to);
  if (schedule) {
    if (!schedule.startPrice) schedule.startPrice = prev;
    const totalMs  = schedule.to - schedule.from;
    const elapsed  = nowMs - schedule.from;
    const progress = Math.min(1, elapsed / totalMs);
    const urgency  = 0.3 + progress * 1.4;
    const tDir     = schedule.direction === 'up' ? 1 : -1;
    const winning  = schedule.direction === 'up' ? prev > schedule.startPrice : prev < schedule.startPrice;
    if (!winning || progress > 0.80) {
      st.vel = st.vel * 0.4 + tDir * vol * urgency;
    }
    const sCap = vol * 2.5;
    st.vel = Math.max(-sCap, Math.min(sCap, st.vel));
    return Math.max(prev * 0.5, prev * (1 + st.vel));
  }

  // ── Candle target steering — moves price to guarantee correct outcome ────
  const target = _candleTargets[assetId];
  if (target && target.expiresAt > nowMs) {
    const secsLeft   = (target.expiresAt - nowMs) / 1000;
    const steerWin   = Math.max(2, Math.min(8, target.totalSeconds * 0.20)); // max 8s, was 40%

    if (secsLeft <= steerWin) {
      const tDir   = target.targetDir === 'up' ? 1 : -1;

      // Check margin — how far is price from entry in the winning direction
      const margin = tDir === 1
        ? prev - target.entryPrice   // positive = already above entry (winning)
        : target.entryPrice - prev;  // positive = already below entry (winning)

      const clearlyWinning = margin > prev * 0.0003; // more than 3 pips clear
      const clearlyLosing  = margin < -(prev * 0.0010); // more than 10 pips wrong way

      if (clearlyWinning) {
        // Outcome already secured — just add natural noise, no steering
        st.vel = st.vel * 0.92 + (Math.random() - 0.5) * ASSETS[assetId].vol * 0.4;
      } else if (clearlyLosing && secsLeft > 1.5) {
        // Way off target but still time — gentle corrective push, not aggressive grind
        const urgency = Math.max(0.3, Math.min(1.2, 3.0 / Math.max(1, secsLeft)));
        const noise   = (Math.random() - 0.5) * ASSETS[assetId].vol * 0.4;
        st.vel = st.vel * 0.5 + tDir * ASSETS[assetId].vol * urgency + noise;
        const tCap = ASSETS[assetId].vol * 1.5; // was 3.0 — less aggressive cap
        st.vel = Math.max(-tCap, Math.min(tCap, st.vel));
        return Math.max(prev * 0.5, prev * (1 + st.vel));
      } else if (!clearlyWinning) {
        // Close to entry — small final nudge only in last 2 seconds
        if (secsLeft <= 2.0) {
          const noise = (Math.random() - 0.5) * ASSETS[assetId].vol * 0.3;
          st.vel = st.vel * 0.5 + tDir * ASSETS[assetId].vol * 0.6 + noise;
          const tCap = ASSETS[assetId].vol * 1.0;
          st.vel = Math.max(-tCap, Math.min(tCap, st.vel));
          return Math.max(prev * 0.5, prev * (1 + st.vel));
        }
        // 2-8s left and not clearly winning — gentle bias mixed with natural movement
        st.vel = st.vel * 0.75 + tDir * ASSETS[assetId].vol * 0.25 + (Math.random() - 0.5) * ASSETS[assetId].vol * 0.5;
      }
      // Fall through to natural price for all other cases
    }
  }

  // ── Normal price movement ─────────────────────────────────────────────────
  st.modeTimer--;
  if (st.modeTimer <= 0) {
    const r = Math.random();
    if      (r < 0.15) { st.mode = 'slow';   st.modeTimer = 8  + Math.floor(Math.random() * 12); }
    else if (r < 0.75) { st.mode = 'normal';  st.modeTimer = 6  + Math.floor(Math.random() * 14); }
    else if (r < 0.92) { st.mode = 'fast';    st.modeTimer = 3  + Math.floor(Math.random() * 8);  }
    else               { st.mode = 'jump';    st.modeTimer = 1  + Math.floor(Math.random() * 3);  }
  }

  if (st.mode === 'jump') {
    st.vel = 0;
    const spike = (Math.random() - 0.5) * vol * 6.0;
    return Math.max(prev * 0.5, prev * (1 + spike));
  }

  const cfg = {
    slow:   { retain: 0.88, nudge: vol * 0.25 },
    normal: { retain: 0.78, nudge: vol * 0.70 },
    fast:   { retain: 0.65, nudge: vol * 1.60 },
  }[st.mode];

  st.vel = st.vel * cfg.retain + (Math.random() - 0.5) * cfg.nudge;
  const cap = vol * (st.mode === 'fast' ? 2.0 : 0.9);
  st.vel = Math.max(-cap, Math.min(cap, st.vel));

  // Light mean reversion
  const theta  = 0.03;
  const center = ASSETS[assetId]?.basePrice ?? prev;
  st.vel += theta * (center - prev) / prev;

  // House bias (Level 3)
  const houseBias = getHouseBias(assetId, prev, nowMs);
  st.vel += houseBias * vol;
  const biasedCap = vol * (st.mode === 'fast' ? 2.5 : 1.2);
  st.vel = Math.max(-biasedCap, Math.min(biasedCap, st.vel));

  return Math.max(prev * 0.5, prev * (1 + st.vel));
}

let tickEngineStarted = false;
export function startTickEngine() {
  if (tickEngineStarted) return;
  tickEngineStarted = true;

  // Track DB health via mongoose connection events
  import('mongoose').then(({ default: mongoose }) => {
    mongoose.connection.on('disconnected', () => {
      dbHealthy = false;
      logger.warn('📉 DB disconnected — tick engine paused, candle saves halted');
    });
    mongoose.connection.on('connected', () => {
      dbHealthy = true;
      logger.info('📈 DB reconnected — tick engine resumed');
    });
  });

  setInterval(() => {
    const now        = new Date();
    const shouldSave = dbHealthy && (Date.now() - lastSaveTime) >= SAVE_INTERVAL;

    for (const assetId of Object.keys(ASSETS)) {
      // Always update in-memory price for smooth display
      livePrice[assetId] = nextPrice(assetId, livePrice[assetId], ASSETS[assetId].vol, now.getTime());

      if (!dbHealthy) {
        // DB down — only update in-memory candle, no DB writes
        updateInMemoryCandle(assetId, livePrice[assetId], now);
        continue;
      }

      if (shouldSave) {
        // DB save (async, don't await to keep tick non-blocking)
        upsertCandle(assetId, livePrice[assetId], now).catch(() => {});
      } else {
        const bucketTime = floorToBucket(now);
        if (!openCandle[assetId] || openCandle[assetId].openTime.getTime() !== bucketTime.getTime()) {
          upsertCandle(assetId, livePrice[assetId], now).catch(() => {});
        } else {
          updateInMemoryCandle(assetId, livePrice[assetId], now);
        }
      }
    }
    if (shouldSave) lastSaveTime = Date.now();
  }, TICK_MS);

  logger.info('📈 Trade tick engine started — 15s candles, smooth price movement');
}

// Update in-memory candle only (no DB write)
function updateInMemoryCandle(assetId, price, now) {
  const bucketTime = floorToBucket(now);
  if (!openCandle[assetId] || openCandle[assetId].openTime.getTime() !== bucketTime.getTime()) {
    openCandle[assetId] = {
      assetId, openTime: bucketTime,
      open: price, high: price, low: price, close: price, isLive: true,
    };
  } else {
    const c = openCandle[assetId];
    c.close = price;
    if (price > c.high) c.high = price;
    if (price < c.low)  c.low  = price;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Deduct USD amount from user. Cuts from totalProfit first, then capital.
 *  Accepts an optional pre-fetched user object to avoid a redundant DB read. */
async function deductBalance(userId, amtUsd, prefetchedUser = null) {
  const amtBdt = usdToBdt(amtUsd);
  const user   = prefetchedUser ?? await User.findById(userId).select('totalProfit capital');
  if (!user) throw new Error('User not found');

  const profit  = user.totalProfit || 0;
  const capital = user.capital     || 0;

  let profitCut = 0, capitalCut = 0;
  if (profit >= amtBdt) {
    profitCut = amtBdt;
  } else {
    profitCut  = profit;
    capitalCut = amtBdt - profit;
  }

  if (profitCut + capitalCut > profit + capital) {
    throw new Error('Insufficient balance');
  }

  await User.findByIdAndUpdate(userId, {
    $inc: {
      totalProfit: -profitCut,
      profitTotal: -profitCut,
      capital:     -capitalCut,
    },
  });
  return { amtBdt, profitCut, capitalCut };
}

/** Credit win profit to totalProfit, and return deducted amount too */
async function creditWin(userId, amtUsd, payoutPct) {
  const amtBdt    = usdToBdt(amtUsd);
  const profitBdt = parseFloat(((amtBdt * payoutPct) / 100).toFixed(2));
  // Return the original amount + profit
  await User.findByIdAndUpdate(userId, {
    $inc: {
      totalProfit: amtBdt + profitBdt,  // return principal + profit
      profitTotal: amtBdt + profitBdt,
    },
  });
  return { profitBdt, profitUsd: bdtToUsd(profitBdt) };
}

async function getFullBalance(userId) {
  const user = await User.findById(userId).select('totalProfit capital');
  if (!user) return 0;
  return getUserTradingBalance(user);
}

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/assets
// ─────────────────────────────────────────────────────────────────────────────
router.get('/assets', auth, (req, res) => {
  res.json({
    assets: Object.entries(ASSETS).map(([id, m]) => ({
      id, label: m.label, payout: m.payout, dec: m.dec,
      livePrice: livePrice[id] ?? m.basePrice,
    })),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/price?assetId=EUR%2FUSD  (query param avoids slash encoding issues)
// Also supports legacy path param: /api/trade/price/:assetId
// ─────────────────────────────────────────────────────────────────────────────
router.get('/price', auth, (req, res) => {
  if (!dbHealthy) return res.status(503).json({ message: 'Database unavailable' });
  const id = req.query.assetId;
  const a  = ASSETS[id];
  if (!a) return res.status(404).json({ message: 'Asset not found' });
  // ts must be the exact time the price tick last ran, NOT Date.now() at response time.
  // Date.now() here would be slightly later due to HTTP processing — different per device.
  // We floor to the nearest 250ms tick interval so all devices compute the same serverBucket.
  const TICK_INTERVAL = 250;
  const tickAlignedTs = Math.floor(Date.now() / TICK_INTERVAL) * TICK_INTERVAL;
  res.json({ assetId: id, price: livePrice[id] ?? a.basePrice, ts: tickAlignedTs });
});

router.get('/price/:assetId', auth, (req, res) => {
  if (!dbHealthy) return res.status(503).json({ message: 'Database unavailable' });
  const id = decodeURIComponent(req.params.assetId).replace('_', '/');
  const a  = ASSETS[id];
  if (!a) return res.status(404).json({ message: 'Asset not found' });
  res.json({ assetId: id, price: livePrice[id] ?? a.basePrice, ts: Date.now() });
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/candles?assetId=EUR%2FUSD&limit=60
// Also supports legacy path param: /api/trade/candles/:assetId
// ─────────────────────────────────────────────────────────────────────────────
router.get('/candles', auth, async (req, res) => {
  try {
    const assetId = req.query.assetId;
    // Default 240 = 1 hour at 15s/candle. Max 5760 = 24 hours.
    const limit   = Math.min(parseInt(req.query.limit) || 240, 5760);
    if (!ASSETS[assetId]) return res.status(404).json({ message: 'Asset not found' });

    // Fetch real stored candles
    const stored = await Candle.find({ assetId }).sort({ openTime: -1 }).limit(limit).lean();
    stored.reverse();

    // Seed synthetic history if not enough real data yet
    let candles = [...stored];
    if (candles.length < limit) {
      const missing    = limit - candles.length;
      const basePrice  = candles.length > 0 ? candles[0].open : ASSETS[assetId].basePrice;
      const vol        = ASSETS[assetId].vol;
      const earliest   = candles.length > 0
        ? new Date(candles[0].openTime).getTime()
        : Date.now() - limit * CANDLE_BUCKET;

      // Use a deterministic seed based on assetId so ALL users get the SAME synthetic history
      // Simple LCG seeded by assetId hash
      let seed = 0;
      for (const ch of assetId) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
      const lcgNext = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 0xffffffff; };

      let p = basePrice;
      const synthetic = [];
      for (let i = missing; i >= 1; i--) {
        const rng1 = lcgNext(), rng2 = lcgNext(), rng3 = lcgNext();
        const open  = p;
        const close = Math.max(open * 0.7, open * (1 + (rng1 - 0.5) * vol * 2));
        const high  = Math.max(open, close) * (1 + rng2 * vol * 0.5);
        const low   = Math.min(open, close) * (1 - rng3 * vol * 0.5);
        synthetic.push({
          assetId, openTime: new Date(earliest - i * CANDLE_BUCKET),
          open, high, low, close, isLive: false,
        });
        p = close;
      }
      candles = [...synthetic, ...candles];
    }

    // Append current live candle
    const live = openCandle[assetId];
    if (live) {
      const last = candles[candles.length - 1];
      if (last && new Date(last.openTime).getTime() === live.openTime.getTime()) {
        candles[candles.length - 1] = live;
      } else {
        candles.push(live);
      }
    }

    res.json({ candles, livePrice: livePrice[assetId] });
  } catch (err) {
    logger.error('Get candles error:', err);
    res.status(500).json({ message: 'Failed to fetch candles' });
  }
});

// Legacy path param support: /api/trade/candles/:assetId
router.get('/candles/:assetId', auth, async (req, res) => {
  const assetId = decodeURIComponent(req.params.assetId).replace('_', '/');
  const limit   = Math.min(parseInt(req.query.limit) || 240, 5760);
  try {
    if (!ASSETS[assetId]) return res.status(404).json({ message: 'Asset not found' });
    const stored = await Candle.find({ assetId }).sort({ openTime: -1 }).limit(limit).lean();
    stored.reverse();
    // Attach live candle if available
    const live = openCandle[assetId];
    if (live) {
      const last = stored[stored.length - 1];
      if (last && new Date(last.openTime).getTime() === live.openTime.getTime()) {
        stored[stored.length - 1] = live;
      } else {
        stored.push(live);
      }
    }
    res.json({ candles: stored, livePrice: livePrice[assetId] });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch candles' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/balance — (capital + totalProfit) / 125 USD
// ─────────────────────────────────────────────────────────────────────────────
router.get('/balance', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('totalProfit capital profitTotal');
    if (!user) return res.status(404).json({ message: 'User not found' });
    const usd = getUserTradingBalance(user);
    res.json({
      balanceUsd:   usd,
      totalProfit:  user.totalProfit || 0,
      capital:      user.capital     || 0,
      bdtPerUsd:    BDT_PER_USD,
    });
  } catch (err) {
    logger.error('Balance error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/trade/place — place trade, deduct from profit→capital
// Expiry: 60s, 300s, 900s, 1800s, 3600s  (1m to 1h)
// ─────────────────────────────────────────────────────────────────────────────
router.post('/place', auth, async (req, res) => {
  try {
    const { assetId, direction, amount, expirySeconds } = req.body;

    if (!ASSETS[assetId])
      return res.status(400).json({ message: 'Invalid asset' });
    if (!['up', 'down'].includes(direction))
      return res.status(400).json({ message: 'Direction must be up or down' });
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 1)
      return res.status(400).json({ message: 'Minimum trade amount is $1' });
    if (amt > 10000)
      return res.status(400).json({ message: 'Maximum trade amount is $10,000' });

    const expSec = parseInt(expirySeconds);
    if (!expSec || expSec < 5 || expSec > 3600)
      return res.status(400).json({ message: 'Expiry must be between 5 seconds and 1 hour' });

    // Rate limit: max 1 trade per 2 seconds per user to prevent bot exploitation
    const recentTrades = await Trade.countDocuments({
      user: req.userId, status: 'open',
      openedAt: { $gte: new Date(Date.now() - 2000) }
    });
    if (recentTrades > 0)
      return res.status(429).json({ message: 'Please wait 2 seconds between trades' });

    const openCount = await Trade.countDocuments({ user: req.userId, status: 'open' });
    if (openCount >= 5)
      return res.status(400).json({ message: 'Maximum 5 open trades at once' });

    // Check balance
    const user = await User.findById(req.userId).select('totalProfit capital');
    if (!user) return res.status(404).json({ message: 'User not found' });
    const usdBalance = getUserTradingBalance(user);
    if (usdBalance < amt)
      return res.status(400).json({ message: `Insufficient balance. Available: $${usdBalance.toFixed(2)}` });

    // Deduct from profit first, then capital — pass pre-fetched user to avoid double read
    await deductBalance(req.userId, amt, user);

    const meta       = ASSETS[assetId];
    const entryPrice = livePrice[assetId] ?? meta.basePrice;
    const expiresAt  = new Date(Date.now() + expSec * 1000);

    const trade = new Trade({
      user: req.userId, assetId, assetLabel: meta.label,
      direction, amount: amt, payout: meta.payout, entryPrice,
      expirySeconds: expSec, openedAt: new Date(), expiresAt, status: 'open',
    });
    await trade.save();

    // ── Candle target system ──────────────────────────────────────────────────
    const SETTLE_WINDOW_MS = 30_000;
    const thisExpiry       = expiresAt.getTime();

    // FIX #4: Count distinct users currently trading (not just any existing target).
    // Check _exposure for trades from OTHER users that are still active.
    // NOTE: We count BEFORE registerTrade so the current trade isn't in the pool yet.
    const otherActiveUserIds = new Set(
      (_exposure[assetId] || [])
        .filter(t =>
          String(t.userId) !== String(req.userId) &&
          new Date(t.expiresAt).getTime() > Date.now()
        )
        .map(t => String(t.userId))
    );
    const activeUserCount = otherActiveUserIds.size + 1; // +1 for current user

    // Determine outcome via cycle BEFORE registering trade in exposure
    const cycleOutcome = await getTradeOutcome(req.userId, amt, meta.payout, activeUserCount, direction);
    const singleUserTargetDir = (cycleOutcome === 'force_win')
      ? direction
      : (direction === 'up' ? 'down' : 'up');

    // Register with house edge system AFTER outcome is decided
    registerTrade(assetId, {
      id: trade._id.toString(), direction, amount: amt,
      entryPrice, expiresAt: expiresAt.toISOString(),
      userId: req.userId, placedAt: Date.now(),
    });

    // FIX #4: hasCompeting checks for OTHER users' targets only, not same user's own targets.
    const existingTarget = _candleTargets[assetId];
    const hasCompeting = existingTarget &&
      Math.abs(existingTarget.expiresAt - thisExpiry) <= SETTLE_WINDOW_MS &&
      existingTarget.expiresAt > Date.now() &&
      existingTarget.userIds &&
      ![...existingTarget.userIds].every(uid => uid === String(req.userId));

    if (hasCompeting) {
      registerCandleTarget(trade._id.toString(), assetId, direction, entryPrice, expiresAt.toISOString(), expSec, singleUserTargetDir, amt, req.userId);
      logger.info(`🎯 Multi-user: added to window. UP=$${existingTarget.totalUp} DOWN=$${existingTarget.totalDown} → candle goes ${existingTarget.targetDir}`);
    } else {
      registerCandleTarget(trade._id.toString(), assetId, direction, entryPrice, expiresAt.toISOString(), expSec, singleUserTargetDir, amt, req.userId);
    }

    const newBalance = await getFullBalance(req.userId);
    res.status(201).json({
      message: 'Trade placed',
      balanceUsd: newBalance,
      trade: {
        id: trade._id, assetId, assetLabel: meta.label,
        direction, amount: amt, payout: meta.payout, entryPrice,
        expirySeconds: expSec, expiresAt: expiresAt.toISOString(),
        openedAt: trade.openedAt.toISOString(), status: 'open',
      },
    });
  } catch (err) {
    logger.error('Place trade error:', err);
    const msg = err.message === 'Insufficient balance' ? err.message : 'Failed to place trade';
    res.status(err.message === 'Insufficient balance' ? 400 : 500).json({ message: msg });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/trade/settle/:tradeId
// ─────────────────────────────────────────────────────────────────────────────
router.post('/settle/:tradeId', auth, async (req, res) => {
  try {
    const trade = await Trade.findOne({ _id: req.params.tradeId, user: req.userId });
    if (!trade) return res.status(404).json({ message: 'Trade not found' });
    if (trade.status !== 'open')
      return res.status(400).json({ message: 'Trade already settled', trade, won: trade.status === 'won' });

    const grace = 3000;
    if (Date.now() < trade.expiresAt.getTime() - grace) {
      const remaining = Math.ceil((trade.expiresAt.getTime() - Date.now()) / 1000);
      return res.status(400).json({ message: `Trade expires in ${remaining}s`, remaining });
    }

    // FIX #5: Use the candle close price (which was steered), not the live tick.
    // The candle steering system drove candle.close to the correct outcome.
    // Reading the instantaneous live tick disconnects steering from settlement.
    const liveCandle  = openCandle[trade.assetId];
    const closePrice  = liveCandle ? liveCandle.close : (livePrice[trade.assetId] ?? trade.entryPrice);

    // Outcome = natural price check — candle was steered to the correct position
    const won = trade.direction === 'up'
      ? closePrice > trade.entryPrice
      : closePrice < trade.entryPrice;

    // Clean up candle target for this trade
    clearCandleTarget(trade._id.toString(), trade.assetId);

    let profitUsd = 0;
    if (won) {
      const { profitUsd: pu } = await creditWin(req.userId, trade.amount, trade.payout);
      profitUsd = pu;
    }
    // If lost: amount was already cut at placement — nothing more to deduct

    trade.status     = won ? 'won' : 'lost';
    trade.closePrice = closePrice;
    trade.profit     = profitUsd;
    await trade.save();

    // Remove from house edge tracking
    unregisterTrade(trade.assetId, trade._id.toString());

    const newBalance = await getFullBalance(req.userId);
    res.json({
      message:     won ? 'Trade won!' : 'Trade lost',
      won,
      profit:      profitUsd,
      closePrice,
      balanceUsd:  newBalance,
      trade: { id: trade._id, status: trade.status, closePrice, profit: profitUsd },
    });
  } catch (err) {
    logger.error('Settle trade error:', err);
    res.status(500).json({ message: 'Failed to settle trade' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/open
// ─────────────────────────────────────────────────────────────────────────────
router.get('/open', auth, async (req, res) => {
  try {
    const trades = await Trade.find({ user: req.userId, status: 'open' }).sort({ openedAt: -1 }).lean();
    res.json({ trades: trades.map(t => ({ ...t, livePrice: livePrice[t.assetId] ?? t.entryPrice })) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch open trades' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/trade/history
// ─────────────────────────────────────────────────────────────────────────────
router.get('/history', auth, async (req, res) => {
  try {
    const trades = await Trade
      .find({ user: req.userId, status: { $in: ['won', 'lost'] } })
      .sort({ openedAt: -1 }).limit(50).lean();
    res.json({ trades });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch trade history' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DEMO trade endpoints — no real money, stored in memory only
// ─────────────────────────────────────────────────────────────────────────────
const DEMO_BALANCE_USD = 10000;
const demoTrades = new Map(); // userId → [{ id, ...trade, expiresAt, status }]

router.post('/demo/place', auth, async (req, res) => {
  try {
    const { assetId, direction, amount, expirySeconds } = req.body;
    if (!ASSETS[assetId]) return res.status(400).json({ message: 'Invalid asset' });
    if (!['up', 'down'].includes(direction)) return res.status(400).json({ message: 'Invalid direction' });
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 1) return res.status(400).json({ message: 'Min amount $1' });
    const expSec = parseInt(expirySeconds);
    if (!expSec || expSec < 5 || expSec > 3600)
      return res.status(400).json({ message: 'Expiry must be between 5 seconds and 1 hour' });

    const meta = ASSETS[assetId];
    const id   = `demo_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const t    = {
      id, assetId, assetLabel: meta.label, direction, amount: amt,
      payout: meta.payout, entryPrice: livePrice[assetId] ?? meta.basePrice,
      expirySeconds: expSec, expiresAt: new Date(Date.now() + expSec * 1000).toISOString(),
      openedAt: new Date().toISOString(), status: 'open',
    };
    const list = demoTrades.get(req.userId) ?? [];
    list.push(t);
    demoTrades.set(req.userId, list);

    res.status(201).json({ message: 'Demo trade placed', trade: t });
  } catch (err) {
    res.status(500).json({ message: 'Failed to place demo trade' });
  }
});

router.post('/demo/settle/:demoId', auth, (req, res) => {
  try {
    const list  = demoTrades.get(req.userId) ?? [];
    const trade = list.find(t => t.id === req.params.demoId);
    if (!trade) return res.status(404).json({ message: 'Demo trade not found' });
    if (trade.status !== 'open') return res.status(400).json({ message: 'Already settled', trade, won: trade.status === 'won' });

    const closePrice = livePrice[trade.assetId] ?? trade.entryPrice;
    const won        = trade.direction === 'up' ? closePrice > trade.entryPrice : closePrice < trade.entryPrice;
    const profitUsd  = won ? parseFloat(((trade.amount * trade.payout) / 100).toFixed(2)) : 0;

    trade.status     = won ? 'won' : 'lost';
    trade.closePrice = closePrice;
    trade.profit     = profitUsd;

    res.json({ message: won ? 'Demo won!' : 'Demo lost', won, profit: profitUsd, closePrice, trade });
  } catch (err) {
    res.status(500).json({ message: 'Failed to settle demo trade' });
  }
});

router.get('/demo/open', auth, (req, res) => {
  const list = (demoTrades.get(req.userId) ?? []).filter(t => t.status === 'open');
  res.json({ trades: list.map(t => ({ ...t, livePrice: livePrice[t.assetId] ?? t.entryPrice })) });
});

export default router;
