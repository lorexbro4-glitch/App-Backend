import express from 'express';
const router = express.Router();
import auth from '../middleware/auth.js';
import mongoose from 'mongoose';
import pushNotificationService from '../services/pushNotificationService.js';
import { notifySupportMessage } from '../services/telegramNotificationService.js';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Configure multer for support chat file uploads
const chatStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/support';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'support-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const chatUpload = multer({
  storage: chatStorage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit for chat files
  },
  fileFilter: (req, file, cb) => {
    // Allow images and common document types
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = file.mimetype.startsWith('image/') || 
                     file.mimetype.startsWith('application/');
    
    if (extname || mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('অসমর্থিত ফাইল টাইপ'));
    }
  }
});

// Support Ticket Schema
const supportTicketSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String, enum: ['open', 'in_progress', 'resolved', 'closed'], default: 'open' },
  priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium' },
  subject: { type: String, default: 'সাপোর্ট টিকেট' },
  lastMessageAt: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now },
  closedAt: { type: Date },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

const SupportTicket = mongoose.model('SupportTicket', supportTicketSchema);

// Support Message Schema
const supportMessageSchema = new mongoose.Schema({
  ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'SupportTicket', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  sender: { type: String, enum: ['user', 'admin', 'system'], required: true },
  message: { type: String },
  messageType: { type: String, enum: ['text', 'image', 'file'], default: 'text' },
  fileUrl: { type: String },
  fileName: { type: String },
  fileSize: { type: Number },
  reactions: [{
    emoji: String,
    userId: mongoose.Schema.Types.ObjectId,
    createdAt: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now },
  read: { type: Boolean, default: false },
  readAt: { type: Date }
});

const SupportMessage = mongoose.model('SupportMessage', supportMessageSchema);

// Typing Status Schema
const typingStatusSchema = new mongoose.Schema({
  ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'SupportTicket', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  isTyping: { type: Boolean, default: false },
  updatedAt: { type: Date, default: Date.now }
});

const TypingStatus = mongoose.model('TypingStatus', typingStatusSchema);

// Upload Support Chat File
router.post('/upload-file', auth, chatUpload.single('file'), async (req, res) => {
  try {
    console.log('=== SUPPORT FILE UPLOAD REQUEST RECEIVED ===');
    console.log('User ID:', req.userId);
    console.log('File received:', req.file ? 'YES' : 'NO');
    
    if (req.file) {
      console.log('File details:', {
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        path: req.file.path
      });
    }
    
    if (!req.file) {
      console.error('No file in request');
      return res.status(400).json({ message: 'ফাইল আপলোড করুন' });
    }

    // Return the file path (relative to server root)
    const fileUrl = `/${req.file.path.replace(/\\/g, '/')}`;
    
    console.log('File uploaded successfully, returning URL:', fileUrl);
    
    res.json({
      message: 'ফাইল সফলভাবে আপলোড হয়েছে',
      fileUrl,
      fileName: req.file.originalname,
      fileSize: req.file.size
    });
    
    console.log('=== SUPPORT FILE UPLOAD COMPLETE ===');
  } catch (error) {
    console.error('=== SUPPORT FILE UPLOAD ERROR ===');
    console.error('Upload support file error:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({ message: 'ফাইল আপলোড করতে ব্যর্থ', error: error.message });
  }
});

// Get or create ticket for user
router.get('/ticket', auth, async (req, res) => {
  try {
    let ticket = await SupportTicket.findOne({ 
      userId: req.userId,
      status: { $in: ['open', 'in_progress'] }
    });

    if (!ticket) {
      ticket = new SupportTicket({
        userId: req.userId,
        subject: 'সাপোর্ট টিকেট'
      });
      await ticket.save();
      
      // NO auto-welcome message here - will be sent when user sends first message
    }

    res.json({ ticket });
  } catch (error) {
    console.error('Get ticket error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get all messages for user's ticket
router.get('/messages', auth, async (req, res) => {
  try {
    const ticket = await SupportTicket.findOne({ 
      userId: req.userId,
      status: { $in: ['open', 'in_progress'] }
    });

    if (!ticket) {
      return res.json({ messages: [] });
    }

    const messages = await SupportMessage.find({ ticketId: ticket._id })
      .sort({ createdAt: 1 })
      .limit(500);

    // Mark admin messages as read
    await SupportMessage.updateMany(
      { ticketId: ticket._id, sender: { $in: ['admin', 'system'] }, read: false },
      { read: true, readAt: new Date() }
    );

    res.json({ messages, ticketId: ticket._id });
  } catch (error) {
    console.error('Get support messages error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Send a message
router.post('/messages', auth, async (req, res) => {
  try {
    const { message, messageType, fileUrl, fileName, fileSize } = req.body;

    if (messageType === 'text' && (!message || !message.trim())) {
      return res.status(400).json({ message: 'মেসেজ খালি হতে পারবে না' });
    }

    // Get or create ticket
    let ticket = await SupportTicket.findOne({ 
      userId: req.userId,
      status: { $in: ['open', 'in_progress'] }
    });

    let isNewTicket = false;
    if (!ticket) {
      ticket = new SupportTicket({ userId: req.userId });
      await ticket.save();
      isNewTicket = true;
    }

    // Check if this is the first user message in this ticket
    const messageCount = await SupportMessage.countDocuments({ 
      ticketId: ticket._id,
      sender: 'user'
    });
    const isFirstMessage = messageCount === 0;

    const newMessage = new SupportMessage({
      ticketId: ticket._id,
      userId: req.userId,
      sender: 'user',
      message: message?.trim(),
      messageType: messageType || 'text',
      fileUrl,
      fileName,
      fileSize
    });

    await newMessage.save();

    // ── Off-hours auto-reply (9 PM – 9 AM Bangladesh time, UTC+6) ──────────────
    const bdHour = new Date(Date.now() + 6 * 60 * 60 * 1000).getUTCHours();
    const isOffHours = bdHour >= 21 || bdHour < 9; // 9 PM to 9 AM

    if (isOffHours) {
      // Only send once per off-hours window — check if we already sent one in the last 8 hours
      const recentOffHoursReply = await SupportMessage.findOne({
        ticketId: ticket._id,
        sender: 'system',
        message: { $regex: 'সকাল ৯টা' },
        createdAt: { $gte: new Date(Date.now() - 8 * 60 * 60 * 1000) }
      });

      if (!recentOffHoursReply) {
        const offHoursMessage = new SupportMessage({
          ticketId: ticket._id,
          userId: req.userId,
          sender: 'system',
          message: 'আপনার বার্তাটি পেয়েছি। আমাদের সাপোর্ট সেবা প্রতিদিন সকাল ৯টা থেকে রাত ৯টা পর্যন্ত চালু থাকে। আমাদের টিম সকাল ৯টার পর আপনার সাথে যোগাযোগ করবে। অসুবিধার জন্য আন্তরিকভাবে দুঃখিত।',
          messageType: 'text',
          read: false
        });
        await offHoursMessage.save();
      }
    }
    // ──────────────────────────────────────────────────────────────────────────

    // Send Telegram notification to admin
    try {
      const User = mongoose.model('User');
      const sender = await User.findById(req.userId).select('name phone');
      const preview = messageType === 'text' ? (message?.substring(0, 100) || '') : `[${messageType}]`;
      await notifySupportMessage(sender?.name, sender?.phone, preview, isFirstMessage);
    } catch (tgErr) {
      console.error('Telegram support notification failed:', tgErr.message);
    }

    // If this is the first message, send auto-welcome message and notify admin
    if (isFirstMessage) {
      const welcomeMessage = new SupportMessage({
        ticketId: ticket._id,
        userId: req.userId,
        sender: 'system',
        message: 'আমাদের এজেন্ট দ্রুত আপনার সাথে যোগাযোগ করবেন। অনুগ্রহ করে অপেক্ষা করুন।',
        messageType: 'text',
        read: true
      });
      await welcomeMessage.save();

      // Notify admin about new support ticket
      try {
        const User = mongoose.model('User');
        const user = await User.findById(req.userId);
        const messagePreview = message?.substring(0, 100) || 'New ticket';
        
        await pushNotificationService.sendToAdmins({
          title: 'নতুন সাপোর্ট টিকেট',
          body: `${user.name || user.phone}: ${messagePreview}`,
          data: {
            type: 'support_ticket',
            userId: req.userId,
            ticketId: ticket._id.toString(),
            messagePreview
          }
        });
        
        console.log('Admin notification sent for new support ticket');
      } catch (notifError) {
        console.error('Failed to send admin notification:', notifError);
        // Don't fail the ticket creation if notification fails
      }
    }

    // Update ticket last message time
    ticket.lastMessageAt = new Date();
    await ticket.save();

    // Send push notification to agents and admins
    const User = mongoose.model('User');
    const Agent = mongoose.model('Agent');
    const user = await User.findById(req.userId);
    
    // Notify admins
    try {
      const admins = await User.find({ role: 'admin', pushToken: { $exists: true, $ne: null } });
      for (const admin of admins) {
        if (admin.pushToken && admin._id) {
          await pushNotificationService.sendToUser(admin._id, {
            title: 'নতুন সাপোর্ট মেসেজ',
            body: `${user.name || user.phone}: ${message?.substring(0, 50) || 'ফাইল পাঠিয়েছে'}`,
            data: { type: 'support_message', ticketId: ticket._id.toString() }
          });
        }
      }
    } catch (notifError) {
      console.error('Failed to notify admins:', notifError);
    }

    // Notify agents
    try {
      const agents = await Agent.find({ isActive: true, pushToken: { $exists: true, $ne: null } });
      for (const agent of agents) {
        if (agent.pushToken && agent._id) {
          await pushNotificationService.sendToAgent(agent._id, {
            title: `নতুন মেসেজ - ${user.name || user.phone}`,
            body: message?.substring(0, 100) || 'ফাইল পাঠিয়েছে',
            data: { type: 'support_message', ticketId: ticket._id.toString() }
          });
        }
      }
    } catch (notifError) {
      console.error('Failed to notify agents:', notifError);
    }

    res.json({ message: 'মেসেজ পাঠানো হয়েছে', data: newMessage });
  } catch (error) {
    console.error('Send support message error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Update typing status
router.post('/typing', auth, async (req, res) => {
  try {
    const { ticketId, isTyping } = req.body;

    await TypingStatus.findOneAndUpdate(
      { ticketId, userId: req.userId },
      { isTyping, updatedAt: new Date() },
      { upsert: true }
    );

    res.json({ success: true });
  } catch (error) {
    console.error('Update typing status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get typing status
router.get('/typing/:ticketId', auth, async (req, res) => {
  try {
    const typingStatuses = await TypingStatus.find({
      ticketId: req.params.ticketId,
      userId: { $ne: req.userId },
      isTyping: true,
      updatedAt: { $gte: new Date(Date.now() - 5000) } // Last 5 seconds
    }).populate('userId', 'name role');

    res.json({ typingStatuses });
  } catch (error) {
    console.error('Get typing status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Add reaction to message
router.post('/messages/:messageId/reaction', auth, async (req, res) => {
  try {
    const { emoji } = req.body;
    const message = await SupportMessage.findById(req.params.messageId);

    if (!message) {
      return res.status(404).json({ message: 'মেসেজ পাওয়া যায়নি' });
    }

    // Check if user already reacted with this emoji
    const existingReaction = message.reactions.find(
      r => r.userId.toString() === req.userId && r.emoji === emoji
    );

    if (existingReaction) {
      // Remove reaction
      message.reactions = message.reactions.filter(
        r => !(r.userId.toString() === req.userId && r.emoji === emoji)
      );
    } else {
      // Add reaction
      message.reactions.push({
        emoji,
        userId: req.userId,
        createdAt: new Date()
      });
    }

    await message.save();
    res.json({ message: 'রিঅ্যাকশন আপডেট হয়েছে', data: message });
  } catch (error) {
    console.error('Add reaction error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Search messages
router.get('/search', auth, async (req, res) => {
  try {
    const { query } = req.query;

    if (!query || query.trim().length < 2) {
      return res.status(400).json({ message: 'সার্চ কোয়েরি কমপক্ষে ২ অক্ষরের হতে হবে' });
    }

    const ticket = await SupportTicket.findOne({ 
      userId: req.userId,
      status: { $in: ['open', 'in_progress'] }
    });

    if (!ticket) {
      return res.json({ messages: [] });
    }

    const messages = await SupportMessage.find({
      ticketId: ticket._id,
      message: { $regex: query.trim(), $options: 'i' }
    }).sort({ createdAt: -1 }).limit(50);

    res.json({ messages });
  } catch (error) {
    console.error('Search messages error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Export chat history
router.get('/export', auth, async (req, res) => {
  try {
    const ticket = await SupportTicket.findOne({ userId: req.userId })
      .sort({ createdAt: -1 });

    if (!ticket) {
      return res.status(404).json({ message: 'কোন টিকেট পাওয়া যায়নি' });
    }

    const messages = await SupportMessage.find({ ticketId: ticket._id })
      .sort({ createdAt: 1 });

    const User = mongoose.model('User');
    const user = await User.findById(req.userId);

    const exportData = {
      ticket: {
        id: ticket._id,
        status: ticket.status,
        priority: ticket.priority,
        createdAt: ticket.createdAt,
        closedAt: ticket.closedAt
      },
      user: {
        name: user.name,
        phone: user.phone,
        email: user.email
      },
      messages: messages.map(msg => ({
        sender: msg.sender,
        message: msg.message,
        messageType: msg.messageType,
        fileUrl: msg.fileUrl,
        fileName: msg.fileName,
        createdAt: msg.createdAt,
        read: msg.read
      })),
      exportedAt: new Date()
    };

    res.json(exportData);
  } catch (error) {
    console.error('Export chat error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Admin: Get all support conversations
router.get('/admin/conversations', auth, async (req, res) => {
  try {
    // Check if user is admin
    const User = mongoose.model('User');
    const user = await User.findById(req.userId);
    
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }

    const { status, priority } = req.query;
    const filter = {};
    
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    const tickets = await SupportTicket.find(filter)
      .populate('userId', 'name phone email')
      .sort({ lastMessageAt: -1 });

    // Get unread count for each ticket
    const ticketsWithUnread = await Promise.all(
      tickets.map(async (ticket) => {
        const unreadCount = await SupportMessage.countDocuments({
          ticketId: ticket._id,
          sender: 'user',
          read: false
        });

        const lastMessage = await SupportMessage.findOne({ ticketId: ticket._id })
          .sort({ createdAt: -1 });

        return {
          ...ticket.toObject(),
          unreadCount,
          lastMessage: lastMessage?.message || '',
          lastMessageType: lastMessage?.messageType || 'text'
        };
      })
    );

    res.json({ tickets: ticketsWithUnread });
  } catch (error) {
    console.error('Get conversations error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Admin: Get messages for a specific ticket
router.get('/admin/messages/:ticketId', auth, async (req, res) => {
  try {
    // Check if user is admin
    const User = mongoose.model('User');
    const user = await User.findById(req.userId);
    
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }

    const ticket = await SupportTicket.findById(req.params.ticketId)
      .populate('userId', 'name phone email');

    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    const messages = await SupportMessage.find({ ticketId: req.params.ticketId })
      .sort({ createdAt: 1 });

    // Mark user messages as read
    await SupportMessage.updateMany(
      { ticketId: req.params.ticketId, sender: 'user', read: false },
      { read: true, readAt: new Date() }
    );

    res.json({ ticket, messages });
  } catch (error) {
    console.error('Get ticket messages error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Admin: Send reply to user
router.post('/admin/messages/:ticketId', auth, async (req, res) => {
  try {
    // Check if user is admin
    const User = mongoose.model('User');
    const adminUser = await User.findById(req.userId);
    
    if (!adminUser || adminUser.role !== 'admin') {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }

    const { message, messageType, fileUrl, fileName, fileSize } = req.body;

    if (messageType === 'text' && (!message || !message.trim())) {
      return res.status(400).json({ message: 'মেসেজ খালি হতে পারবে না' });
    }

    const ticket = await SupportTicket.findById(req.params.ticketId);
    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    const newMessage = new SupportMessage({
      ticketId: req.params.ticketId,
      userId: ticket.userId,
      sender: 'admin',
      message: message?.trim(),
      messageType: messageType || 'text',
      fileUrl,
      fileName,
      fileSize,
      read: true
    });

    await newMessage.save();

    // Update ticket
    ticket.lastMessageAt = new Date();
    if (ticket.status === 'open') {
      ticket.status = 'in_progress';
    }
    await ticket.save();

    // Send push notification to user
    const user = await User.findById(ticket.userId);
    
    try {
      if (user && user._id) {
        await pushNotificationService.sendToUser(user._id, {
          title: 'সাপোর্ট টিম থেকে নতুন মেসেজ',
          body: message?.substring(0, 100) || 'আপনি একটি নতুন মেসেজ পেয়েছেন',
          data: { type: 'support_reply', ticketId: ticket._id.toString() }
        });
      }
    } catch (notifError) {
      console.error('Failed to send notification to user:', notifError);
    }

    res.json({ message: 'রিপ্লাই পাঠানো হয়েছে', data: newMessage });
  } catch (error) {
    console.error('Send admin reply error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Admin: Update ticket status
router.patch('/admin/ticket/:ticketId/status', auth, async (req, res) => {
  try {
    const User = mongoose.model('User');
    const user = await User.findById(req.userId);
    
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }

    const { status } = req.body;
    const ticket = await SupportTicket.findById(req.params.ticketId);

    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    ticket.status = status;
    if (status === 'closed' || status === 'resolved') {
      ticket.closedAt = new Date();
    }
    await ticket.save();

    // Send system message
    const systemMessage = new SupportMessage({
      ticketId: ticket._id,
      userId: ticket.userId,
      sender: 'system',
      message: `টিকেট স্ট্যাটাস আপডেট: ${status}`,
      messageType: 'text',
      read: true
    });
    await systemMessage.save();

    res.json({ message: 'স্ট্যাটাস আপডেট হয়েছে', ticket });
  } catch (error) {
    console.error('Update ticket status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Admin: Update ticket priority
router.patch('/admin/ticket/:ticketId/priority', auth, async (req, res) => {
  try {
    const User = mongoose.model('User');
    const user = await User.findById(req.userId);
    
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }

    const { priority } = req.body;
    const ticket = await SupportTicket.findById(req.params.ticketId);

    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    ticket.priority = priority;
    await ticket.save();

    res.json({ message: 'প্রায়োরিটি আপডেট হয়েছে', ticket });
  } catch (error) {
    console.error('Update ticket priority error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
