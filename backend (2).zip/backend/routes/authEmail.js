import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import User from '../models/User.js';
import { generateOTP, sendVerificationEmail, sendPasswordResetEmail, sendWelcomeEmail } from '../services/emailService.js';
import rateLimiter from '../services/rateLimiter.js';
import pushNotificationService from '../services/pushNotificationService.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production';

// Wake-up ping — keeps Replit warm, used on app startup
router.get('/ping', (req, res) => res.json({ ok: true }));

// Check Email Availability
router.get('/email/check-email', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) {
      return res.status(400).json({ available: false, reason: 'Email is required' });
    }
    const trimmed = email.trim().toLowerCase();
    const gmailRegex = /^[a-zA-Z0-9._%+\-]+@gmail\.com$/i;
    if (!gmailRegex.test(trimmed)) {
      return res.json({ available: false, reason: 'Only @gmail.com emails are accepted' });
    }
    const existing = await User.findOne({ email: trimmed });
    if (existing && existing.emailVerified) {
      return res.json({ available: false, taken: true });
    }
    return res.json({ available: true });
  } catch (error) {
    console.error('Check email error:', error);
    res.status(500).json({ available: false, reason: 'Server error' });
  }
});

// Register with Email
router.post('/email/register', async (req, res) => {
  try {
    console.log('🔵 ===== EMAIL REGISTRATION REQUEST =====');
    console.log('🔵 Request body:', JSON.stringify(req.body, null, 2));
    
    const { email, password, username, name, phone } = req.body;

    // Validate input
    if (!email || !password || !username) {
      console.log('❌ Missing email, password, or username');
      return res.status(400).json({ message: 'Email, password, and username are required' });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      console.log('❌ Invalid email format:', email);
      return res.status(400).json({ message: 'Invalid email format' });
    }

    console.log('✅ Email format valid');

    // Validate username
    const trimmedUsername = username.trim().toLowerCase();
    if (trimmedUsername.length < 5) {
      console.log('❌ Username too short:', trimmedUsername);
      return res.status(400).json({ message: 'Username must be at least 5 characters' });
    }

    if (trimmedUsername.length > 15) {
      console.log('❌ Username too long:', trimmedUsername);
      return res.status(400).json({ message: 'Username cannot exceed 15 characters' });
    }

    if (!/^[a-z0-9_]+$/.test(trimmedUsername)) {
      console.log('❌ Invalid username format:', trimmedUsername);
      return res.status(400).json({ message: 'Username can only contain lowercase letters, numbers, and underscores' });
    }

    console.log('✅ Username format valid');

    // Check if user exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      console.log('⚠️ User already exists:', email);
      // If user exists but email is NOT verified, allow re-registration
      if (!existingUser.emailVerified) {
        console.log('🔵 User exists but not verified, deleting old record');
        await User.findByIdAndDelete(existingUser._id);
        console.log('✅ Old unverified user deleted, proceeding with new registration');
      } else {
        // Email is verified, don't allow re-registration
        console.log('❌ Email already registered and verified');
        return res.status(400).json({ message: 'Email already registered' });
      }
    }

    console.log('✅ Email available for registration');

    // Check if username exists — ignore unverified accounts (they haven't completed registration)
    const existingUsername = await User.findOne({ username: trimmedUsername });
    if (existingUsername) {
      if (!existingUsername.emailVerified) {
        // Unverified account is holding this username — delete it so the new user can claim it
        console.log('🔵 Username taken by unverified account, deleting stale record:', existingUsername._id);
        await User.findByIdAndDelete(existingUsername._id);
        console.log('✅ Stale unverified account deleted, username is now free');
      } else {
        console.log('❌ Username already taken:', trimmedUsername);
        return res.status(400).json({ message: 'Username already taken' });
      }
    }

    console.log('✅ Username available');

    // Check if phone exists (if provided)
    if (phone) {
      console.log('🔵 Checking phone number:', phone);
      const existingPhone = await User.findOne({ phone });
      if (existingPhone) {
        console.log('❌ Phone number already registered');
        return res.status(400).json({ message: 'Phone number already registered' });
      }
      console.log('✅ Phone number available');
    }

    // Generate OTP
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    console.log('🔵 Generated OTP:', otp);
    console.log('🔵 OTP expires at:', otpExpires);

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log('✅ Password hashed');

    // Validate referredBy if provided - FIXED FOR OBJECTID
    let referredById = null;
    if (req.body.referredBy) {
      console.log('🔵 Processing referral code:', req.body.referredBy);
      const referralInput = req.body.referredBy.trim();
      
      // Check if it's a full 24-character ObjectId
      if (/^[0-9a-fA-F]{24}$/.test(referralInput)) {
        console.log('✅ Full 24-char ObjectId detected');
        try {
          const referrer = await User.findById(referralInput);
          if (referrer) {
            referredById = referralInput;
            console.log('✅ Referrer found with full ID');
          } else {
            console.log('❌ No referrer found for full ID:', referralInput);
            return res.status(400).json({ message: 'Invalid referral code' });
          }
        } catch (error) {
          console.error('❌ Error with full ID lookup:', error);
          return res.status(400).json({ message: 'Invalid referral code' });
        }
      }
      // Check if it's an 8-character referral code
      else if (/^[0-9a-fA-F]{8}$/i.test(referralInput)) {
        console.log('🔵 8-char referral code detected, looking up referrer...');
        
        // MongoDB _id is ObjectId type, not String, so regex won't work
        // Instead, we need to find all users and check if their ID starts with this code
        // This is less efficient but necessary for ObjectId fields
        try {
          // Get all users (we'll optimize this later if needed)
          const allUsers = await User.find({}, '_id').lean();
          console.log(`🔵 Checking ${allUsers.length} users for matching referral code`);
          
          // Find user whose ID starts with the referral code
          const referrer = allUsers.find(u => 
            u._id.toString().toLowerCase().startsWith(referralInput.toLowerCase())
          );
          
          if (referrer) {
            console.log('✅ Referrer found:', referrer._id.toString());
            referredById = referrer._id;
          } else {
            console.log('❌ No referrer found for code:', referralInput);
            return res.status(400).json({ message: 'Invalid referral code' });
          }
        } catch (error) {
          console.error('❌ Error looking up referral code:', error);
          return res.status(400).json({ message: 'Invalid referral code' });
        }
      } else {
        console.log('❌ Invalid referral code format');
        return res.status(400).json({ message: 'Invalid referral code format' });
      }
    }

    console.log('🔵 Creating user with referredBy:', referredById);

    // Create user - email NOT verified yet, must verify OTP
    const user = new User({
      email: email.toLowerCase(),
      username: trimmedUsername,
      password: hashedPassword,
      name: name || '',
      phone: phone || undefined, // Use undefined instead of empty string to avoid duplicate key errors
      emailVerified: false, // User must verify OTP first
      emailVerificationToken: otp,
      emailVerificationExpires: otpExpires,
      authProvider: 'email',
      referredBy: referredById
    });

    await user.save();
    console.log('✅ User saved to database:', user._id.toString());

    // If referral was used, increment referrer's count
    if (referredById) {
      console.log('🔵 Incrementing referrer count for:', referredById.toString());
      await User.findByIdAndUpdate(referredById, { 
        $inc: { referralCount: 1 } 
      });
      console.log('✅ Referrer count incremented');
    }

    // Record email attempt for rate limiting
    rateLimiter.recordEmailAttempt(user._id.toString());
    console.log('✅ Email attempt recorded for rate limiting');

    // Send verification email
    console.log('📧 Sending verification email...');
    const emailResult = await sendVerificationEmail(email, otp, name);
    
    if (!emailResult.success) {
      console.error('❌ Email send failed:', emailResult.error);
      // Delete user if email fails
      await User.findByIdAndDelete(user._id);
      console.log('🗑️ User deleted due to email failure');
      return res.status(500).json({ message: 'Failed to send verification email' });
    }

    console.log('✅ Verification email sent successfully');
    console.log('🔵 ===== REGISTRATION COMPLETED =====');

    res.status(201).json({
      message: 'Registration successful! Please check your email for verification code.',
      userId: user._id,
      email: user.email,
      requiresVerification: true
    });
  } catch (error) {
    console.error('❌ ===== REGISTRATION ERROR =====');
    console.error('❌ Error:', error);
    console.error('❌ Stack:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// Verify Email OTP
router.post('/email/verify-email', async (req, res) => {
  console.log('🔵 ===== VERIFY EMAIL OTP REQUEST =====');
  console.log('🔵 Request body:', req.body);
  
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      console.log('❌ Missing email or OTP');
      return res.status(400).json({ message: 'Email and OTP are required' });
    }

    // Trim and normalize OTP
    const normalizedOTP = String(otp).trim();
    console.log('🔵 Normalized OTP from request:', normalizedOTP);

    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      console.log('❌ User not found for email:', email);
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('✅ User found:', user.email);
    console.log('🔵 Stored OTP in database:', user.emailVerificationToken);
    console.log('🔵 OTP expires at:', user.emailVerificationExpires);
    console.log('🔵 Current time:', new Date());

    // Check if already verified
    if (user.emailVerified) {
      console.log('❌ Email already verified');
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Check expiration first
    if (new Date() > user.emailVerificationExpires) {
      console.log('❌ OTP expired');
      return res.status(400).json({ message: 'OTP expired. Please request a new one.' });
    }

    // Check OTP - normalize both sides
    const storedOTP = String(user.emailVerificationToken).trim();
    console.log('🔵 Comparing OTPs:');
    console.log('  - Received:', normalizedOTP, '(length:', normalizedOTP.length, ')');
    console.log('  - Stored:', storedOTP, '(length:', storedOTP.length, ')');
    console.log('  - Match:', storedOTP === normalizedOTP);

    if (storedOTP !== normalizedOTP) {
      console.log('❌ OTP mismatch');
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    console.log('✅ OTP verified successfully');

    // Verify email
    user.emailVerified = true;
    user.emailVerificationToken = null;
    user.emailVerificationExpires = null;
    await user.save();

    console.log('✅ User email verified and saved');

    // Send welcome email
    await sendWelcomeEmail(user.email, user.name);

    // Create registration notification
    try {
      await pushNotificationService.createAndSendNotification(
        user._id,
        'registration',
        'স্বাগতম!',
        `${user.name || 'ব্যবহারকারী'}, YFBD তে আপনাকে স্বাগতম! এখন বিনিয়োগ শুরু করুন।`
      );
      console.log('✅ Registration notification sent');
    } catch (notifError) {
      console.error('⚠️ Failed to send registration notification:', notifError);
      // Don't fail the registration if notification fails
    }

    // If user was referred, notify the referrer
    if (user.referredBy) {
      try {
        await pushNotificationService.createAndSendNotification(
          user.referredBy,
          'referral_success',
          'নতুন রেফারেল!',
          `${user.name || 'একজন নতুন ব্যবহারকারী'} আপনার রেফারেল লিংক ব্যবহার করে যোগ দিয়েছেন!`
        );
        console.log('✅ Referral success notification sent to referrer');
      } catch (notifError) {
        console.error('⚠️ Failed to send referral notification:', notifError);
      }
    }

    // Generate token
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '30d' });

    console.log('✅ Token generated, sending response');
    console.log('🔵 ===== VERIFY EMAIL OTP COMPLETED =====');

    res.json({
      message: 'Email verified successfully!',
      token,
      userId: user._id,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        phone: user.phone,
        emailVerified: user.emailVerified
      }
    });
  } catch (error) {
    console.error('❌ Verify email error:', error);
    console.error('❌ Error stack:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// Resend Verification OTP
router.post('/email/resend-otp', async (req, res) => {
  console.log('🔵 ===== RESEND OTP REQUEST =====');
  console.log('🔵 Request body:', req.body);
  
  try {
    const { email } = req.body;

    if (!email) {
      console.log('❌ No email provided');
      return res.status(400).json({ message: 'Email is required' });
    }

    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      console.log('❌ User not found for email:', email);
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('✅ User found:', user.email);

    // Check if already verified
    if (user.emailVerified) {
      console.log('❌ Email already verified');
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Check rate limit (max 3 emails per hour per user)
    const rateLimit = rateLimiter.checkEmailLimit(user._id.toString());
    console.log('🔵 Rate limit check:', rateLimit);
    
    if (!rateLimit.allowed) {
      console.log('❌ Rate limit exceeded');
      return res.status(429).json({ 
        message: `Too many email requests. Please try again in ${Math.ceil(rateLimit.retryAfter / 60)} minutes.`,
        retryAfter: rateLimit.retryAfter
      });
    }

    // Generate new OTP
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000);

    console.log('🔵 Generated new OTP:', otp);
    console.log('🔵 OTP expires at:', otpExpires);

    user.emailVerificationToken = otp;
    user.emailVerificationExpires = otpExpires;
    await user.save();

    console.log('✅ OTP saved to database');

    // Record email attempt
    rateLimiter.recordEmailAttempt(user._id.toString());

    // Send email
    console.log('📧 Sending verification email to:', user.email);
    const emailResult = await sendVerificationEmail(user.email, otp, user.name);
    
    console.log('📧 Email result:', emailResult);
    
    if (!emailResult.success) {
      console.error('❌ Failed to send email:', emailResult.error);
      return res.status(500).json({ message: 'Failed to send email' });
    }

    console.log('✅ Verification email sent successfully');
    console.log('🔵 ===== RESEND OTP COMPLETED =====');
    
    res.json({ message: 'Verification code sent to your email' });
  } catch (error) {
    console.error('❌ Resend OTP error:', error);
    console.error('❌ Error stack:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// Login with Email
router.post('/email/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ message: 'Email/Username and password are required' });
    }

    // Find user by email or username
    const emailOrUsername = email.toLowerCase().trim();
    const user = await User.findOne({
      $or: [
        { email: emailOrUsername },
        { username: emailOrUsername }
      ]
    });
    
    if (!user) {
      return res.status(400).json({ message: 'Invalid email/username or password' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email/username or password' });
    }

    // Check if email verified
    if (!user.emailVerified) {
      return res.status(403).json({ 
        message: 'Please verify your email first',
        emailVerified: false,
        email: user.email
      });
    }

    // Check if banned
    if (user.banned || !user.isActive) {
      return res.status(403).json({ message: 'Your account has been banned' });
    }

    // Generate token
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      message: 'Login successful',
      token,
      userId: user._id,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        phone: user.phone,
        balance: user.balance,
        capital: user.capital,
        totalProfit: user.totalProfit,
        emailVerified: user.emailVerified
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Forgot Password - Send OTP
router.post('/email/forgot-password', async (req, res) => {
  console.log('🔵 ===== FORGOT PASSWORD REQUEST RECEIVED =====');
  console.log('🔵 Request body:', req.body);
  console.log('🔵 Request headers:', req.headers);
  
  try {
    const { email } = req.body;

    console.log('🔵 Email from request:', email);

    if (!email) {
      console.log('❌ No email provided');
      return res.status(400).json({ message: 'Email is required' });
    }

    // Get client IP address
    const clientIp = req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'];
    console.log('🔵 Client IP:', clientIp);

    // Check rate limit (max 5 password resets per hour per IP)
    const rateLimit = rateLimiter.checkPasswordResetLimit(clientIp);
    if (!rateLimit.allowed) {
      console.log('❌ Rate limit exceeded for IP:', clientIp);
      return res.status(429).json({ 
        message: `Too many password reset requests. Please try again in ${Math.ceil(rateLimit.retryAfter / 60)} minutes.`,
        retryAfter: rateLimit.retryAfter
      });
    }

    // Find user
    console.log('🔵 Searching for user with email:', email.toLowerCase());
    const user = await User.findOne({ email: email.toLowerCase() });
    
    if (!user) {
      console.log('❌ User not found for email:', email);
      // Don't reveal if email exists, but still record the attempt
      rateLimiter.recordPasswordResetAttempt(clientIp);
      return res.json({ message: 'If email exists, reset code has been sent' });
    }

    console.log('✅ User found:', user.email);

    // Generate OTP
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000);

    console.log('🔵 Generated OTP:', otp);
    console.log('🔵 OTP expires at:', otpExpires);

    user.passwordResetToken = otp;
    user.passwordResetExpires = otpExpires;
    await user.save();

    console.log('✅ OTP saved to database');

    // Record password reset attempt
    rateLimiter.recordPasswordResetAttempt(clientIp);

    // Send email
    console.log(`📧 Attempting to send password reset email to: ${user.email}`);
    console.log(`📧 OTP: ${otp}`);
    console.log(`📧 User name: ${user.name}`);
    
    const emailResult = await sendPasswordResetEmail(user.email, otp, user.name);
    
    console.log('📧 Email result:', emailResult);
    
    if (!emailResult.success) {
      console.error('❌ Failed to send password reset email:', emailResult.error);
      return res.status(500).json({ message: 'Failed to send reset email. Please try again.' });
    }
    
    console.log('✅ Password reset email sent successfully');
    console.log('🔵 ===== FORGOT PASSWORD REQUEST COMPLETED =====');
    res.json({ message: 'If email exists, reset code has been sent' });
  } catch (error) {
    console.error('❌ Forgot password error:', error);
    console.error('❌ Error stack:', error.stack);
    res.status(500).json({ message: 'Server error' });
  }
});

// Reset Password with OTP
router.post('/email/reset-password', async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Find user
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({ message: 'Invalid reset code' });
    }

    // Check OTP
    if (user.passwordResetToken !== otp) {
      return res.status(400).json({ message: 'Invalid reset code' });
    }

    // Check expiration
    if (new Date() > user.passwordResetExpires) {
      return res.status(400).json({ message: 'Reset code expired' });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    user.password = hashedPassword;
    user.passwordResetToken = null;
    user.passwordResetExpires = null;
    await user.save();

    res.json({ message: 'Password reset successful' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Google Sign-In
router.post('/google-signin', async (req, res) => {
  try {
    const { googleId, email, name, photoUrl } = req.body;

    if (!googleId || !email) {
      return res.status(400).json({ message: 'Google ID and email are required' });
    }

    // Check if user exists
    let user = await User.findOne({ 
      $or: [
        { googleId },
        { email: email.toLowerCase() }
      ]
    });

    if (user) {
      // Update Google ID if not set
      if (!user.googleId) {
        user.googleId = googleId;
        user.authProvider = 'google';
        user.emailVerified = true;
        await user.save();
      }
    } else {
      // Create new user
      user = new User({
        googleId,
        email: email.toLowerCase(),
        name: name || '',
        emailVerified: true,
        authProvider: 'google',
        password: await bcrypt.hash(Math.random().toString(36), 10) // Random password
      });
      await user.save();
    }

    // Generate token
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      message: 'Google sign-in successful',
      token,
      userId: user._id,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        balance: user.balance,
        capital: user.capital,
        totalProfit: user.totalProfit,
        emailVerified: user.emailVerified
      }
    });
  } catch (error) {
    console.error('Google sign-in error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
