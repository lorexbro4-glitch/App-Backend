import express from 'express';
import Settings from '../models/Settings.js';
import { cacheMiddleware, invalidateCache } from '../middleware/cacheMiddleware.js';

const router = express.Router();

// Get Settings (Public - no auth required) - Cached for 300 seconds
router.get('/', cacheMiddleware(300), async (req, res) => {
  try {
    let settings = await Settings.findOne();
    
    // If no settings exist, create default
    if (!settings) {
      settings = new Settings();
      await settings.save();
    }

    res.json(settings);
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update Settings (Admin only)
router.put('/', async (req, res) => {
  try {
    const { 
      appDownloadLink, appName, maintenanceMode, maintenanceMessage, 
      referralUrl, referralQrImage,
      withdrawalNumbers, profitRate, minDeposit, maxDeposit,
      referralBonus, capitalLockMonths,
      forceUpdateEnabled, minimumAppVersion, updateMessage,
      updateDelayMinutes, updateTimerSetAt
    } = req.body;

    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings();
    }

    if (appDownloadLink !== undefined) settings.appDownloadLink = appDownloadLink;
    if (appName !== undefined) settings.appName = appName;
    if (maintenanceMode !== undefined) settings.maintenanceMode = maintenanceMode;
    if (maintenanceMessage !== undefined) settings.maintenanceMessage = maintenanceMessage;
    if (referralUrl !== undefined) settings.referralUrl = referralUrl;
    if (referralQrImage !== undefined) settings.referralQrImage = referralQrImage;
    if (withdrawalNumbers !== undefined) settings.withdrawalNumbers = withdrawalNumbers;
    if (profitRate !== undefined) settings.profitRate = profitRate;
    if (minDeposit !== undefined) settings.minDeposit = minDeposit;
    if (maxDeposit !== undefined) settings.maxDeposit = maxDeposit;
    if (referralBonus !== undefined) settings.referralBonus = referralBonus;
    if (capitalLockMonths !== undefined) settings.capitalLockMonths = capitalLockMonths;
    if (forceUpdateEnabled !== undefined) settings.forceUpdateEnabled = forceUpdateEnabled;
    if (minimumAppVersion !== undefined) settings.minimumAppVersion = minimumAppVersion;
    if (updateMessage !== undefined) settings.updateMessage = updateMessage;
    if (updateDelayMinutes !== undefined) settings.updateDelayMinutes = updateDelayMinutes;
    // When admin sets a new timer value, record the current timestamp as the start
    if (updateTimerSetAt !== undefined) settings.updateTimerSetAt = updateTimerSetAt;

    await settings.save();

    // Invalidate all settings caches
    await invalidateCache('GET:/api/settings*');
    await invalidateCache('GET:/api/user/settings*');

    res.json({
      message: 'Settings updated successfully',
      settings
    });
  } catch (error) {
    console.error('Update settings error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
