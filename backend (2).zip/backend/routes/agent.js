import express from 'express';
const router = express.Router();
import jwt from 'jsonwebtoken';
import Agent from '../models/Agent.js';
import Report from '../models/Report.js';
import auth from '../middleware/auth.js';
import mongoose from 'mongoose';
import pushNotificationService from '../services/pushNotificationService.js';
import { generateOTP, sendVerificationEmail, sendPasswordResetEmail } from '../services/emailService.js';
import multer from 'multer';

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production';
import path from 'path';
import fs from 'fs';

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/agent-kyc';
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('শুধুমাত্র ছবি ফাইল (JPEG, JPG, PNG) আপলোড করা যাবে'));
    }
  }
});

// Configure multer for chat file uploads
const chatStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/chat';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'chat-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const chatUpload = multer({
  storage: chatStorage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit for chat files
  },
  fileFilter: (req, file, cb) => {
    // Allow images and common document types
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = file.mimetype.startsWith('image/') || 
                     file.mimetype.startsWith('application/');
    
    if (extname || mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('অসমর্থিত ফাইল টাইপ'));
    }
  }
});

// Agent Registration - Complete registration with KYC
router.post('/register', async (req, res) => {
  try {
    const {
      name, email, phone, password,
      nid, dateOfBirth,
      address, emergencyContact,
      nidFrontImage, nidBackImage, selfieImage
    } = req.body;

    console.log('📝 Registration request received for:', email);

    // Validation
    if (!name || !email || !phone || !password || !nid || !dateOfBirth || !address || !emergencyContact) {
      return res.status(400).json({ message: 'সব ফিল্ড পূরণ করুন' });
    }

    // Validate images (base64 strings)
    if (!nidFrontImage || !nidBackImage || !selfieImage) {
      console.error('❌ Missing images');
      return res.status(400).json({ message: 'সব KYC ছবি আপলোড করুন' });
    }

    // Check if agent already exists
    const existingAgent = await Agent.findOne({
      $or: [
        { email: email.toLowerCase() },
        { phone },
        { nid }
      ]
    });

    if (existingAgent) {
      // If email not verified, allow re-registration (delete old record)
      if (!existingAgent.isEmailVerified) {
        console.log('Agent exists but email not verified, deleting old record');
        await Agent.findByIdAndDelete(existingAgent._id);
        console.log('Old unverified agent deleted, proceeding with new registration');
      } else {
        // Email is verified, don't allow re-registration
        return res.status(400).json({ message: 'এই ইমেইল, ফোন বা NID দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে' });
      }
    }

    // Generate OTP for email verification
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Create new agent (pending approval)
    const agent = new Agent({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      phone: phone.trim(),
      password,
      nid: nid.trim(),
      dateOfBirth: new Date(dateOfBirth),
      address: {
        street: address.street.trim(),
        city: address.city.trim(),
        district: address.district.trim(),
        postalCode: address.postalCode?.trim() || ''
      },
      emergencyContact: {
        name: emergencyContact.name.trim(),
        phone: emergencyContact.phone.trim(),
        relation: emergencyContact.relation.trim()
      },
      nidFrontImage: nidFrontImage,
      nidBackImage: nidBackImage,
      selfieImage: selfieImage,
      approvalStatus: 'pending',
      isActive: false,
      emailVerificationToken: otp,
      emailVerificationExpires: otpExpires
    });

    await agent.save();
    console.log('✅ Agent saved successfully with ID:', agent._id);

    // Send verification email
    console.log(`OTP for ${email}: ${otp}`);
    const emailResult = await sendVerificationEmail(email, otp, agent.name);
    
    if (!emailResult.success) {
      console.error('Failed to send verification email:', emailResult.error);
      // Don't fail registration if email fails, agent can resend OTP
    }

    // Notify admin about new agent registration
    try {
      await pushNotificationService.sendToAdmins({
        title: 'নতুন এজেন্ট রেজিস্ট্রেশন',
        body: `${name} - ${email} - ${phone}`,
        data: {
          type: 'agent_registration',
          agentId: agent._id.toString(),
          email: email,
          phone: phone,
        },
      });
      console.log('Admin notification sent for new agent registration');
    } catch (notifError) {
      console.error('Failed to send admin notification:', notifError);
      // Don't fail the agent registration if notification fails
    }

    res.json({
      message: 'আবেদন সফলভাবে জমা হয়েছে। আপনার ইমেইল যাচাই করুন।',
      agentId: agent._id
    });
  } catch (error) {
    console.error('Agent registration error:', error);
    console.error('Error stack:', error.stack);
    console.error('Error message:', error.message);
    
    // Return more specific error message
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(e => e.message);
      return res.status(400).json({ message: `Validation error: ${errors.join(', ')}` });
    }
    
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      return res.status(400).json({ message: `এই ${field} ইতিমধ্যে ব্যবহৃত হয়েছে` });
    }
    
    res.status(500).json({ message: 'সার্ভার ত্রুটি', error: error.message });
  }
});

// KYC Verification Only (Simplified endpoint for KYC submission without full registration)
router.post('/verification', upload.fields([
  { name: 'nidFrontImage', maxCount: 1 },
  { name: 'nidBackImage', maxCount: 1 },
  { name: 'selfieImage', maxCount: 1 }
]), async (req, res) => {
  try {
    const {
      nidNumber,
      dateOfBirth,
      withdrawPassword
    } = req.body;

    console.log('KYC Verification request received:', {
      nidNumber,
      dateOfBirth,
      hasWithdrawPassword: !!withdrawPassword,
      files: req.files
    });

    // Get uploaded file paths
    const files = req.files;
    const nidFrontImage = files?.nidFrontImage?.[0]?.path;
    const nidBackImage = files?.nidBackImage?.[0]?.path;
    const selfieImage = files?.selfieImage?.[0]?.path;

    // Validation
    if (!nidNumber || !dateOfBirth || !withdrawPassword) {
      console.log('Validation failed: Missing required fields');
      return res.status(400).json({ message: 'সব ফিল্ড পূরণ করুন' });
    }

    // Validate uploaded images
    if (!nidFrontImage || !nidBackImage || !selfieImage) {
      console.log('Validation failed: Missing images', {
        hasNidFront: !!nidFrontImage,
        hasNidBack: !!nidBackImage,
        hasSelfie: !!selfieImage
      });
      return res.status(400).json({ message: 'সব KYC ছবি আপলোড করুন' });
    }

    console.log('All validations passed, images uploaded successfully');

    // For now, just return success
    // In a real implementation, you would save this to a KYC verification collection
    res.json({
      message: 'KYC যাচাইকরণ সফলভাবে জমা হয়েছে। অনুমোদনের জন্য অপেক্ষা করুন।',
      data: {
        nidNumber,
        dateOfBirth,
        nidFrontImage,
        nidBackImage,
        selfieImage
      }
    });
  } catch (error) {
    console.error('KYC verification error:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({ message: 'সার্ভার ত্রুটি', error: error.message });
  }
});

// Send OTP for Email Verification
router.post('/register/send-otp', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'ইমেইল প্রয়োজন' });
    }

    // Check if agent exists
    const agent = await Agent.findOne({ email: email.toLowerCase() });
    if (!agent) {
      return res.status(404).json({ message: 'এই ইমেইলে কোন এজেন্ট পাওয়া যায়নি' });
    }

    // Generate 6-digit OTP
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP in agent record
    agent.emailVerificationToken = otp;
    agent.emailVerificationExpires = otpExpires;
    await agent.save();

    // Send OTP via email
    console.log(`OTP for ${email}: ${otp}`);
    const emailResult = await sendVerificationEmail(email, otp, agent.name);
    
    if (!emailResult.success) {
      return res.status(500).json({ message: 'ইমেইল পাঠাতে ব্যর্থ' });
    }

    res.json({ message: 'OTP আপনার ইমেইলে পাঠানো হয়েছে' });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Verify OTP
router.post('/register/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ message: 'ইমেইল এবং OTP প্রয়োজন' });
    }

    const agent = await Agent.findOne({ email: email.toLowerCase() });
    if (!agent) {
      return res.status(404).json({ message: 'এজেন্ট পাওয়া যায়নি' });
    }

    if (!agent.emailVerificationToken) {
      return res.status(400).json({ message: 'OTP পাওয়া যায়নি। আবার পাঠান।' });
    }

    if (new Date() > agent.emailVerificationExpires) {
      return res.status(400).json({ message: 'OTP মেয়াদ শেষ হয়ে গেছে' });
    }

    if (agent.emailVerificationToken !== otp.trim()) {
      return res.status(400).json({ message: 'ভুল OTP' });
    }

    // Mark email as verified
    agent.isEmailVerified = true;
    agent.emailVerificationToken = undefined;
    agent.emailVerificationExpires = undefined;
    await agent.save();

    res.json({ message: 'ইমেইল যাচাই সফল' });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Forgot Password - Send OTP
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'ইমেইল প্রয়োজন' });
    }

    const agent = await Agent.findOne({ email: email.toLowerCase() });
    if (!agent) {
      return res.status(404).json({ message: 'এই ইমেইল দিয়ে কোন এজেন্ট পাওয়া যায়নি' });
    }

    // Generate 6-digit OTP
    const otp = generateOTP();
    const otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    agent.resetPasswordOTP = otp;
    agent.resetPasswordOTPExpires = otpExpires;
    await agent.save();

    // Send OTP via email
    console.log(`Password Reset OTP for ${email}: ${otp}`);
    const emailResult = await sendPasswordResetEmail(email, otp, agent.name);
    
    if (!emailResult.success) {
      return res.status(500).json({ message: 'ইমেইল পাঠাতে ব্যর্থ' });
    }

    res.json({ message: 'OTP আপনার ইমেইলে পাঠানো হয়েছে' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Forgot Password - Verify OTP
router.post('/forgot-password/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ message: 'ইমেইল এবং OTP প্রয়োজন' });
    }

    const agent = await Agent.findOne({ email: email.toLowerCase() });
    if (!agent) {
      return res.status(404).json({ message: 'এজেন্ট পাওয়া যায়নি' });
    }

    if (!agent.resetPasswordOTP || agent.resetPasswordOTP !== otp.trim()) {
      return res.status(400).json({ message: 'ভুল OTP' });
    }

    if (new Date() > agent.resetPasswordOTPExpires) {
      return res.status(400).json({ message: 'OTP মেয়াদ শেষ হয়ে গেছে' });
    }

    // Generate reset token
    const resetToken = jwt.sign(
      { agentId: agent._id, purpose: 'password-reset' },
      JWT_SECRET,
      { expiresIn: '15m' }
    );

    agent.resetPasswordToken = resetToken;
    agent.resetPasswordOTP = undefined;
    agent.resetPasswordOTPExpires = undefined;
    await agent.save();

    res.json({ message: 'OTP যাচাই সফল', resetToken });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Forgot Password - Reset Password
router.post('/forgot-password/reset', async (req, res) => {
  try {
    const { resetToken, newPassword } = req.body;

    if (!resetToken || !newPassword) {
      return res.status(400).json({ message: 'সব ফিল্ড প্রয়োজন' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে' });
    }

    const decoded = jwt.verify(resetToken, JWT_SECRET);
    if (decoded.purpose !== 'password-reset') {
      return res.status(400).json({ message: 'অবৈধ টোকেন' });
    }

    const agent = await Agent.findById(decoded.agentId);
    if (!agent || agent.resetPasswordToken !== resetToken) {
      return res.status(400).json({ message: 'অবৈধ বা মেয়াদ শেষ টোকেন' });
    }

    agent.password = newPassword;
    agent.resetPasswordToken = undefined;
    await agent.save();

    res.json({ message: 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Agent Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'ইমেইল এবং পাসওয়ার্ড প্রয়োজন' });
    }

    const agent = await Agent.findOne({ email: email.toLowerCase() });
    if (!agent) {
      return res.status(401).json({ message: 'ভুল ইমেইল বা পাসওয়ার্ড' });
    }

    // Check approval status
    if (agent.approvalStatus === 'pending') {
      return res.status(403).json({ message: 'আপনার আবেদন অনুমোদনের জন্য অপেক্ষমান' });
    }

    if (agent.approvalStatus === 'rejected') {
      return res.status(403).json({ 
        message: `আপনার আবেদন প্রত্যাখ্যান করা হয়েছে। কারণ: ${agent.rejectionReason || 'কোন কারণ উল্লেখ করা হয়নি'}` 
      });
    }

    if (!agent.isActive) {
      return res.status(403).json({ message: 'আপনার অ্যাকাউন্ট নিষ্ক্রিয়' });
    }

    const isMatch = await agent.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'ভুল ইমেইল বা পাসওয়ার্ড' });
    }

    // Update last login (non-blocking — don't let this fail the login)
    Agent.findByIdAndUpdate(agent._id, { lastLoginAt: new Date() }).catch(err =>
      console.error('Failed to update lastLoginAt:', err)
    );

    const token = jwt.sign(
      { userId: agent._id, role: 'agent' },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      token,
      agentId: agent._id,
      name: agent.name,
      email: agent.email,
      phone: agent.phone,
      nidFrontImage: agent.nidFrontImage,
      nidBackImage: agent.nidBackImage,
      selfieImage: agent.selfieImage,
      approvalStatus: agent.approvalStatus,
      isEmailVerified: agent.isEmailVerified
    });
  } catch (error) {
    console.error('Agent login error:', error.message, error.stack);
    res.status(500).json({ message: 'সার্ভার ত্রুটি', detail: error.message });
  }
});

// Get Agent Profile
router.get('/profile', auth, async (req, res) => {
  try {
    const agent = await Agent.findById(req.userId).select('-password -emailVerificationToken -resetPasswordToken -resetPasswordOTP');
    if (!agent) {
      return res.status(404).json({ message: 'এজেন্ট পাওয়া যায়নি' });
    }
    res.json({ agent });
  } catch (error) {
    console.error('Get agent profile error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Update Push Token
router.post('/push-token', auth, async (req, res) => {
  try {
    const { pushToken } = req.body;
    
    if (!pushToken) {
      return res.status(400).json({ message: 'Push token is required' });
    }

    // Register token with validation and welcome notification
    const result = await pushNotificationService.registerAgentToken(req.userId, pushToken);
    
    res.json({ 
      message: 'Push token updated',
      welcomeNotificationSent: result.welcomeNotificationSent
    });
  } catch (error) {
    console.error('Update push token error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Upload Chat File
router.post('/upload-chat-file', auth, chatUpload.single('file'), async (req, res) => {
  try {
    console.log('=== CHAT FILE UPLOAD REQUEST RECEIVED ===');
    console.log('User ID:', req.userId);
    console.log('File received:', req.file ? 'YES' : 'NO');
    
    if (req.file) {
      console.log('File details:', {
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        path: req.file.path
      });
    }
    
    if (!req.file) {
      console.error('No file in request');
      return res.status(400).json({ message: 'ফাইল আপলোড করুন' });
    }

    // Return the file path (relative to server root)
    const fileUrl = `/${req.file.path.replace(/\\/g, '/')}`;
    
    console.log('File uploaded successfully, returning URL:', fileUrl);
    
    res.json({
      message: 'ফাইল সফলভাবে আপলোড হয়েছে',
      fileUrl,
      fileName: req.file.originalname,
      fileSize: req.file.size
    });
    
    console.log('=== CHAT FILE UPLOAD COMPLETE ===');
  } catch (error) {
    console.error('=== CHAT FILE UPLOAD ERROR ===');
    console.error('Upload chat file error:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({ message: 'ফাইল আপলোড করতে ব্যর্থ', error: error.message });
  }
});

// Get Tickets (reuse support ticket model)
router.get('/tickets', auth, async (req, res) => {
  try {
    const { status, priority } = req.query;
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');

    const filter = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    const tickets = await SupportTicket.find(filter)
      .populate('userId', 'name phone username')
      .sort({ lastMessageAt: -1 });

    // Filter tickets to only include those with at least one message
    const ticketsWithMessages = [];
    
    for (const ticket of tickets) {
      const messageCount = await SupportMessage.countDocuments({ ticketId: ticket._id });
      
      // Only include tickets that have at least one message
      if (messageCount > 0) {
        const unreadCount = await SupportMessage.countDocuments({
          ticketId: ticket._id,
          sender: 'user',
          read: false
        });

        const lastMessage = await SupportMessage.findOne({ ticketId: ticket._id })
          .sort({ createdAt: -1 });

        ticketsWithMessages.push({
          ...ticket.toObject(),
          unreadCount,
          lastMessage: lastMessage?.message || '',
          lastMessageType: lastMessage?.messageType || 'text'
        });
      }
    }

    res.json({ tickets: ticketsWithMessages });
  } catch (error) {
    console.error('Get tickets error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Ticket Details
router.get('/tickets/:id', auth, async (req, res) => {
  try {
    const SupportTicket = mongoose.model('SupportTicket');
    const ticket = await SupportTicket.findById(req.params.id)
      .populate('userId', 'name phone username');

    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    res.json({ ticket });
  } catch (error) {
    console.error('Get ticket details error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Ticket Messages
router.get('/tickets/:id/messages', auth, async (req, res) => {
  try {
    const SupportMessage = mongoose.model('SupportMessage');
    const messages = await SupportMessage.find({ ticketId: req.params.id })
      .sort({ createdAt: 1 });

    // Mark user messages as read
    await SupportMessage.updateMany(
      { ticketId: req.params.id, sender: 'user', read: false },
      { read: true, readAt: new Date() }
    );

    res.json({ messages });
  } catch (error) {
    console.error('Get ticket messages error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Send Message
router.post('/tickets/:id/messages', auth, async (req, res) => {
  try {
    const { message, messageType, fileUrl, fileName, fileSize } = req.body;
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');

    const ticket = await SupportTicket.findById(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    const newMessage = new SupportMessage({
      ticketId: req.params.id,
      userId: ticket.userId,
      sender: 'admin',
      message: message?.trim(),
      messageType: messageType || 'text',
      fileUrl,
      fileName,
      fileSize,
      read: true
    });

    await newMessage.save();

    // Update ticket
    ticket.lastMessageAt = new Date();
    if (ticket.status === 'open') {
      ticket.status = 'in_progress';
    }
    await ticket.save();

    // Update agent stats
    await Agent.findByIdAndUpdate(req.userId, {
      $inc: { 'stats.ticketsHandled': 1 }
    });

    // Send push notification to user
    const User = mongoose.model('User');
    const user = await User.findById(ticket.userId);
    
    try {
      if (user && user._id) {
        await pushNotificationService.sendToUser(user._id, {
          title: 'সাপোর্ট টিম থেকে নতুন মেসেজ',
          body: message?.substring(0, 100) || 'আপনি একটি নতুন মেসেজ পেয়েছেন',
          data: { type: 'support_reply', ticketId: ticket._id.toString() }
        });
      }
    } catch (notifError) {
      console.error('Failed to send notification to user:', notifError);
    }

    res.json({ message: 'মেসেজ পাঠানো হয়েছে', data: newMessage });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Update Ticket Status
router.patch('/tickets/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');

    const ticket = await SupportTicket.findById(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    ticket.status = status;
    if (status === 'closed' || status === 'resolved') {
      ticket.closedAt = new Date();
    }
    await ticket.save();

    // Send system message
    const systemMessage = new SupportMessage({
      ticketId: ticket._id,
      userId: ticket.userId,
      sender: 'system',
      message: `টিকেট স্ট্যাটাস আপডেট: ${status}`,
      messageType: 'text',
      read: true
    });
    await systemMessage.save();

    res.json({ message: 'স্ট্যাটাস আপডেট হয়েছে', ticket });
  } catch (error) {
    console.error('Update ticket status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Update Ticket Priority
router.patch('/tickets/:id/priority', auth, async (req, res) => {
  try {
    const { priority } = req.body;
    const SupportTicket = mongoose.model('SupportTicket');

    const ticket = await SupportTicket.findById(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    ticket.priority = priority;
    await ticket.save();

    res.json({ message: 'প্রায়োরিটি আপডেট হয়েছে', ticket });
  } catch (error) {
    console.error('Update ticket priority error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Typing Status
router.post('/tickets/:id/typing', auth, async (req, res) => {
  try {
    const { isTyping } = req.body;
    const TypingStatus = mongoose.model('TypingStatus');

    await TypingStatus.findOneAndUpdate(
      { ticketId: req.params.id, userId: req.userId },
      { isTyping, updatedAt: new Date() },
      { upsert: true }
    );

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

router.get('/tickets/:id/typing', auth, async (req, res) => {
  try {
    const TypingStatus = mongoose.model('TypingStatus');
    const typingStatuses = await TypingStatus.find({
      ticketId: req.params.id,
      userId: { $ne: req.userId },
      isTyping: true,
      updatedAt: { $gte: new Date(Date.now() - 5000) }
    }).populate('userId', 'name role');

    res.json({ typingStatuses });
  } catch (error) {
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get User Profile
router.get('/users/:id', auth, async (req, res) => {
  try {
    const User = mongoose.model('User');
    const user = await User.findById(req.params.id).select('-password -email');
    
    if (!user) {
      return res.status(404).json({ message: 'ইউজার পাওয়া যায়নি' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get User Transactions
router.get('/users/:id/transactions', auth, async (req, res) => {
  try {
    const Transaction = mongoose.model('Transaction');
    const transactions = await Transaction.find({ userId: req.params.id })
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({ transactions });
  } catch (error) {
    console.error('Get user transactions error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get User Deposits
router.get('/users/:id/deposits', auth, async (req, res) => {
  try {
    const Deposit = mongoose.model('Deposit');
    const deposits = await Deposit.find({ userId: req.params.id })
      .sort({ createdAt: -1 })
      .limit(20);

    res.json({ deposits });
  } catch (error) {
    console.error('Get user deposits error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get User Withdrawals
router.get('/users/:id/withdrawals', auth, async (req, res) => {
  try {
    const Withdraw = mongoose.model('Withdraw');
    const withdrawals = await Withdraw.find({ userId: req.params.id })
      .sort({ createdAt: -1 })
      .limit(20);

    res.json({ withdrawals });
  } catch (error) {
    console.error('Get user withdrawals error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Submit Report
router.post('/reports', auth, async (req, res) => {
  try {
    const { ticketId, userId, reportType, priority, subject, description, attachments } = req.body;

    if (!reportType || !subject || !description) {
      return res.status(400).json({ message: 'সব ফিল্ড পূরণ করুন' });
    }

    const report = new Report({
      agentId: req.userId,
      ticketId,
      userId,
      reportType,
      priority: priority || 'medium',
      subject,
      description,
      attachments: attachments || []
    });

    await report.save();

    res.json({ message: 'রিপোর্ট সাবমিট হয়েছে', report });
  } catch (error) {
    console.error('Submit report error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Agent's Reports
router.get('/reports', auth, async (req, res) => {
  try {
    const reports = await Report.find({ agentId: req.userId })
      .populate('ticketId')
      .populate('userId', 'name phone')
      .sort({ createdAt: -1 });

    res.json({ reports });
  } catch (error) {
    console.error('Get reports error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Agent Stats
router.get('/stats', auth, async (req, res) => {
  try {
    const agent = await Agent.findById(req.userId);
    const SupportTicket = mongoose.model('SupportTicket');
    
    const totalTickets = await SupportTicket.countDocuments();
    const openTickets = await SupportTicket.countDocuments({ status: 'open' });
    const inProgressTickets = await SupportTicket.countDocuments({ status: 'in_progress' });
    const resolvedTickets = await SupportTicket.countDocuments({ status: 'resolved' });

    res.json({
      stats: {
        ...agent.stats,
        totalTickets,
        openTickets,
        inProgressTickets,
        resolvedTickets
      }
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Delete Chat History (Agent only - after problem solved)
router.delete('/tickets/:id/messages', auth, async (req, res) => {
  try {
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');
    const TypingStatus = mongoose.model('TypingStatus');

    const ticket = await SupportTicket.findById(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: 'টিকেট পাওয়া যায়নি' });
    }

    // Only allow deletion if ticket is resolved or closed
    if (ticket.status !== 'resolved' && ticket.status !== 'closed') {
      return res.status(400).json({ 
        message: 'শুধুমাত্র সমাধান হওয়া বা বন্ধ টিকেটের মেসেজ ডিলিট করা যাবে' 
      });
    }

    // Delete all messages for this ticket
    const deleteResult = await SupportMessage.deleteMany({ ticketId: req.params.id });

    // Delete typing status
    await TypingStatus.deleteMany({ ticketId: req.params.id });

    // Create new ticket for user (NO welcome message yet - will be sent when user sends first message)
    const newTicket = new SupportTicket({
      userId: ticket.userId,
      subject: 'সাপোর্ট টিকেট',
      status: 'open',
      priority: 'medium'
    });
    await newTicket.save();

    // Delete the old ticket
    await SupportTicket.findByIdAndDelete(req.params.id);

    res.json({ 
      message: 'চ্যাট হিস্ট্রি সফলভাবে ডিলিট হয়েছে',
      deletedMessages: deleteResult.deletedCount
    });
  } catch (error) {
    console.error('Delete chat history error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Delete Single Message (Agent only)
router.delete('/tickets/:ticketId/messages/:messageId', auth, async (req, res) => {
  try {
    const SupportMessage = mongoose.model('SupportMessage');
    const message = await SupportMessage.findById(req.params.messageId);
    if (!message) {
      return res.status(404).json({ message: 'মেসেজ পাওয়া যায়নি' });
    }
    if (message.ticketId.toString() !== req.params.ticketId) {
      return res.status(403).json({ message: 'অনুমতি নেই' });
    }
    await SupportMessage.findByIdAndDelete(req.params.messageId);
    res.json({ message: 'মেসেজ ডিলিট হয়েছে' });
  } catch (error) {
    console.error('Delete message error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
