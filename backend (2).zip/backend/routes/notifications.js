import express from 'express';
const router = express.Router();
import Notification from '../models/Notification.js';
import auth from '../middleware/auth.js';

// GET /api/notifications - Get all notifications for authenticated user with pagination
router.get('/', auth, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const skip = parseInt(req.query.skip) || 0;

    console.log('📱 [GET /notifications] Fetching notifications for user:', req.userId);

    // Get notifications sorted by createdAt descending
    const notifications = await Notification.find({ userId: req.userId })
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip(skip);

    // Get unread count
    const unreadCount = await Notification.countDocuments({ 
      userId: req.userId, 
      read: false 
    });

    console.log('📱 [GET /notifications] Found notifications:', {
      userId: req.userId,
      count: notifications.length,
      unreadCount,
      types: notifications.map(n => n.type)
    });

    res.json({
      notifications,
      unreadCount
    });
  } catch (error) {
    console.error('❌ [GET /notifications] Error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// PUT /api/notifications/:id/read - Mark notification as read
router.put('/:id/read', auth, async (req, res) => {
  try {
    const notification = await Notification.findOne({
      _id: req.params.id,
      userId: req.userId
    });

    if (!notification) {
      return res.status(404).json({ message: 'নোটিফিকেশন পাওয়া যায়নি' });
    }

    notification.read = true;
    await notification.save();

    res.json({
      message: 'নোটিফিকেশন পড়া হয়েছে',
      notification
    });
  } catch (error) {
    console.error('Mark notification as read error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// POST /api/notifications/mark-all-read - Mark all notifications as read
router.post('/mark-all-read', auth, async (req, res) => {
  try {
    const result = await Notification.updateMany(
      { userId: req.userId, read: false },
      { $set: { read: true } }
    );

    res.json({
      message: 'সব নোটিফিকেশন পড়া হয়েছে',
      count: result.modifiedCount
    });
  } catch (error) {
    console.error('Mark all notifications as read error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// DELETE /api/notifications/:id - Delete a notification
router.delete('/:id', auth, async (req, res) => {
  try {
    const notification = await Notification.findOneAndDelete({
      _id: req.params.id,
      userId: req.userId
    });

    if (!notification) {
      return res.status(404).json({ message: 'নোটিফিকেশন পাওয়া যায়নি' });
    }

    res.json({ message: 'নোটিফিকেশন মুছে ফেলা হয়েছে' });
  } catch (error) {
    console.error('Delete notification error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
