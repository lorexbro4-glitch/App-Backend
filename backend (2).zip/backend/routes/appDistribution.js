import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import AppDistribution from '../models/AppDistribution.js';
import AppRating from '../models/AppRating.js';
import jwt from 'jsonwebtoken';

const router = express.Router();

// Admin authentication middleware
const adminAuth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production');
    if (!decoded.isAdmin) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    req.admin = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Configure multer for APK uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/apk';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB limit
  fileFilter: (req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() === '.apk') {
      cb(null, true);
    } else {
      cb(new Error('Only APK files are allowed'));
    }
  }
});

// Get latest app info (public endpoint)
router.get('/latest', async (req, res) => {
  try {
    const { appName = 'InvestmentApp' } = req.query;
    
    const latestApp = await AppDistribution.findOne({ appName })
      .sort({ uploadedAt: -1 })
      .select('appName version fileSize fileName uploadedAt');
    
    if (!latestApp) {
      return res.status(404).json({ message: 'No app version found' });
    }
    
    res.json({
      success: true,
      data: {
        id: latestApp._id,
        appName: latestApp.appName,
        version: latestApp.version,
        fileSize: latestApp.fileSize,
        fileName: latestApp.fileName,
        uploadedAt: latestApp.uploadedAt
      }
    });
  } catch (error) {
    console.error('Get latest app error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Download APK file (public endpoint)
router.get('/download/:id', async (req, res) => {
  try {
    const app = await AppDistribution.findById(req.params.id);
    
    if (!app) {
      return res.status(404).json({ message: 'App not found' });
    }
    
    const filePath = path.resolve(app.filePath);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    res.download(filePath, app.fileName);
  } catch (error) {
    console.error('Download app error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload new APK (admin only)
router.post('/upload', adminAuth, upload.single('apk'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    
    const { appName, version } = req.body;
    
    if (!appName || !version) {
      // Delete uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ message: 'App name and version are required' });
    }
    
    const appDistribution = await AppDistribution.create({
      appName,
      version,
      fileSize: req.file.size,
      fileName: req.file.originalname,
      filePath: req.file.path,
      uploadedBy: req.admin.username
    });
    
    res.json({
      success: true,
      message: 'App uploaded successfully',
      data: {
        id: appDistribution._id,
        appName: appDistribution.appName,
        version: appDistribution.version,
        fileSize: appDistribution.fileSize,
        fileName: appDistribution.fileName,
        uploadedAt: appDistribution.uploadedAt
      }
    });
  } catch (error) {
    // Delete uploaded file if database operation fails
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    console.error('Upload app error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// List all versions (admin only)
router.get('/list', adminAuth, async (req, res) => {
  try {
    const { appName, page = 1, pageSize = 20 } = req.query;
    
    let query = {};
    if (appName) {
      query.appName = appName;
    }
    
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [data, totalCount] = await Promise.all([
      AppDistribution.find(query)
        .sort({ uploadedAt: -1 })
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      AppDistribution.countDocuments(query)
    ]);
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('List apps error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete version (admin only)
router.delete('/:id', adminAuth, async (req, res) => {
  try {
    const app = await AppDistribution.findById(req.params.id);
    
    if (!app) {
      return res.status(404).json({ message: 'App not found' });
    }
    
    // Delete file from filesystem
    if (fs.existsSync(app.filePath)) {
      fs.unlinkSync(app.filePath);
    }
    
    // Delete from database
    await AppDistribution.findByIdAndDelete(req.params.id);
    
    res.json({ success: true, message: 'App deleted successfully' });
  } catch (error) {
    console.error('Delete app error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// ── Rating Endpoints ──

// GET /api/app-distribution/rating — get current rating stats
router.get('/rating', async (req, res) => {
  try {
    let rating = await AppRating.findOne();
    if (!rating) rating = await AppRating.create({});
    const avg = (rating.totalScore / rating.totalRatings).toFixed(1);
    res.json({ success: true, data: {
      totalRatings: rating.totalRatings,
      average: parseFloat(avg),
      star5: rating.star5, star4: rating.star4,
      star3: rating.star3, star2: rating.star2, star1: rating.star1
    }});
  } catch (e) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/app-distribution/rating — submit a rating (1-5 stars)
// Uses IP to prevent duplicate ratings
router.post('/rating', async (req, res) => {
  try {
    const { stars } = req.body;
    if (!stars || stars < 1 || stars > 5) {
      return res.status(400).json({ message: 'stars must be 1-5' });
    }

    let rating = await AppRating.findOne();
    if (!rating) rating = await AppRating.create({});

    const starKey = `star${Math.round(stars)}`;
    rating[starKey] = (rating[starKey] || 0) + 1;
    rating.totalRatings += 1;
    rating.totalScore += Math.round(stars);
    await rating.save();

    const avg = (rating.totalScore / rating.totalRatings).toFixed(1);
    res.json({ success: true, data: {
      totalRatings: rating.totalRatings,
      average: parseFloat(avg),
      star5: rating.star5, star4: rating.star4,
      star3: rating.star3, star2: rating.star2, star1: rating.star1
    }});
  } catch (e) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
