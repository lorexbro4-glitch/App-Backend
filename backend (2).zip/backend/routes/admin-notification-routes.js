// ========================================
// NOTIFICATION ROUTES TO ADD TO admin.js
// ========================================
// Add these routes to backend/routes/admin.js (before export default router;)

import Notification from '../models/Notification.js';
import Admin from '../models/Admin.js';

// Get all notifications for admin
router.get('/notifications', adminAuth, async (req, res) => {
  try {
    const notifications = await Notification.find({ userId: req.admin._id })
      .sort({ createdAt: -1 })
      .limit(50);
    res.json({ notifications });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ message: 'Failed to fetch notifications' });
  }
});

// Mark notification as read
router.put('/notifications/:id/read', adminAuth, async (req, res) => {
  try {
    await Notification.findByIdAndUpdate(req.params.id, { read: true });
    res.json({ message: 'Marked as read' });
  } catch (error) {
    console.error('Mark notification as read error:', error);
    res.status(500).json({ message: 'Failed to mark as read' });
  }
});

// Mark all notifications as read
router.put('/notifications/read-all', adminAuth, async (req, res) => {
  try {
    await Notification.updateMany(
      { userId: req.admin._id, read: false },
      { read: true }
    );
    res.json({ message: 'All marked as read' });
  } catch (error) {
    console.error('Mark all notifications as read error:', error);
    res.status(500).json({ message: 'Failed to mark all as read' });
  }
});

// Get unread count
router.get('/notifications/unread-count', adminAuth, async (req, res) => {
  try {
    const count = await Notification.countDocuments({
      userId: req.admin._id,
      read: false
    });
    res.json({ count });
  } catch (error) {
    console.error('Get unread count error:', error);
    res.status(500).json({ message: 'Failed to get count' });
  }
});

// Register push token
router.post('/push-token', adminAuth, async (req, res) => {
  try {
    const { token } = req.body;
    
    // If you don't have Admin model, you can store in User model with isAdmin flag
    // For now, just return success (implement based on your admin storage)
    
    res.json({ message: 'Token registered' });
  } catch (error) {
    console.error('Register push token error:', error);
    res.status(500).json({ message: 'Failed to register token' });
  }
});
