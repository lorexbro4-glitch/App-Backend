import request from 'supertest';
import express from 'express';
import mongoose from 'mongoose';
import fc from 'fast-check';
import authEmailRouter from './authEmail.js';
import User from '../models/User.js';

// Create Express app for testing
const app = express();
app.use(express.json());
app.use('/auth', authEmailRouter);

/**
 * Feature: referral-code-auto-fill
 * Property 18: Backend Referral Code Validation
 * 
 * **Validates: Requirements 12.1**
 * 
 * This property test verifies that the backend correctly validates referral codes
 * against existing users. It generates random referral codes (both valid and invalid)
 * and verifies the validation logic works correctly across all inputs.
 */
describe('Feature: referral-code-auto-fill, Property 18: Backend Referral Code Validation', () => {
  beforeAll(async () => {
    // Connect to test database
    const mongoUri = process.env.MONGO_URI_TEST || 'mongodb://localhost:27017/investment-app-test';
    
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(mongoUri);
    }
  });

  beforeEach(async () => {
    // Clear database before each test
    await User.deleteMany({});
  });

  afterAll(async () => {
    await User.deleteMany({});
    await mongoose.connection.close();
  });

  it('should correctly validate referral codes against existing users', async () => {
    await fc.assert(
      fc.asyncProperty(
        // Generate random test data
        fc.record({
          // Create a referrer user
          referrerEmail: fc.emailAddress(),
          referrerUsername: fc.stringMatching(/^[a-z0-9_]{5,15}$/),
          referrerName: fc.string({ minLength: 1, maxLength: 50 }),
          
          // Create a new user (referee)
          newUserEmail: fc.emailAddress(),
          newUserUsername: fc.stringMatching(/^[a-z0-9_]{5,15}$/),
          newUserName: fc.string({ minLength: 1, maxLength: 50 }),
          
          // Decide whether to use valid or invalid referral code
          useValidCode: fc.boolean(),
          
          // Generate an invalid referral code (for when useValidCode is false)
          invalidCode: fc.oneof(
            // Random 8-char hex string that won't match any user
            fc.hexaString({ minLength: 8, maxLength: 8 }),
            // Random invalid format
            fc.string({ minLength: 1, maxLength: 20 }),
            // Too short
            fc.hexaString({ minLength: 1, maxLength: 7 }),
            // Too long (not 8 or 24 chars)
            fc.hexaString({ minLength: 9, maxLength: 23 })
          )
        }),
        async (testData) => {
          // Ensure unique emails and usernames
          fc.pre(testData.referrerEmail !== testData.newUserEmail);
          fc.pre(testData.referrerUsername !== testData.newUserUsername);
          
          // Create referrer user
          const referrer = new User({
            email: testData.referrerEmail.toLowerCase(),
            username: testData.referrerUsername.toLowerCase(),
            password: 'hashedpassword123',
            name: testData.referrerName,
            emailVerified: true,
            authProvider: 'email',
            referralCount: 0
          });
          await referrer.save();
          
          const referrerId = referrer._id.toString();
          const referrerCode8Char = referrerId.substring(0, 8);
          
          // Determine which referral code to use
          let referralCode;
          let shouldSucceed;
          
          if (testData.useValidCode) {
            // Use valid code (either 8-char or full 24-char)
            const useFullId = Math.random() > 0.5;
            referralCode = useFullId ? referrerId : referrerCode8Char;
            shouldSucceed = true;
          } else {
            // Use invalid code
            referralCode = testData.invalidCode;
            shouldSucceed = false;
            
            // Make sure invalid code doesn't accidentally match the referrer
            fc.pre(referralCode !== referrerId);
            fc.pre(referralCode !== referrerCode8Char);
            fc.pre(!referrerId.toLowerCase().startsWith(referralCode.toLowerCase()));
          }
          
          // Attempt registration with referral code
          const response = await request(app)
            .post('/auth/email/register')
            .send({
              email: testData.newUserEmail,
              username: testData.newUserUsername,
              password: 'password123',
              name: testData.newUserName,
              referredBy: referralCode
            });
          
          if (shouldSucceed) {
            // Valid referral code should allow registration
            expect(response.status).toBe(201);
            expect(response.body.message).toContain('Registration successful');
            
            // Verify referral relationship was created
            const newUser = await User.findOne({ email: testData.newUserEmail.toLowerCase() });
            expect(newUser).toBeTruthy();
            expect(newUser.referredBy).toBeTruthy();
            expect(newUser.referredBy.toString()).toBe(referrerId);
            
            // Verify referrer count was incremented
            const updatedReferrer = await User.findById(referrerId);
            expect(updatedReferrer.referralCount).toBe(1);
          } else {
            // Invalid referral code should reject registration
            // Check if it's a format error or non-existent code error
            const isValidFormat = /^[0-9a-fA-F]{8}$/.test(referralCode) || /^[0-9a-fA-F]{24}$/.test(referralCode);
            
            if (isValidFormat) {
              // Valid format but non-existent user
              expect(response.status).toBe(400);
              expect(response.body.message).toBe('Invalid referral code');
            } else {
              // Invalid format
              expect(response.status).toBe(400);
              expect(response.body.message).toBe('Invalid referral code format');
            }
            
            // Verify user was NOT created
            const newUser = await User.findOne({ email: testData.newUserEmail.toLowerCase() });
            expect(newUser).toBeNull();
            
            // Verify referrer count was NOT incremented
            const updatedReferrer = await User.findById(referrerId);
            expect(updatedReferrer.referralCount).toBe(0);
          }
          
          // Clean up for next iteration
          await User.deleteMany({});
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should validate that referral code corresponds to an existing user account', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          // Multiple referrers
          numReferrers: fc.integer({ min: 1, max: 5 }),
          // New user data
          newUserEmail: fc.emailAddress(),
          newUserUsername: fc.stringMatching(/^[a-z0-9_]{5,15}$/),
          // Which referrer to use (index)
          referrerIndex: fc.integer({ min: 0, max: 4 })
        }),
        async (testData) => {
          // Create multiple referrer users
          const referrers = [];
          for (let i = 0; i < testData.numReferrers; i++) {
            const referrer = new User({
              email: `referrer${i}@test.com`,
              username: `referrer${i}`,
              password: 'hashedpassword',
              name: `Referrer ${i}`,
              emailVerified: true,
              authProvider: 'email',
              referralCount: 0
            });
            await referrer.save();
            referrers.push(referrer);
          }
          
          // Select a referrer to use
          const selectedReferrer = referrers[testData.referrerIndex % testData.numReferrers];
          const referralCode = selectedReferrer._id.toString().substring(0, 8);
          
          // Register new user with selected referral code
          const response = await request(app)
            .post('/auth/email/register')
            .send({
              email: testData.newUserEmail,
              username: testData.newUserUsername,
              password: 'password123',
              name: 'New User',
              referredBy: referralCode
            });
          
          // Should succeed
          expect(response.status).toBe(201);
          
          // Verify correct referrer was linked
          const newUser = await User.findOne({ email: testData.newUserEmail.toLowerCase() });
          expect(newUser.referredBy.toString()).toBe(selectedReferrer._id.toString());
          
          // Verify only the selected referrer's count was incremented
          for (let i = 0; i < referrers.length; i++) {
            const referrer = await User.findById(referrers[i]._id);
            if (i === testData.referrerIndex % testData.numReferrers) {
              expect(referrer.referralCount).toBe(1);
            } else {
              expect(referrer.referralCount).toBe(0);
            }
          }
          
          // Clean up
          await User.deleteMany({});
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should handle case-insensitive referral code validation', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          referrerEmail: fc.emailAddress(),
          referrerUsername: fc.stringMatching(/^[a-z0-9_]{5,15}$/),
          newUserEmail: fc.emailAddress(),
          newUserUsername: fc.stringMatching(/^[a-z0-9_]{5,15}$/),
          // Generate random case variations
          caseVariation: fc.constantFrom('lower', 'upper', 'mixed')
        }),
        async (testData) => {
          fc.pre(testData.referrerEmail !== testData.newUserEmail);
          fc.pre(testData.referrerUsername !== testData.newUserUsername);
          
          // Create referrer
          const referrer = new User({
            email: testData.referrerEmail.toLowerCase(),
            username: testData.referrerUsername.toLowerCase(),
            password: 'hashedpassword',
            name: 'Referrer',
            emailVerified: true,
            authProvider: 'email',
            referralCount: 0
          });
          await referrer.save();
          
          const referrerId = referrer._id.toString();
          const referrerCode = referrerId.substring(0, 8);
          
          // Apply case variation
          let codeToUse;
          switch (testData.caseVariation) {
            case 'lower':
              codeToUse = referrerCode.toLowerCase();
              break;
            case 'upper':
              codeToUse = referrerCode.toUpperCase();
              break;
            case 'mixed':
              // Mix upper and lower case
              codeToUse = referrerCode.split('').map((c, i) => 
                i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()
              ).join('');
              break;
          }
          
          // Register with case-varied code
          const response = await request(app)
            .post('/auth/email/register')
            .send({
              email: testData.newUserEmail,
              username: testData.newUserUsername,
              password: 'password123',
              name: 'New User',
              referredBy: codeToUse
            });
          
          // Should succeed regardless of case
          expect(response.status).toBe(201);
          
          // Verify referral relationship
          const newUser = await User.findOne({ email: testData.newUserEmail.toLowerCase() });
          expect(newUser.referredBy.toString()).toBe(referrerId);
          
          // Clean up
          await User.deleteMany({});
        }
      ),
      { numRuns: 100 }
    );
  });
});
