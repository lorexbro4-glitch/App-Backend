import express from 'express';
const router = express.Router();
import auth from '../middleware/auth.js';
import User from '../models/User.js';
import Settings from '../models/Settings.js';

// Get Referral Stats
router.get('/stats', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'ইউজার পাওয়া যায়নি' });
    }

    // Get referred users
    const referredUsers = await User.find({ referredBy: req.userId });

    // Calculate total capital of all referred users
    const totalReferredCapital = referredUsers.reduce((sum, u) => {
      return sum + (u.capital || 0);
    }, 0);

    // Calculate estimated monthly earnings
    // Your commission = 5% of referred users' capital per month
    // So: estimatedMonthlyEarnings = totalReferredCapital × 0.05
    const estimatedMonthlyEarnings = totalReferredCapital * 0.05;

    res.json({
      referralCount: user.referralCount || referredUsers.length,
      referralIncome: user.referralIncome || 0,
      totalReferredCapital: totalReferredCapital,
      estimatedMonthlyEarnings: Math.round(estimatedMonthlyEarnings),
      referredUsers: referredUsers.map(u => ({
        name: u.name || u.phone,
        phone: u.phone,
        joinDate: u.joinDate || u.createdAt,
        isActive: u.isActive !== false,
        depositTotal: u.capital || 0,
      })),
    });
  } catch (error) {
    console.error('Get referral stats error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Referral Link
router.get('/link', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'ইউজার পাওয়া যায়নি' });
    }

    // Get app referral/download link from settings
    let settings = await Settings.findOne();
    if (!settings) {
      settings = new Settings();
      await settings.save();
    }

    // Generate referral code from user ID
    const referralCode = req.userId.toString().substring(0, 8);
    // Prefer referralUrl configured by admin; fall back to appDownloadLink or default
    const appDownloadLink = settings.referralUrl || settings.appDownloadLink || 'https://upload.app/your-app-link';
    
    // Return download link and code separately (no ?ref= appended)
    res.json({
      link: appDownloadLink,
      code: referralCode,
      referralCount: user.referralCount || 0,
      referralIncome: user.referralIncome || 0,
    });
  } catch (error) {
    console.error('Get referral link error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Apply Referral Code (called during registration)
router.post('/apply', auth, async (req, res) => {
  try {
    const { referralCode } = req.body;

    if (!referralCode) {
      return res.status(400).json({ message: 'রেফারেল কোড প্রয়োজন' });
    }

    // Find referrer by code (first 8 chars of user ID)
    const referrer = await User.findOne({
      _id: { $regex: new RegExp(`^${referralCode}`) }
    });

    if (!referrer) {
      return res.status(404).json({ message: 'রেফারেল কোড সঠিক নয়' });
    }

    // Update current user
    const user = await User.findById(req.userId);
    if (user.referredBy) {
      return res.status(400).json({ message: 'আপনি ইতিমধ্যে রেফার করা হয়েছে' });
    }

    user.referredBy = referrer._id;
    await user.save();

    // Update referrer stats
    referrer.referralCount = (referrer.referralCount || 0) + 1;
    await referrer.save();

    res.json({
      message: 'রেফারেল সফলভাবে প্রয়োগ করা হয়েছে',
      referrer: {
        name: referrer.name || referrer.phone,
      },
    });
  } catch (error) {
    console.error('Apply referral error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

export default router;
