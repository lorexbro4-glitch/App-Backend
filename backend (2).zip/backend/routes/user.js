import express from 'express';
const router = express.Router();
import User from '../models/User.js';
import Notification from '../models/Notification.js';
import auth from '../middleware/auth.js';
import pushNotificationService from '../services/pushNotificationService.js';

// Check Username Availability
router.get('/check-username', async (req, res) => {
  try {
    const { username } = req.query;

    if (!username) {
      return res.status(400).json({ available: false, reason: 'Username is required' });
    }

    const trimmedUsername = username.trim().toLowerCase();

    // Validate format
    if (trimmedUsername.length < 5) {
      return res.json({ available: false, reason: 'Username must be at least 5 characters' });
    }

    if (trimmedUsername.length > 15) {
      return res.json({ available: false, reason: 'Username cannot exceed 15 characters' });
    }

    if (!/^[a-z0-9_]+$/.test(trimmedUsername)) {
      return res.json({ available: false, reason: 'Username can only contain lowercase letters, numbers, and underscores' });
    }

    // Reserved username logic: 5-6 chars with ≤2 numbers are blocked
    if (trimmedUsername.length >= 5 && trimmedUsername.length <= 6) {
      const digitCount = (trimmedUsername.match(/\d/g) || []).length;
      if (digitCount <= 2) {
        return res.json({ available: false, reason: 'This username is already taken' });
      }
    }

    // Check if username exists in database — ignore unverified accounts
    const existingUser = await User.findOne({ username: trimmedUsername });
    if (existingUser) {
      // If the existing account is not email-verified, the username is still effectively free
      if (!existingUser.emailVerified) {
        return res.json({ available: true, reason: 'Username is available' });
      }
      return res.json({ available: false, reason: 'This username is already taken' });
    }

    res.json({ available: true, reason: 'Username is available' });
  } catch (error) {
    console.error('Check username error:', error);
    res.status(500).json({ available: false, reason: 'Server error' });
  }
});

// Get Profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    if (!user) {
      return res.status(404).json({message: 'ব্যবহারকারী পাওয়া যায়নি'});
    }

    // Count unread notifications for the user
    const unreadNotificationCount = await Notification.countDocuments({
      userId: req.userId,
      read: false
    });

    // Calculate capitalLockUntil dynamically from lastDepositDate
    let capitalLockUntil = null;
    if (user.lastDepositDate) {
      const lockDate = new Date(user.lastDepositDate);
      lockDate.setDate(lockDate.getDate() + 90);
      capitalLockUntil = lockDate;
    }

    res.json({
      uid: user._id,
      username: user.username,
      name: user.name,
      email: user.email,
      phone: user.phone,
      profilePicture: user.profilePicture,
      depositTotal: user.depositTotal,
      profitTotal: user.profitTotal,
      capital: user.capital || 0,
      totalProfit: user.totalProfit || 0,
      balance: user.balance || 0,
      referralIncome: user.referralIncome,
      referralCount: user.referralCount,
      joinDate: user.joinDate,
      firstDepositDate: user.firstDepositDate,
      lastDepositDate: user.lastDepositDate,
      capitalLockUntil: capitalLockUntil, // Calculated dynamically
      isVerified: user.isVerified,
      unreadNotificationCount: unreadNotificationCount,
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({message: 'সার্ভার ত্রুটি'});
  }
});

// Update Profile
router.put('/profile', auth, async (req, res) => {
  try {
    const {name, phone, profilePicture, username} = req.body;

    const updateData = {};
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (profilePicture !== undefined) updateData.profilePicture = profilePicture;
    
    // Handle username update with validation
    if (username !== undefined && username !== null && username.trim() !== '') {
      const trimmedUsername = username.trim().toLowerCase();
      
      // Validate username format
      if (trimmedUsername.length < 5) {
        return res.status(400).json({message: 'ইউজারনেম কমপক্ষে ৫ অক্ষরের হতে হবে'});
      }

      if (trimmedUsername.length > 15) {
        return res.status(400).json({message: 'ইউজারনেম সর্বোচ্চ ১৫ অক্ষরের হতে হবে'});
      }
      
      if (!/^[a-z0-9_]+$/.test(trimmedUsername)) {
        return res.status(400).json({message: 'ইউজারনেমে শুধুমাত্র ছোট হাতের অক্ষর (a-z), সংখ্যা (0-9) এবং আন্ডারস্কোর (_) ব্যবহার করা যাবে'});
      }
      
      // Check if username is already taken by another user
      const existingUser = await User.findOne({ 
        username: trimmedUsername,
        _id: { $ne: req.userId }
      });
      
      if (existingUser) {
        return res.status(400).json({message: 'এই ইউজারনেম ইতিমধ্যে ব্যবহৃত হচ্ছে'});
      }
      
      updateData.username = trimmedUsername;
    }

    const user = await User.findByIdAndUpdate(
      req.userId,
      updateData,
      {new: true},
    ).select('-password');

    // Count unread notifications
    const unreadNotificationCount = await Notification.countDocuments({
      userId: req.userId,
      read: false
    });

    res.json({
      uid: user._id,
      username: user.username,
      name: user.name,
      email: user.email,
      phone: user.phone,
      profilePicture: user.profilePicture,
      depositTotal: user.depositTotal,
      profitTotal: user.profitTotal,
      capital: user.capital || 0,
      totalProfit: user.totalProfit || 0,
      balance: user.balance || 0,
      referralIncome: user.referralIncome,
      referralCount: user.referralCount,
      joinDate: user.joinDate,
      firstDepositDate: user.firstDepositDate,
      lastDepositDate: user.lastDepositDate,
      capitalLockUntil: user.capitalLockUntil,
      isVerified: user.isVerified,
      unreadNotificationCount: unreadNotificationCount,
    });
  } catch (error) {
    console.error('Update profile error:', error);
    if (error.code === 11000) {
      return res.status(400).json({message: 'এই ইউজারনেম ইতিমধ্যে ব্যবহৃত হচ্ছে'});
    }
    res.status(500).json({message: 'সার্ভার ত্রুটি'});
  }
});

// Change Password
router.post('/change-password', auth, async (req, res) => {
  try {
    const {currentPassword, newPassword} = req.body;
    const bcrypt = (await import('bcryptjs')).default;

    // Validation
    if (!currentPassword || !newPassword) {
      return res.status(400).json({message: 'সব ফিল্ড পূরণ করুন'});
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        message: 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে',
      });
    }

    // Get user with password field
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({message: 'ব্যবহারকারী পাওয়া যায়নি'});
    }

    // Verify current password
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({message: 'বর্তমান পাসওয়ার্ড ভুল'});
    }

    // Check if new password is same as current
    const isSame = await bcrypt.compare(newPassword, user.password);
    if (isSame) {
      return res.status(400).json({
        message: 'নতুন পাসওয়ার্ড বর্তমান পাসওয়ার্ডের মতো হতে পারবে না',
      });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    user.password = hashedPassword;
    await user.save();

    res.json({message: 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে'});
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({message: 'সার্ভার ত্রুটি'});
  }
});

// Register Push Token
router.post('/push-token', auth, async (req, res) => {
  try {
    const { pushToken } = req.body;

    if (!pushToken) {
      return res.status(400).json({ message: 'Push token is required' });
    }

    // Register token with validation and welcome notification
    const result = await pushNotificationService.registerToken(req.userId, pushToken);

    res.json({ 
      message: 'Push token registered successfully',
      welcomeNotificationSent: result.welcomeNotificationSent
    });
  } catch (error) {
    console.error('Register push token error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Get Public Settings (withdrawal numbers and referral URL for app)
router.get('/settings', async (req, res) => {
  try {
    // Prevent caching to ensure fresh data
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    
    const Settings = (await import('../models/Settings.js')).default;
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings();
      await settings.save();
    }
    
    // Normalize withdrawalNumbers to new structure if needed
    const normalizedWithdrawalNumbers = {};
    for (const [method, value] of Object.entries(settings.withdrawalNumbers || {})) {
      if (typeof value === 'string') {
        // Old structure: convert string to object
        normalizedWithdrawalNumbers[method] = {
          number: value,
          mode: 'personal'
        };
      } else if (value && typeof value === 'object') {
        // New structure
        normalizedWithdrawalNumbers[method] = {
          number: value.number || '',
          mode: value.mode || 'personal'
        };
      }
    }
    
    // Return only public settings (withdrawal numbers with modes and referral URL)
    res.json({ 
      withdrawalNumbers: normalizedWithdrawalNumbers,
      referralUrl: settings.referralUrl || 'https://yourapp.com/ref/',
      referralQrImage: settings.referralQrImage || ''
    });
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Check App Version (Force Update)
router.get('/check-version', async (req, res) => {
  try {
    const { version } = req.query;
    
    console.log('🔍 Version check request received');
    console.log('📱 Client version:', version);
    
    const Settings = (await import('../models/Settings.js')).default;
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings();
      await settings.save();
    }
    
    console.log('⚙️ Settings from database:');
    console.log('  - forceUpdateEnabled:', settings.forceUpdateEnabled);
    console.log('  - minimumAppVersion:', settings.minimumAppVersion);
    console.log('  - appDownloadLink:', settings.appDownloadLink);
    
    // Compare versions
    const currentVersion = version || '0.0.0';
    const minimumVersion = settings.minimumAppVersion || '2.1.0';
    const forceUpdate = settings.forceUpdateEnabled || false;
    
    console.log('🔄 Version comparison:');
    console.log('  - Current:', currentVersion);
    console.log('  - Minimum:', minimumVersion);
    console.log('  - Force update enabled:', forceUpdate);
    
    // Simple version comparison (assumes semantic versioning)
    const comparisonResult = compareVersions(currentVersion, minimumVersion);
    console.log('  - Comparison result:', comparisonResult, '(< 0 means update needed)');
    
    const isUpdateRequired = forceUpdate && comparisonResult < 0;
    console.log('✅ Final decision - Update required:', isUpdateRequired);
    
    res.json({
      updateRequired: isUpdateRequired,
      minimumVersion: minimumVersion,
      downloadUrl: settings.referralUrl || settings.appDownloadLink || 'https://upload.app/your-app-link',
      message: settings.updateMessage || 'নতুন ভার্সন উপলব্ধ! অ্যাপ ব্যবহার করতে আপডেট করুন।',
      // Timer fields — app uses these to show countdown before enabling download
      updateDelayMinutes: settings.updateDelayMinutes || 0,
      updateTimerSetAt: settings.updateTimerSetAt || null
    });
  } catch (error) {
    console.error('❌ Check version error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Helper function to compare versions
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const part1 = parts1[i] || 0;
    const part2 = parts2[i] || 0;
    
    if (part1 < part2) return -1;
    if (part1 > part2) return 1;
  }
  
  return 0;
}

export default router;
