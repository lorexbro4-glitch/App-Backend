// Bengali text constants for the application

const BENGALI_TEXT = {
  // Transaction status
  PENDING: 'অপেক্ষমাণ',
  APPROVED: 'অনুমোদিত',
  REJECTED: 'প্রত্যাখ্যাত',
  COMPLETED: 'সম্পন্ন',
  FAILED: 'ব্যর্থ',

  // Capital lock messages
  CAPITAL_LOCK_LABEL: 'মূলধন লক',
  CAPITAL_LOCK_UNTIL: 'পর্যন্ত',
  CAPITAL_LOCK_ACTIVE: 'মূলধন লক সক্রিয়',
  CAPITAL_WITHDRAWAL_AFTER: 'মূলধন উত্তোলন {date} তারিখের পরে সম্ভব',

  // Success messages
  DEPOSIT_SUBMITTED: 'ডিপোজিট রিকোয়েস্ট গৃহীত হয়েছে',
  WITHDRAWAL_SUBMITTED: 'উইথড্রয়াল রিকোয়েস্ট গৃহীত হয়েছে',
  DEPOSIT_APPROVED: 'ডিপোজিট অনুমোদিত হয়েছে',
  WITHDRAWAL_APPROVED: 'উইথড্রয়াল অনুমোদিত হয়েছে',
  DEPOSIT_REJECTED: 'ডিপোজিট রিজেক্ট হয়েছে',
  WITHDRAWAL_REJECTED: 'উইথড্রয়াল রিজেক্ট হয়েছে',

  // Error messages (pending checks)
  PENDING_DEPOSIT_EXISTS: 'আপনার ইতিমধ্যে একটি পেন্ডিং ডিপোজিট রিকোয়েস্ট আছে',
  PENDING_WITHDRAWAL_EXISTS: 'আপনার ইতিমধ্যে একটি পেন্ডিং উইথড্রয়াল রিকোয়েস্ট আছে',
};

export default BENGALI_TEXT;
