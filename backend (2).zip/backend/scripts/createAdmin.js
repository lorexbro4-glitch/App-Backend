import mongoose from 'mongoose';
import Admin from '../models/Admin.js';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from parent directory
dotenv.config({ path: join(__dirname, '..', '.env') });

async function createAdmin() {
  try {
    console.log('🔄 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    // Check if any admin exists
    const existingAdmin = await Admin.findOne({ username: 'admin' });
    if (existingAdmin) {
      console.log('⚠️  Admin user already exists');
      console.log('Username:', existingAdmin.username);
      console.log('Active:', existingAdmin.isActive);
      console.log('Last Login:', existingAdmin.lastLoginAt || 'Never');
      await mongoose.connection.close();
      process.exit(0);
    }
    
    console.log('🔄 Creating admin user...');
    
    // Create new admin
    const admin = new Admin({
      username: 'admin',
      password: 'admin123', // Will be hashed by pre-save hook
      isActive: true
    });
    
    await admin.save();
    
    console.log('✅ Admin user created successfully!');
    console.log('');
    console.log('═══════════════════════════════════════');
    console.log('  ADMIN CREDENTIALS');
    console.log('═══════════════════════════════════════');
    console.log('  Username: admin');
    console.log('  Password: admin123');
    console.log('═══════════════════════════════════════');
    console.log('');
    console.log('⚠️  IMPORTANT: Change this password immediately after first login!');
    console.log('');
    
    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating admin:', error);
    await mongoose.connection.close();
    process.exit(1);
  }
}

createAdmin();
