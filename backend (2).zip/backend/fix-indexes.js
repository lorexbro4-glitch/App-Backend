/**
 * Fix MongoDB Indexes Script
 * 
 * This script drops problematic indexes and recreates them correctly.
 * Run this once to fix the database.
 * 
 * Usage: node fix-indexes.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

async function fixIndexes() {
  try {
    console.log('🔵 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    console.log('\n🔵 Current indexes:');
    const indexes = await User.collection.getIndexes();
    console.log(JSON.stringify(indexes, null, 2));

    console.log('\n🔵 Dropping all indexes except _id...');
    await User.collection.dropIndexes();
    console.log('✅ Indexes dropped');

    console.log('\n🔵 Recreating indexes from schema...');
    await User.syncIndexes();
    console.log('✅ Indexes recreated');

    console.log('\n🔵 New indexes:');
    const newIndexes = await User.collection.getIndexes();
    console.log(JSON.stringify(newIndexes, null, 2));

    console.log('\n✅ Index fix completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error fixing indexes:', error);
    process.exit(1);
  }
}

fixIndexes();
