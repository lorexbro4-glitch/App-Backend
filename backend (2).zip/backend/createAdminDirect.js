// Direct admin creation script - Run this with your MongoDB URI
// Usage: MONGODB_URI="your-connection-string" node createAdminDirect.js

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI || MONGODB_URI.includes('username:password') || MONGODB_URI.includes('xxxxx')) {
  console.log('❌ ERROR: MongoDB URI not configured!');
  console.log('');
  console.log('Please set your MongoDB connection string:');
  console.log('');
  console.log('Option 1: Set in Replit Secrets');
  console.log('  1. Go to Replit Secrets (lock icon in left sidebar)');
  console.log('  2. Add key: MONGODB_URI');
  console.log('  3. Add value: your MongoDB connection string');
  console.log('  4. Run: node backend/createAdminDirect.js');
  console.log('');
  console.log('Option 2: Run with environment variable');
  console.log('  MONGODB_URI="mongodb+srv://..." node backend/createAdminDirect.js');
  console.log('');
  console.log('Option 3: Update backend/.env file');
  console.log('  Edit backend/.env and replace the placeholder MONGODB_URI');
  console.log('  Then run: node backend/scripts/createAdmin.js');
  console.log('');
  process.exit(1);
}

async function createAdmin() {
  try {
    console.log('🔄 Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB');
    
    // Define Admin schema inline
    const adminSchema = new mongoose.Schema({
      username: { type: String, required: true, unique: true, lowercase: true },
      password: { type: String, required: true },
      isActive: { type: Boolean, default: true },
      pushTokens: [{ token: String, registeredAt: Date }],
      lastLoginAt: Date
    }, { timestamps: true });
    
    const Admin = mongoose.models.Admin || mongoose.model('Admin', adminSchema);
    
    // Check if admin exists
    const existingAdmin = await Admin.findOne({ username: 'admin' });
    if (existingAdmin) {
      console.log('⚠️  Admin user already exists');
      console.log('Username:', existingAdmin.username);
      console.log('Active:', existingAdmin.isActive);
      console.log('Last Login:', existingAdmin.lastLoginAt || 'Never');
      console.log('');
      console.log('If you need to reset the password, delete the admin from MongoDB and run this script again.');
      await mongoose.connection.close();
      process.exit(0);
    }
    
    console.log('🔄 Creating admin user...');
    
    // Hash password manually
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    // Create admin directly
    await Admin.create({
      username: 'admin',
      password: hashedPassword,
      isActive: true,
      pushTokens: [],
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    console.log('✅ Admin user created successfully!');
    console.log('');
    console.log('═══════════════════════════════════════');
    console.log('  ADMIN CREDENTIALS');
    console.log('═══════════════════════════════════════');
    console.log('  Username: admin');
    console.log('  Password: admin123');
    console.log('═══════════════════════════════════════');
    console.log('');
    console.log('⚠️  IMPORTANT: Change this password immediately after first login!');
    console.log('');
    console.log('You can now login to the Admin Mobile App with these credentials.');
    console.log('');
    
    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating admin:', error.message);
    if (error.code === 11000) {
      console.log('');
      console.log('Admin user already exists. If you need to reset:');
      console.log('1. Delete the admin from MongoDB');
      console.log('2. Run this script again');
    }
    await mongoose.connection.close();
    process.exit(1);
  }
}

createAdmin();
