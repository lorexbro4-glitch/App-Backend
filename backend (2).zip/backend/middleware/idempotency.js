import Deposit from '../models/Deposit.js';
import Withdraw from '../models/Withdraw.js';

// In-memory cache for idempotency keys (in production, use Redis)
const idempotencyCache = new Map();

// TTL for cache entries (5 seconds for duplicate detection)
const DUPLICATE_TTL = 5000;

/**
 * Idempotency middleware to prevent duplicate requests
 * @param {Object} options - Configuration options
 * @param {String} options.model - Model name ('Deposit' or 'Withdraw')
 * @returns {Function} Express middleware
 */
function idempotencyMiddleware(options = {}) {
  const { model } = options;

  return async (req, res, next) => {
    const idempotencyKey = req.headers['idempotency-key'] || req.body.idempotencyKey;

    if (!idempotencyKey) {
      // No idempotency key provided, continue without check
      return next();
    }

    try {
      // Check in-memory cache first
      const cachedEntry = idempotencyCache.get(idempotencyKey);
      if (cachedEntry) {
        const now = Date.now();
        if (now - cachedEntry.timestamp < DUPLICATE_TTL) {
          return res.status(409).json({
            success: false,
            message: 'দয়া করে একটু অপেক্ষা করুন', // Please wait a moment
            requestId: cachedEntry.requestId,
          });
        } else {
          // Entry expired, remove from cache
          idempotencyCache.delete(idempotencyKey);
        }
      }

      // Check database for existing request with this key
      let existingRequest = null;
      if (model === 'Deposit') {
        existingRequest = await Deposit.findOne({ idempotencyKey });
      } else if (model === 'Withdraw') {
        existingRequest = await Withdraw.findOne({ idempotencyKey });
      }

      if (existingRequest) {
        return res.status(409).json({
          success: false,
          message: 'এই রিকোয়েস্ট ইতিমধ্যে সাবমিট করা হয়েছে', // This request has already been submitted
          requestId: existingRequest._id,
        });
      }

      // Add to cache
      idempotencyCache.set(idempotencyKey, {
        timestamp: Date.now(),
        requestId: null, // Will be updated after request creation
      });

      // Store idempotency key in request for later use
      req.idempotencyKey = idempotencyKey;

      next();
    } catch (error) {
      console.error('Error in idempotency middleware:', error);
      // On error, allow request to proceed (fail open)
      next();
    }
  };
}

/**
 * Check if idempotency key exists and return the request ID
 * @param {String} idempotencyKey - Idempotency key
 * @returns {String|null} Request ID if exists, null otherwise
 */
async function checkIdempotency(idempotencyKey) {
  // Check in-memory cache first
  const cachedEntry = idempotencyCache.get(idempotencyKey);
  if (cachedEntry && cachedEntry.requestId) {
    return cachedEntry.requestId;
  }

  // Check database for existing request with this key
  try {
    const deposit = await Deposit.findOne({ idempotencyKey });
    if (deposit) {
      return deposit._id.toString();
    }

    const withdraw = await Withdraw.findOne({ idempotencyKey });
    if (withdraw) {
      return withdraw._id.toString();
    }
  } catch (error) {
    console.error('Error checking idempotency:', error);
  }

  return null;
}

/**
 * Update idempotency cache with request ID
 * @param {String} idempotencyKey - Idempotency key
 * @param {String} requestId - Created request ID
 */
function updateIdempotencyCache(idempotencyKey, requestId) {
  const entry = idempotencyCache.get(idempotencyKey);
  if (entry) {
    entry.requestId = requestId;
  } else {
    // Create new entry if it doesn't exist
    idempotencyCache.set(idempotencyKey, {
      timestamp: Date.now(),
      requestId: requestId,
    });
  }
}

/**
 * Clean up expired cache entries (run periodically)
 */
function cleanupCache() {
  const now = Date.now();
  for (const [key, entry] of idempotencyCache.entries()) {
    if (now - entry.timestamp > DUPLICATE_TTL) {
      idempotencyCache.delete(key);
    }
  }
}

// Run cleanup every 10 seconds
setInterval(cleanupCache, 10000);

export { idempotencyMiddleware, updateIdempotencyCache, checkIdempotency };
