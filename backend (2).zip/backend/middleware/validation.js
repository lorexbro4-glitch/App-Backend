import Joi from 'joi';

// Validation middleware factory
const validate = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
      convert: true,
    });

    if (error) {
      const details = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message.replace(/"/g, ''),
      }));

      // Use the first specific error message as the top-level message
      const firstMessage = details[0]?.message || 'সঠিক তথ্য দিন';

      return res.status(400).json({
        success: false,
        message: firstMessage,
        error: {
          code: 'VALIDATION_ERROR',
          message: firstMessage,
          details,
          timestamp: new Date().toISOString(),
        },
      });
    }

    // Replace req.body with sanitized value
    req.body = value;
    next();
  };
};

// Common validation schemas
const schemas = {
  // Deposit validation
  deposit: Joi.object({
    amount: Joi.number().min(500).max(1000000).required()
      .messages({
        'number.min': 'Amount must be at least 500',
        'number.max': 'Amount cannot exceed 1,000,000',
        'any.required': 'Amount is required',
      }),
    method: Joi.string().valid('Bkash', 'Nagad', 'Rocket').optional(),
    paymentMethod: Joi.string().valid('Bkash', 'Nagad', 'Rocket').optional(),
    transactionId: Joi.string().max(100).optional().allow(null, '')
      .messages({
        'string.max': 'ট্রানজেকশন আইডি সর্বোচ্চ ১০০ অক্ষরের হতে পারবে',
      }),
    senderNumber: Joi.string().pattern(/^01[0-9]{9}$/).optional()
      .messages({ 'string.pattern.base': 'সঠিক ফোন নম্বর লিখুন (০১ দিয়ে শুরু, ১১ ডিজিট)' }),
    phoneNumber: Joi.string().pattern(/^01[0-9]{9}$/).optional()
      .messages({ 'string.pattern.base': 'সঠিক ফোন নম্বর লিখুন (০১ দিয়ে শুরু, ১১ ডিজিট)' }),
    screenshot: Joi.string().optional().allow(null, ''),
    idempotencyKey: Joi.string().optional(),
  }).or('method', 'paymentMethod').or('senderNumber', 'phoneNumber')
    .messages({
      'object.missing': 'Either method or paymentMethod is required, and either senderNumber or phoneNumber is required',
    }),

  // Withdrawal validation
  withdrawal: Joi.object({
    amount: Joi.number().min(500).max(1000000).required()
      .messages({
        'number.min': 'ন্যূনতম ৫০০ টাকা উইথড্র করুন',
        'number.max': 'একবারে সর্বোচ্চ ১০,০০,০০০ টাকা উইথড্র করতে পারবেন',
        'any.required': 'পরিমাণ লিখুন',
      }),
    type: Joi.string().valid('profit', 'capital').required()
      .messages({
        'any.only': 'উইথড্র ধরন সঠিক নয়',
        'any.required': 'উইথড্র ধরন নির্বাচন করুন',
      }),
    method: Joi.string().valid('Bkash', 'Nagad', 'Rocket').required()
      .messages({
        'any.only': 'পেমেন্ট মেথড Bkash, Nagad বা Rocket হতে হবে',
        'any.required': 'পেমেন্ট মেথড নির্বাচন করুন',
      }),
    accountNumber: Joi.string().pattern(/^01[0-9]{9}$/).required()
      .messages({
        'string.pattern.base': 'সঠিক অ্যাকাউন্ট নম্বর লিখুন (০১ দিয়ে শুরু, ১১ ডিজিট)',
        'any.required': 'অ্যাকাউন্ট নম্বর লিখুন',
      }),
    withdrawPassword: Joi.string().min(4).max(6).required()
      .messages({
        'string.min': 'উইথড্র পাসওয়ার্ড কমপক্ষে ৪ ডিজিটের হতে হবে',
        'string.max': 'উইথড্র পাসওয়ার্ড সর্বোচ্চ ৬ ডিজিটের হতে পারবে',
        'any.required': 'উইথড্র পাসওয়ার্ড দিন',
      }),
    idempotencyKey: Joi.string().optional(),
  }),

  // User registration validation
  register: Joi.object({
    email: Joi.string().email().required()
      .messages({
        'string.email': 'Invalid email format',
        'any.required': 'Email is required',
      }),
    password: Joi.string().min(6).max(50).required()
      .messages({
        'string.min': 'Password must be at least 6 characters',
        'string.max': 'Password cannot exceed 50 characters',
        'any.required': 'Password is required',
      }),
    name: Joi.string().min(2).max(100).optional().allow(''),
    referralCode: Joi.string().length(8).optional().allow(''),
    phone: Joi.string().pattern(/^01[0-9]{9}$/).optional(),
  }),

  // User login validation
  login: Joi.object({
    email: Joi.string().email().optional(),
    phone: Joi.string().pattern(/^01[0-9]{9}$/).optional(),
    password: Joi.string().required()
      .messages({
        'any.required': 'Password is required',
      }),
  }).or('email', 'phone')
    .messages({
      'object.missing': 'Either email or phone is required',
    }),

  // Profile update validation
  profileUpdate: Joi.object({
    name: Joi.string().min(2).max(100).optional(),
    email: Joi.string().email().optional(),
    phone: Joi.string().pattern(/^01[0-9]{9}$/).optional(),
    profilePicture: Joi.string().uri().optional().allow(null, ''),
  }),
};

export { validate, schemas };
