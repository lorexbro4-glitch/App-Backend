import cacheService from '../services/cacheService.js';

/**
 * Cache Middleware
 * Provides request-level caching for API endpoints
 */

/**
 * Cache middleware factory
 * @param {number} ttl - Time to live in seconds
 * @param {function} keyGenerator - Function to generate cache key from request
 * @returns {function} Express middleware
 */
function cacheMiddleware(ttl, keyGenerator = null) {
  return async (req, res, next) => {
    try {
      // Generate cache key
      const cacheKey = keyGenerator 
        ? keyGenerator(req) 
        : `${req.method}:${req.originalUrl}`;

      // Try to get cached response
      const cachedData = await cacheService.get(cacheKey);
      
      if (cachedData) {
        // Cache hit - return cached response
        return res.json(cachedData);
      }

      // Cache miss - store original res.json
      const originalJson = res.json.bind(res);
      
      // Override res.json to cache the response
      res.json = function(data) {
        // Cache the response data
        cacheService.set(cacheKey, data, ttl).catch(err => {
          console.error('Cache set error:', err);
        });
        
        // Send the response
        return originalJson(data);
      };

      next();
    } catch (error) {
      console.error('Cache middleware error:', error);
      // Don't fail the request if caching fails
      next();
    }
  };
}

/**
 * Invalidate cache by pattern
 * @param {string} pattern - Cache key pattern to invalidate
 */
async function invalidateCache(pattern) {
  try {
    await cacheService.delPattern(pattern);
  } catch (error) {
    console.error('Cache invalidation error:', error);
  }
}

/**
 * Invalidate cache by exact key
 * @param {string} key - Cache key to invalidate
 */
async function invalidateCacheKey(key) {
  try {
    await cacheService.del(key);
  } catch (error) {
    console.error('Cache key invalidation error:', error);
  }
}

export { cacheMiddleware, invalidateCache, invalidateCacheKey };
