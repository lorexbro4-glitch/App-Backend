const mongoose = require('mongoose');
require('dotenv').config();

const Deposit = require('./models/Deposit');
const Verification = require('./models/Verification');

async function cleanupImages() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/investment-app');
    console.log('Connected to MongoDB');

    // Clean up deposit screenshots (approved and rejected)
    const depositResult = await Deposit.updateMany(
      { 
        status: { $in: ['approved', 'rejected'] },
        screenshot: { $ne: null }
      },
      { 
        $set: { screenshot: null }
      }
    );
    console.log(`✅ Cleaned ${depositResult.modifiedCount} deposit screenshots`);

    // Clean up verification images (approved and rejected)
    const verificationResult = await Verification.updateMany(
      { 
        status: { $in: ['approved', 'rejected'] },
        $or: [
          { nidFrontImage: { $ne: null } },
          { nidBackImage: { $ne: null } },
          { selfieImage: { $ne: null } },
          { nidFront: { $ne: null } },
          { nidBack: { $ne: null } },
          { selfie: { $ne: null } }
        ]
      },
      { 
        $set: { 
          nidFrontImage: null,
          nidBackImage: null,
          selfieImage: null,
          nidFront: null,
          nidBack: null,
          selfie: null
        }
      }
    );
    console.log(`✅ Cleaned ${verificationResult.modifiedCount} verification image sets (3 images each)`);

    // Calculate space saved (rough estimate)
    const depositSpaceSaved = depositResult.modifiedCount * 1.5; // ~1.5 MB per deposit screenshot
    const verificationSpaceSaved = verificationResult.modifiedCount * 4.5; // ~4.5 MB per verification (3 images)
    const totalSpaceSaved = depositSpaceSaved + verificationSpaceSaved;

    console.log(`\n📊 STORAGE SAVED:`);
    console.log(`   Deposits: ~${depositSpaceSaved.toFixed(1)} MB`);
    console.log(`   Verifications: ~${verificationSpaceSaved.toFixed(1)} MB`);
    console.log(`   TOTAL: ~${totalSpaceSaved.toFixed(1)} MB freed! 🎉`);

    await mongoose.connection.close();
    console.log('\n✅ Cleanup complete! Database connection closed.');
  } catch (error) {
    console.error('❌ Cleanup error:', error);
    process.exit(1);
  }
}

cleanupImages();
