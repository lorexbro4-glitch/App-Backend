import NodeCache from 'node-cache';
import logger from '../config/logger.js';

class CacheService {
  constructor() {
    // Initialize NodeCache as fallback
    this.nodeCache = new NodeCache({
      stdTTL: 300, // Default 5 minutes
      checkperiod: 60, // Check for expired keys every 60 seconds
      useClones: false, // Better performance
    });

    this.redis = null;
    this.cacheType = 'node-cache';
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0,
    };

    // Try to initialize Redis if available
    this.initRedis();
  }

  async initRedis() {
    try {
      if (process.env.REDIS_URL) {
        const { createClient } = await import('redis');
        this.redis = createClient({
          url: process.env.REDIS_URL,
        });

        this.redis.on('error', (err) => {
          logger.error('Redis error:', err);
          this.redis = null;
          this.cacheType = 'node-cache';
        });

        this.redis.on('connect', () => {
          logger.info('✅ Redis connected');
          this.cacheType = 'redis';
        });

        await this.redis.connect();
      }
    } catch (error) {
      logger.warn('Redis not available, using NodeCache fallback:', error.message);
      this.redis = null;
      this.cacheType = 'node-cache';
    }
  }

  async get(key) {
    try {
      let value;

      if (this.redis && this.cacheType === 'redis') {
        value = await this.redis.get(key);
        if (value) {
          value = JSON.parse(value);
        }
      } else {
        value = this.nodeCache.get(key);
      }

      if (value !== undefined && value !== null) {
        this.stats.hits++;
        return value;
      }

      this.stats.misses++;
      return null;
    } catch (error) {
      logger.error('Cache get error:', error);
      this.stats.misses++;
      return null;
    }
  }

  async set(key, value, ttl = 300) {
    try {
      if (this.redis && this.cacheType === 'redis') {
        await this.redis.setEx(key, ttl, JSON.stringify(value));
      } else {
        this.nodeCache.set(key, value, ttl);
      }

      this.stats.sets++;
      return true;
    } catch (error) {
      logger.error('Cache set error:', error);
      return false;
    }
  }

  async del(key) {
    try {
      if (this.redis && this.cacheType === 'redis') {
        await this.redis.del(key);
      } else {
        this.nodeCache.del(key);
      }

      this.stats.deletes++;
      return true;
    } catch (error) {
      logger.error('Cache delete error:', error);
      return false;
    }
  }

  async delPattern(pattern) {
    try {
      if (this.redis && this.cacheType === 'redis') {
        const keys = await this.redis.keys(pattern);
        if (keys.length > 0) {
          await this.redis.del(keys);
        }
      } else {
        // NodeCache doesn't support pattern deletion, delete all keys matching pattern
        const keys = this.nodeCache.keys();
        const regex = new RegExp(pattern.replace('*', '.*'));
        keys.forEach(key => {
          if (regex.test(key)) {
            this.nodeCache.del(key);
          }
        });
      }

      this.stats.deletes++;
      return true;
    } catch (error) {
      logger.error('Cache delete pattern error:', error);
      return false;
    }
  }

  async flush() {
    try {
      if (this.redis && this.cacheType === 'redis') {
        await this.redis.flushAll();
      } else {
        this.nodeCache.flushAll();
      }

      return true;
    } catch (error) {
      logger.error('Cache flush error:', error);
      return false;
    }
  }

  getStats() {
    const hitRate = this.stats.hits + this.stats.misses > 0
      ? (this.stats.hits / (this.stats.hits + this.stats.misses)).toFixed(2)
      : 0;

    return {
      type: this.cacheType,
      hitRate: parseFloat(hitRate),
      totalHits: this.stats.hits,
      totalMisses: this.stats.misses,
      totalSets: this.stats.sets,
      totalDeletes: this.stats.deletes,
      totalKeys: this.cacheType === 'redis' ? 'N/A' : this.nodeCache.keys().length,
    };
  }
}

// Export singleton instance
export default new CacheService();
