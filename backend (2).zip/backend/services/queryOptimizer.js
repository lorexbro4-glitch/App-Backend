/**
 * Query Optimizer Service
 * Provides optimized query methods using .lean(), .select(), .populate()
 */

class QueryOptimizer {
  /**
   * Find documents with optimization
   * @param {Model} model - Mongoose model
   * @param {Object} query - Query filter
   * @param {Object} options - Optimization options
   * @returns {Promise<Array>} Query results
   */
  async findOptimized(model, query = {}, options = {}) {
    const {
      select = null,
      populate = null,
      sort = null,
      limit = null,
      skip = null,
      lean = true
    } = options;

    let queryBuilder = model.find(query);

    // Apply field selection
    if (select) {
      queryBuilder = queryBuilder.select(select);
    }

    // Apply population with field selection
    if (populate) {
      if (Array.isArray(populate)) {
        populate.forEach(pop => {
          queryBuilder = queryBuilder.populate(pop);
        });
      } else {
        queryBuilder = queryBuilder.populate(populate);
      }
    }

    // Apply sorting
    if (sort) {
      queryBuilder = queryBuilder.sort(sort);
    }

    // Apply pagination
    if (skip !== null) {
      queryBuilder = queryBuilder.skip(skip);
    }
    if (limit !== null) {
      queryBuilder = queryBuilder.limit(limit);
    }

    // Apply lean for read-only queries
    if (lean) {
      queryBuilder = queryBuilder.lean();
    }

    const startTime = Date.now();
    const results = await queryBuilder.exec();
    const duration = Date.now() - startTime;

    // Log slow queries (> 100ms)
    if (duration > 100) {
      console.warn(`Slow query detected: ${model.modelName}.find() took ${duration}ms`);
    }

    return results;
  }

  /**
   * Find one document with optimization
   * @param {Model} model - Mongoose model
   * @param {Object} query - Query filter
   * @param {Object} options - Optimization options
   * @returns {Promise<Object|null>} Query result
   */
  async findOneOptimized(model, query = {}, options = {}) {
    const {
      select = null,
      populate = null,
      lean = true
    } = options;

    let queryBuilder = model.findOne(query);

    if (select) {
      queryBuilder = queryBuilder.select(select);
    }

    if (populate) {
      if (Array.isArray(populate)) {
        populate.forEach(pop => {
          queryBuilder = queryBuilder.populate(pop);
        });
      } else {
        queryBuilder = queryBuilder.populate(populate);
      }
    }

    if (lean) {
      queryBuilder = queryBuilder.lean();
    }

    const startTime = Date.now();
    const result = await queryBuilder.exec();
    const duration = Date.now() - startTime;

    if (duration > 100) {
      console.warn(`Slow query detected: ${model.modelName}.findOne() took ${duration}ms`);
    }

    return result;
  }

  /**
   * Optimized population helper
   * @param {Query} query - Mongoose query
   * @param {string} path - Path to populate
   * @param {string} select - Fields to select from populated document
   * @returns {Query} Modified query
   */
  populateOptimized(query, path, select = null) {
    if (select) {
      return query.populate(path, select);
    }
    return query.populate(path);
  }

  /**
   * Iterate over large datasets using cursor
   * @param {Model} model - Mongoose model
   * @param {Object} query - Query filter
   * @param {function} callback - Function to process each document
   * @param {Object} options - Query options
   */
  async iterateCursor(model, query = {}, callback, options = {}) {
    const {
      select = null,
      batchSize = 100
    } = options;

    let queryBuilder = model.find(query);

    if (select) {
      queryBuilder = queryBuilder.select(select);
    }

    const cursor = queryBuilder.cursor({ batchSize });
    let processedCount = 0;

    try {
      for (let doc = await cursor.next(); doc != null; doc = await cursor.next()) {
        await callback(doc);
        processedCount++;
      }
      
      console.log(`Processed ${processedCount} documents using cursor`);
    } catch (error) {
      console.error('Cursor iteration error:', error);
      throw error;
    }
  }

  /**
   * Count documents with optimization
   * @param {Model} model - Mongoose model
   * @param {Object} query - Query filter
   * @returns {Promise<number>} Document count
   */
  async countOptimized(model, query = {}) {
    const startTime = Date.now();
    const count = await model.countDocuments(query);
    const duration = Date.now() - startTime;

    if (duration > 100) {
      console.warn(`Slow count query detected: ${model.modelName}.countDocuments() took ${duration}ms`);
    }

    return count;
  }

  /**
   * Aggregate with optimization
   * @param {Model} model - Mongoose model
   * @param {Array} pipeline - Aggregation pipeline
   * @returns {Promise<Array>} Aggregation results
   */
  async aggregateOptimized(model, pipeline) {
    const startTime = Date.now();
    const results = await model.aggregate(pipeline);
    const duration = Date.now() - startTime;

    if (duration > 100) {
      console.warn(`Slow aggregation detected: ${model.modelName}.aggregate() took ${duration}ms`);
    }

    return results;
  }
}

export default new QueryOptimizer();
