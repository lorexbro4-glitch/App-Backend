import nodemailer from 'nodemailer';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Admin email address
const ADMIN_EMAIL = process.env.ADMIN_NOTIFICATION_EMAIL || 'shakibatlas@gmail.com';

/**
 * Send admin notification email
 */
async function sendAdminEmail(subject, htmlContent) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: ADMIN_EMAIL,
    subject: subject,
    html: htmlContent
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Admin email notification sent successfully');
  } catch (error) {
    console.error('Error sending admin email notification:', error.message);
  }
}

/**
 * Send deposit request notification to admin
 */
async function notifyAdminDepositRequest(deposit) {
  const subject = '🔔 New Deposit Request - YFBD';
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8fafc;">
      <div style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <div style="text-align: center; margin-bottom: 25px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">Admin Notification</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 20px; text-align: center; border-radius: 8px; margin-bottom: 25px;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">🔔 New Deposit Request</h2>
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">💰 Amount:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">৳${deposit.amount}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">💳 Method:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${deposit.method}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">👤 User:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${deposit.userName || 'N/A'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📱 Phone:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${deposit.userPhone || 'N/A'}</td>
          </tr>
          <tr>
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📅 Date:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${new Date(deposit.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}</td>
          </tr>
        </table>
        
        <div style="text-align: center; margin-top: 30px;">
          <a href="https://bilibilibot.com/admin/deposits" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">Check BiliBiliBot</a>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD - Admin Panel</p>
        </div>
      </div>
    </div>
  `;

  await sendAdminEmail(subject, htmlContent);
}

/**
 * Send withdrawal request notification to admin
 */
async function notifyAdminWithdrawRequest(withdraw) {
  const subject = '🔔 New Withdrawal Request - YFBD';
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8fafc;">
      <div style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <div style="text-align: center; margin-bottom: 25px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">Admin Notification</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 20px; text-align: center; border-radius: 8px; margin-bottom: 25px;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">🔔 New Withdrawal Request</h2>
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">💰 Amount:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">৳${withdraw.amount}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">💳 Method:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${withdraw.method}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📝 Type:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${withdraw.type === 'profit' ? 'Profit' : 'Capital'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">👤 User:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${withdraw.userName || 'N/A'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📱 Phone:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${withdraw.userPhone || 'N/A'}</td>
          </tr>
          <tr>
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📅 Date:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${new Date(withdraw.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}</td>
          </tr>
        </table>
        
        <div style="text-align: center; margin-top: 30px;">
          <a href="https://bilibilibot.com/admin/withdrawals" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">Check BiliBiliBot</a>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD - Admin Panel</p>
        </div>
      </div>
    </div>
  `;

  await sendAdminEmail(subject, htmlContent);
}

/**
 * Send verification request notification to admin
 */
async function notifyAdminVerificationRequest(verification) {
  const subject = '🔔 New Verification Request - YFBD';
  const htmlContent = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8fafc;">
      <div style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <div style="text-align: center; margin-bottom: 25px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">Admin Notification</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 20px; text-align: center; border-radius: 8px; margin-bottom: 25px;">
          <h2 style="color: #ffffff; margin: 0; font-size: 20px;">🔔 New Verification Request</h2>
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">👤 User:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${verification.userName || 'N/A'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📱 Phone:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${verification.userPhone || 'N/A'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">🆔 NID:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${verification.nidNumber || 'N/A'}</td>
          </tr>
          <tr>
            <td style="padding: 12px 0; color: #64748b; font-weight: 600;">📅 Date:</td>
            <td style="padding: 12px 0; color: #1e293b; font-weight: bold; text-align: right;">${new Date(verification.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}</td>
          </tr>
        </table>
        
        <div style="text-align: center; margin-top: 30px;">
          <a href="https://bilibilibot.com/admin/verifications" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">Check BiliBiliBot</a>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD - Admin Panel</p>
        </div>
      </div>
    </div>
  `;

  await sendAdminEmail(subject, htmlContent);
}

export {
  sendAdminEmail,
  notifyAdminDepositRequest,
  notifyAdminWithdrawRequest,
  notifyAdminVerificationRequest,
};
