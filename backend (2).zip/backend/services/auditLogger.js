import AuditLog from '../models/AuditLog.js';

/**
 * Audit Logger Service
 * Records all administrative actions for compliance and security
 */

class AuditLogger {
  /**
   * Log an administrative action
   * @param {string} action - Action type (e.g., 'user.update', 'deposit.approve')
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} resourceType - Resource type (User, Deposit, Withdraw, etc.)
   * @param {string} resourceId - Resource ID
   * @param {Object} changes - Before/after state for updates
   * @param {Object} metadata - Additional metadata (reason, requestId, etc.)
   * @param {Object} req - Express request object (for IP and user agent)
   * @returns {Promise<Object>} Created audit log entry
   */
  async logAction(action, adminId, adminEmail, resourceType, resourceId, changes = {}, metadata = {}, req = null) {
    try {
      const auditEntry = {
        action,
        adminId,
        adminEmail,
        resourceType,
        resourceId,
        timestamp: new Date(),
        changes,
        metadata
      };

      // Extract IP address and user agent from request if available
      if (req) {
        auditEntry.ipAddress = req.ip || req.connection.remoteAddress || null;
        auditEntry.userAgent = req.get('user-agent') || null;
      }

      const auditLog = await AuditLog.create(auditEntry);
      
      console.log(`[AUDIT] ${action} by ${adminEmail} on ${resourceType}:${resourceId}`);
      
      return auditLog;
    } catch (error) {
      console.error('Audit logging error:', error);
      // Don't throw error - audit logging should not break the main operation
      return null;
    }
  }

  /**
   * Log user creation
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} userId - Created user ID
   * @param {Object} userData - User data
   * @param {Object} req - Express request object
   */
  async logUserCreate(adminId, adminEmail, userId, userData, req = null) {
    return this.logAction(
      'user.create',
      adminId,
      adminEmail,
      'User',
      userId,
      { after: userData },
      {},
      req
    );
  }

  /**
   * Log user update
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} userId - Updated user ID
   * @param {Object} before - User data before update
   * @param {Object} after - User data after update
   * @param {Object} req - Express request object
   */
  async logUserUpdate(adminId, adminEmail, userId, before, after, req = null) {
    return this.logAction(
      'user.update',
      adminId,
      adminEmail,
      'User',
      userId,
      { before, after },
      {},
      req
    );
  }

  /**
   * Log user deletion
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} userId - Deleted user ID
   * @param {Object} userData - User data before deletion
   * @param {Object} req - Express request object
   */
  async logUserDelete(adminId, adminEmail, userId, userData, req = null) {
    return this.logAction(
      'user.delete',
      adminId,
      adminEmail,
      'User',
      userId,
      { before: userData },
      {},
      req
    );
  }

  /**
   * Log deposit approval
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} depositId - Deposit ID
   * @param {number} amount - Deposit amount
   * @param {Object} req - Express request object
   */
  async logDepositApprove(adminId, adminEmail, depositId, amount, req = null) {
    return this.logAction(
      'deposit.approve',
      adminId,
      adminEmail,
      'Deposit',
      depositId,
      { before: { status: 'pending' }, after: { status: 'approved' } },
      { amount },
      req
    );
  }

  /**
   * Log deposit rejection
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} depositId - Deposit ID
   * @param {number} amount - Deposit amount
   * @param {string} reason - Rejection reason
   * @param {Object} req - Express request object
   */
  async logDepositReject(adminId, adminEmail, depositId, amount, reason, req = null) {
    return this.logAction(
      'deposit.reject',
      adminId,
      adminEmail,
      'Deposit',
      depositId,
      { before: { status: 'pending' }, after: { status: 'rejected' } },
      { amount, reason },
      req
    );
  }

  /**
   * Log withdrawal approval
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} withdrawalId - Withdrawal ID
   * @param {number} amount - Withdrawal amount
   * @param {Object} req - Express request object
   */
  async logWithdrawalApprove(adminId, adminEmail, withdrawalId, amount, req = null) {
    return this.logAction(
      'withdrawal.approve',
      adminId,
      adminEmail,
      'Withdraw',
      withdrawalId,
      { before: { status: 'pending' }, after: { status: 'approved' } },
      { amount },
      req
    );
  }

  /**
   * Log withdrawal rejection
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} withdrawalId - Withdrawal ID
   * @param {number} amount - Withdrawal amount
   * @param {string} reason - Rejection reason
   * @param {Object} req - Express request object
   */
  async logWithdrawalReject(adminId, adminEmail, withdrawalId, amount, reason, req = null) {
    return this.logAction(
      'withdrawal.reject',
      adminId,
      adminEmail,
      'Withdraw',
      withdrawalId,
      { before: { status: 'pending' }, after: { status: 'rejected' } },
      { amount, reason },
      req
    );
  }

  /**
   * Log settings update
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} settingsId - Settings ID
   * @param {Object} before - Settings before update
   * @param {Object} after - Settings after update
   * @param {Object} req - Express request object
   */
  async logSettingsUpdate(adminId, adminEmail, settingsId, before, after, req = null) {
    return this.logAction(
      'settings.update',
      adminId,
      adminEmail,
      'Settings',
      settingsId,
      { before, after },
      {},
      req
    );
  }

  /**
   * Log gift to user
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} userId - User ID
   * @param {number} amount - Gift amount
   * @param {Object} req - Express request object
   */
  async logUserGift(adminId, adminEmail, userId, amount, req = null) {
    return this.logAction(
      'user.gift',
      adminId,
      adminEmail,
      'User',
      userId,
      {},
      { amount },
      req
    );
  }

  /**
   * Log verification approval
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} verificationId - Verification ID
   * @param {string} userName - User name from verification
   * @param {string} nidNumber - NID number
   * @param {Object} req - Express request object
   */
  async logVerificationApprove(adminId, adminEmail, verificationId, userName, nidNumber, req = null) {
    return this.logAction(
      'verification.approve',
      adminId,
      adminEmail,
      'Verification',
      verificationId,
      { before: { status: 'pending' }, after: { status: 'approved' } },
      { userName, nidNumber },
      req
    );
  }

  /**
   * Log verification rejection
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} verificationId - Verification ID
   * @param {string} userName - User name from verification
   * @param {string} nidNumber - NID number
   * @param {string} reason - Rejection reason
   * @param {Object} req - Express request object
   */
  async logVerificationReject(adminId, adminEmail, verificationId, userName, nidNumber, reason, req = null) {
    return this.logAction(
      'verification.reject',
      adminId,
      adminEmail,
      'Verification',
      verificationId,
      { before: { status: 'pending' }, after: { status: 'rejected' } },
      { userName, nidNumber, reason },
      req
    );
  }

  /**
   * Log agent approval
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} agentId - Agent ID
   * @param {string} agentName - Agent name
   * @param {string} agentEmail - Agent email
   * @param {Object} req - Express request object
   */
  async logAgentApprove(adminId, adminEmail, agentId, agentName, agentEmail, req = null) {
    return this.logAction(
      'agent.approve',
      adminId,
      adminEmail,
      'Agent',
      agentId,
      { before: { approvalStatus: 'pending' }, after: { approvalStatus: 'approved' } },
      { agentName, agentEmail },
      req
    );
  }

  /**
   * Log agent rejection
   * @param {string} adminId - Admin user ID
   * @param {string} adminEmail - Admin email
   * @param {string} agentId - Agent ID
   * @param {string} agentName - Agent name
   * @param {string} agentEmail - Agent email
   * @param {string} reason - Rejection reason
   * @param {Object} req - Express request object
   */
  async logAgentReject(adminId, adminEmail, agentId, agentName, agentEmail, reason, req = null) {
    return this.logAction(
      'agent.reject',
      adminId,
      adminEmail,
      'Agent',
      agentId,
      { before: { approvalStatus: 'pending' }, after: { approvalStatus: 'rejected' } },
      { agentName, agentEmail, reason },
      req
    );
  }

  /**
   * Query audit logs with filters and pagination
   * @param {Object} filters - Query filters
   * @param {Object} pagination - Pagination options
   * @returns {Promise<Object>} Paginated audit logs
   */
  async queryLogs(filters = {}, pagination = {}) {
    try {
      const query = {};
      
      // Apply filters
      if (filters.action) {
        query.action = filters.action;
      }
      
      if (filters.adminId) {
        query.adminId = filters.adminId;
      }
      
      if (filters.resourceType) {
        query.resourceType = filters.resourceType;
      }
      
      if (filters.resourceId) {
        query.resourceId = filters.resourceId;
      }
      
      // Date range filter
      if (filters.startDate || filters.endDate) {
        query.timestamp = {};
        if (filters.startDate) {
          query.timestamp.$gte = new Date(filters.startDate);
        }
        if (filters.endDate) {
          query.timestamp.$lte = new Date(filters.endDate);
        }
      }
      
      // Manual pagination
      const page = pagination.page || 1;
      const pageSize = pagination.pageSize || 20;
      const skip = (page - 1) * pageSize;
      
      const [data, totalCount] = await Promise.all([
        AuditLog.find(query)
          .populate('adminId', 'name email')
          .sort({ timestamp: -1 })
          .skip(skip)
          .limit(pageSize)
          .lean(),
        AuditLog.countDocuments(query)
      ]);
      
      const totalPages = Math.ceil(totalCount / pageSize);
      
      return {
        success: true,
        data,
        pagination: {
          page,
          pageSize,
          totalCount,
          totalPages,
          hasNext: page < totalPages,
          hasPrevious: page > 1
        }
      };
    } catch (error) {
      console.error('Query audit logs error:', error);
      throw error;
    }
  }

  /**
   * Cleanup old audit logs (older than 365 days)
   * This is handled automatically by MongoDB TTL index, but can be called manually
   * @returns {Promise<number>} Number of deleted logs
   */
  async cleanupOldLogs() {
    try {
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      
      const result = await AuditLog.deleteMany({
        timestamp: { $lt: oneYearAgo }
      });
      
      console.log(`Cleaned up ${result.deletedCount} old audit logs`);
      return result.deletedCount;
    } catch (error) {
      console.error('Cleanup old logs error:', error);
      throw error;
    }
  }

  /**
   * Get audit log statistics
   * @param {Object} filters - Query filters
   * @returns {Promise<Object>} Statistics
   */
  async getStats(filters = {}) {
    try {
      const query = {};
      
      // Apply date range filter
      if (filters.startDate || filters.endDate) {
        query.timestamp = {};
        if (filters.startDate) {
          query.timestamp.$gte = new Date(filters.startDate);
        }
        if (filters.endDate) {
          query.timestamp.$lte = new Date(filters.endDate);
        }
      }
      
      // Get total count
      const totalCount = await AuditLog.countDocuments(query);
      
      // Get counts by action
      const actionCounts = await AuditLog.aggregate([
        { $match: query },
        { $group: { _id: '$action', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]);
      
      // Get counts by admin
      const adminCounts = await AuditLog.aggregate([
        { $match: query },
        { $group: { _id: '$adminEmail', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 10 }
      ]);
      
      // Get counts by resource type
      const resourceCounts = await AuditLog.aggregate([
        { $match: query },
        { $group: { _id: '$resourceType', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
      ]);
      
      return {
        totalCount,
        actionCounts,
        adminCounts,
        resourceCounts
      };
    } catch (error) {
      console.error('Get audit stats error:', error);
      throw error;
    }
  }
}

export default new AuditLogger();
