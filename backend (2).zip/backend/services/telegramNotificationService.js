import TelegramBot from 'node-telegram-bot-api';

// Telegram Bot Configuration
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8669019193:AAEBmIL6mFKM0uOTfVaEXROpU-mVdiOey8g';
const ADMIN_CHAT_ID = process.env.TELEGRAM_ADMIN_CHAT_ID || '8311220878';

// Initialize bot
const bot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: false });

/**
 * Send notification to admin via Telegram
 */
async function sendTelegramNotification(message) {
  try {
    await bot.sendMessage(ADMIN_CHAT_ID, message, { parse_mode: 'HTML' });
    console.log('Telegram notification sent successfully');
  } catch (error) {
    console.error('Error sending Telegram notification:', error.message);
  }
}

/**
 * Send deposit request notification
 */
async function notifyDepositRequest(deposit) {
  const message = `
🔔 <b>New Deposit Request</b>

💰 <b>Amount:</b> ৳${deposit.amount}
💳 <b>Method:</b> ${deposit.method}
👤 <b>User:</b> ${deposit.userName || 'N/A'}
📱 <b>Phone:</b> ${deposit.userPhone || 'N/A'}
📅 <b>Date:</b> ${new Date(deposit.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}

<a href="https://bilibilibot.com/admin/deposits">Check BiliBiliBot</a>
  `.trim();

  await sendTelegramNotification(message);
}

/**
 * Send withdrawal request notification
 */
async function notifyWithdrawRequest(withdraw) {
  const message = `
🔔 <b>New Withdrawal Request</b>

� <b>Name:</b> ${withdraw.userName || 'N/A'}
� <b>Amount:</b> ৳${withdraw.amount}
� <b>Method:</b> ${withdraw.method}
� <b>Withdraw Number:</b> ${withdraw.accountNumber || 'N/A'}
📅 <b>Time:</b> ${new Date(withdraw.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}
  `.trim();

  await sendTelegramNotification(message);
}

/**
 * Send verification request notification
 */
async function notifyVerificationRequest(verification) {
  const message = `
🔔 <b>New Verification Request</b>

👤 <b>User:</b> ${verification.userName || 'N/A'}
📱 <b>Phone:</b> ${verification.userPhone || 'N/A'}
🆔 <b>NID:</b> ${verification.nidNumber || 'N/A'}
📅 <b>Date:</b> ${new Date(verification.createdAt).toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}

<a href="https://bilibilibot.com/admin/verifications">Check BiliBiliBot</a>
  `.trim();

  await sendTelegramNotification(message);
}

export {
  sendTelegramNotification,
  notifyDepositRequest,
  notifyWithdrawRequest,
  notifyVerificationRequest,
  notifySupportMessage,
};

/**
 * Send support message notification
 */
async function notifySupportMessage(userName, userPhone, messagePreview, isFirstMessage = false) {
  const label = isFirstMessage ? '🆕 New Support Ticket' : '💬 New Support Message';
  const message = `
${label}

👤 <b>From:</b> ${userName || 'Unknown'}
📱 <b>Phone:</b> ${userPhone || 'N/A'}
📝 <b>Message:</b> ${messagePreview || '(file/image)'}
📅 <b>Time:</b> ${new Date().toLocaleString('en-US', { timeZone: 'Asia/Dhaka' })}
  `.trim();

  await sendTelegramNotification(message);
}
