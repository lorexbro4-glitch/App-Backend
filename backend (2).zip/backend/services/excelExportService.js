import ExcelJS from 'exceljs';
import path from 'path';
import { promises as fs } from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import Transaction from '../models/Transaction.js';
import Deposit from '../models/Deposit.js';
import Withdraw from '../models/Withdraw.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Excel Export Service
 * Generates Excel files from transaction data
 */

class ExcelExportService {
  constructor() {
    this.exportsDir = path.join(__dirname, '../exports');
    this.maxExportSize = 10000; // Maximum 10,000 transactions per export
    this.urlExpirationSeconds = 3600; // 1 hour
    
    // Ensure exports directory exists
    this.ensureExportsDir();
  }

  /**
   * Ensure exports directory exists
   */
  async ensureExportsDir() {
    try {
      await fs.mkdir(this.exportsDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create exports directory:', error);
    }
  }

  /**
   * Generate transaction export
   * @param {string} userId - User ID
   * @param {Object} filters - Export filters
   * @returns {Promise<Object>} Export result with download URL
   */
  async generateTransactionExport(userId, filters = {}) {
    try {
      // Build query
      const query = { user: userId };
      
      // Apply date range filter
      if (filters.startDate || filters.endDate) {
        query.createdAt = {};
        if (filters.startDate) {
          query.createdAt.$gte = new Date(filters.startDate);
        }
        if (filters.endDate) {
          query.createdAt.$lte = new Date(filters.endDate);
        }
      }

      // Fetch all transaction types
      let allTransactions = [];

      // Get transactions from Transaction model
      const transactions = await Transaction.find(query)
        .sort({ createdAt: -1 })
        .limit(this.maxExportSize)
        .lean();

      allTransactions = transactions.map(t => ({
        date: t.createdAt,
        type: this.formatTransactionType(t.type),
        amount: t.amount,
        status: this.formatStatus(t.status || 'completed'),
        reference: t._id.toString(),
        description: t.description || t.note || ''
      }));

      // Get deposits
      const depositQuery = { user: userId };
      if (query.createdAt) {
        depositQuery.createdAt = query.createdAt;
      }
      
      const deposits = await Deposit.find(depositQuery)
        .sort({ createdAt: -1 })
        .limit(this.maxExportSize)
        .lean();

      deposits.forEach(d => {
        allTransactions.push({
          date: d.createdAt,
          type: 'Deposit',
          amount: d.amount,
          status: this.formatStatus(d.status),
          reference: d.transactionId || d._id.toString(),
          description: `${d.method} deposit`
        });
      });

      // Get withdrawals
      const withdrawQuery = { user: userId };
      if (query.createdAt) {
        withdrawQuery.createdAt = query.createdAt;
      }
      
      const withdrawals = await Withdraw.find(withdrawQuery)
        .sort({ createdAt: -1 })
        .limit(this.maxExportSize)
        .lean();

      withdrawals.forEach(w => {
        allTransactions.push({
          date: w.createdAt,
          type: `Withdrawal (${w.type})`,
          amount: w.amount,
          status: this.formatStatus(w.status),
          reference: w._id.toString(),
          description: `${w.method} withdrawal`
        });
      });

      // Sort by date (newest first)
      allTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));

      // Apply type filter if specified
      if (filters.types && Array.isArray(filters.types) && filters.types.length > 0) {
        allTransactions = allTransactions.filter(t => {
          const typeMatch = filters.types.some(filterType => 
            t.type.toLowerCase().includes(filterType.toLowerCase())
          );
          return typeMatch;
        });
      }

      // Limit to max export size
      allTransactions = allTransactions.slice(0, this.maxExportSize);

      // Format transaction data
      const formattedData = this.formatTransactionData(allTransactions);

      // Generate summary
      const summary = this.generateSummary(allTransactions);

      // Create Excel file
      const fileName = await this.createExcelFile(formattedData, summary, filters);

      // Generate download URL
      const downloadUrl = this.createDownloadUrl(fileName);

      // Schedule file cleanup (delete after expiration)
      this.scheduleFileCleanup(fileName, this.urlExpirationSeconds);

      return {
        downloadUrl,
        expiresAt: new Date(Date.now() + this.urlExpirationSeconds * 1000).toISOString(),
        fileName,
        recordCount: allTransactions.length
      };
    } catch (error) {
      console.error('Generate transaction export error:', error);
      throw error;
    }
  }

  /**
   * Format transaction data for Excel
   * @param {Array} transactions - Transaction array
   * @returns {Array} Formatted transaction data
   */
  formatTransactionData(transactions) {
    return transactions.map(t => ({
      Date: this.formatDate(t.date),
      Type: t.type,
      Amount: this.formatCurrency(t.amount),
      Status: t.status,
      Reference: t.reference,
      Description: t.description
    }));
  }

  /**
   * Generate summary statistics
   * @param {Array} transactions - Transaction array
   * @returns {Object} Summary statistics
   */
  generateSummary(transactions) {
    const summary = {
      totalDeposits: 0,
      totalWithdrawals: 0,
      totalProfit: 0,
      netBalance: 0
    };

    transactions.forEach(t => {
      if (t.type.toLowerCase().includes('deposit')) {
        summary.totalDeposits += t.amount;
      } else if (t.type.toLowerCase().includes('withdrawal')) {
        summary.totalWithdrawals += t.amount;
      } else if (t.type.toLowerCase().includes('profit')) {
        summary.totalProfit += t.amount;
      }
    });

    summary.netBalance = summary.totalDeposits - summary.totalWithdrawals + summary.totalProfit;

    return summary;
  }

  /**
   * Create Excel file
   * @param {Array} data - Formatted transaction data
   * @param {Object} summary - Summary statistics
   * @param {Object} filters - Export filters
   * @returns {Promise<string>} File name
   */
  async createExcelFile(data, summary, filters) {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Transaction History');

    // Set column widths and headers
    worksheet.columns = [
      { header: 'Date', key: 'Date', width: 20 },
      { header: 'Type', key: 'Type', width: 20 },
      { header: 'Amount', key: 'Amount', width: 15 },
      { header: 'Status', key: 'Status', width: 15 },
      { header: 'Reference', key: 'Reference', width: 25 },
      { header: 'Description', key: 'Description', width: 30 }
    ];

    // Style header row
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Add data rows
    data.forEach(row => {
      worksheet.addRow(row);
    });

    // Add summary section
    worksheet.addRow([]);
    worksheet.addRow(['Summary']);
    worksheet.getRow(worksheet.rowCount).font = { bold: true, size: 14 };
    
    worksheet.addRow(['Total Deposits:', this.formatCurrency(summary.totalDeposits)]);
    worksheet.addRow(['Total Withdrawals:', this.formatCurrency(summary.totalWithdrawals)]);
    worksheet.addRow(['Total Profit:', this.formatCurrency(summary.totalProfit)]);
    worksheet.addRow(['Net Balance:', this.formatCurrency(summary.netBalance)]);

    // Generate unique file name
    const timestamp = Date.now();
    const randomStr = crypto.randomBytes(8).toString('hex');
    const dateRange = filters.startDate && filters.endDate 
      ? `_${this.formatDateForFilename(filters.startDate)}_to_${this.formatDateForFilename(filters.endDate)}`
      : '';
    const fileName = `transactions${dateRange}_${timestamp}_${randomStr}.xlsx`;
    const filePath = path.join(this.exportsDir, fileName);

    // Write file
    await workbook.xlsx.writeFile(filePath);

    return fileName;
  }

  /**
   * Create download URL
   * @param {string} fileName - File name
   * @returns {string} Download URL
   */
  createDownloadUrl(fileName) {
    // In production, this should be a signed URL or use a download endpoint
    return `/api/downloads/${fileName}`;
  }

  /**
   * Schedule file cleanup
   * @param {string} fileName - File name
   * @param {number} expirationSeconds - Expiration time in seconds
   */
  scheduleFileCleanup(fileName, expirationSeconds) {
    setTimeout(async () => {
      try {
        const filePath = path.join(this.exportsDir, fileName);
        await fs.unlink(filePath);
        console.log(`Cleaned up expired export file: ${fileName}`);
      } catch (error) {
        console.error(`Failed to cleanup export file ${fileName}:`, error);
      }
    }, expirationSeconds * 1000);
  }

  /**
   * Format date for display
   * @param {Date} date - Date object
   * @returns {string} Formatted date string
   */
  formatDate(date) {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }

  /**
   * Format date for filename
   * @param {Date} date - Date object
   * @returns {string} Formatted date string
   */
  formatDateForFilename(date) {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  /**
   * Format currency amount
   * @param {number} amount - Amount
   * @returns {string} Formatted currency string
   */
  formatCurrency(amount) {
    return `৳${amount.toFixed(2)}`;
  }

  /**
   * Format transaction type
   * @param {string} type - Transaction type
   * @returns {string} Formatted type
   */
  formatTransactionType(type) {
    const typeMap = {
      'deposit': 'Deposit',
      'deposit_request': 'Deposit Request',
      'deposit_approved': 'Deposit Approved',
      'deposit_rejected': 'Deposit Rejected',
      'withdrawal': 'Withdrawal',
      'withdraw_request': 'Withdrawal Request',
      'withdraw_approved': 'Withdrawal Approved',
      'withdraw_rejected': 'Withdrawal Rejected',
      'profit_added': 'Profit Added',
      'referral_bonus': 'Referral Bonus',
      'gift': 'Gift'
    };
    return typeMap[type] || type;
  }

  /**
   * Format status
   * @param {string} status - Status
   * @returns {string} Formatted status
   */
  formatStatus(status) {
    const statusMap = {
      'pending': 'Pending',
      'approved': 'Approved',
      'rejected': 'Rejected',
      'completed': 'Completed',
      'failed': 'Failed'
    };
    return statusMap[status] || status;
  }

  /**
   * Get export file
   * @param {string} fileName - File name
   * @returns {Promise<string>} File path
   */
  async getExportFile(fileName) {
    const filePath = path.join(this.exportsDir, fileName);
    
    // Check if file exists
    try {
      await fs.access(filePath);
      return filePath;
    } catch (error) {
      throw new Error('Export file not found or expired');
    }
  }
}

export default new ExcelExportService();
