/**
 * DEPRECATED: This service is deprecated and redirects to pushNotificationService.js
 * All functions maintain API compatibility but use the unified Expo SDK-based service
 * This file will be removed in a future version after migration is complete
 */

import pushNotificationService from './pushNotificationService.js';
import Notification from '../models/Notification.js';
import User from '../models/User.js';

/**
 * Log deprecation warning
 */
function logDeprecationWarning(functionName) {
  console.warn(`[DEPRECATED] notificationService.${functionName}() is deprecated. Use pushNotificationService instead.`);
}

/**
 * Send push notification using Expo Push Notification Service
 * @deprecated Use pushNotificationService.sendToUser() or sendToAgent() instead
 * @param {string} pushToken - Expo push token
 * @param {string} title - Notification title
 * @param {string} body - Notification body
 * @param {Object} data - Additional data
 */
async function sendPushNotification(pushToken, title, body, data = {}) {
  logDeprecationWarning('sendPushNotification');
  
  // This function is called with a token directly, so we need to find the user/agent
  // For now, we'll just log a warning that this pattern should be avoided
  console.warn('[DEPRECATED] sendPushNotification with raw token is not recommended. Use sendToUser/sendToAgent with userId/agentId instead.');
  
  // Legacy behavior: just log and return
  console.log('Legacy sendPushNotification called with token:', pushToken?.substring(0, 20) + '...');
}

/**
 * Create notification and send push
 * @param {string} userId - User ID
 * @param {string} type - Notification type
 * @param {string} title - Title
 * @param {string} message - Message
 * @param {Object} metadata - Additional metadata
 */
async function createAndSendNotification(userId, type, title, message, metadata = {}) {
  logDeprecationWarning('createAndSendNotification');
  
  // Use pushNotificationService.createAndSendNotification
  return pushNotificationService.createAndSendNotification(userId, type, title, message, metadata);
}

/**
 * Create a notification for registration
 */
async function createRegistrationNotification(userId, userName) {
  logDeprecationWarning('createRegistrationNotification');
  
  return createAndSendNotification(
    userId,
    'registration',
    'স্বাগতম!',
    `${userName}, YFBD তে আপনাকে স্বাগতম! এখন বিনিয়োগ শুরু করুন।`,
    { userName }
  );
}

/**
 * Create a notification for login
 */
async function createLoginNotification(userId) {
  logDeprecationWarning('createLoginNotification');
  
  return createAndSendNotification(
    userId,
    'login',
    'লগইন সফল',
    'আপনি সফলভাবে লগইন করেছেন',
    {}
  );
}

/**
 * Create a notification for deposit submission
 */
async function createDepositSubmissionNotification(userId, amount) {
  logDeprecationWarning('createDepositSubmissionNotification');
  
  return createAndSendNotification(
    userId,
    'deposit_submitted',
    'ডিপোজিট রিকোয়েস্ট গৃহীত হয়েছে',
    `আপনার ৳${amount} ডিপোজিট রিকোয়েস্ট গৃহীত হয়েছে। অনুমোদনের জন্য অপেক্ষা করুন।`,
    { amount }
  );
}

/**
 * Create a notification for deposit approval
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {number} amount - The deposit amount
 * @param {string} transactionId - The transaction ID
 * @returns {Promise<Object>} The created notification
 */
async function createDepositNotification(userId, amount, transactionId) {
  logDeprecationWarning('createDepositNotification');
  
  return createAndSendNotification(
    userId,
    'deposit_approved',
    'ডিপোজিট অনুমোদিত',
    `আপনার ৳${amount} ডিপোজিট অনুমোদিত হয়েছে`,
    { amount, transactionId }
  );
}

/**
 * Create a notification for deposit rejection
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {number} amount - The deposit amount
 * @param {string} reason - The rejection reason
 * @returns {Promise<Object>} The created notification
 */
async function createDepositRejectionNotification(userId, amount, reason) {
  logDeprecationWarning('createDepositRejectionNotification');
  
  return createAndSendNotification(
    userId,
    'deposit_rejected',
    'ডিপোজিট প্রত্যাখ্যাত',
    `আপনার ৳${amount} ডিপোজিট প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'তথ্য সঠিক নয়'}`,
    { amount, reason }
  );
}

/**
 * Create a notification for withdrawal submission
 */
async function createWithdrawalSubmissionNotification(userId, amount) {
  logDeprecationWarning('createWithdrawalSubmissionNotification');
  
  return createAndSendNotification(
    userId,
    'withdrawal_submitted',
    'উইথড্রয়াল রিকোয়েস্ট গৃহীত হয়েছে',
    `আপনার ৳${amount} উইথড্রয়াল রিকোয়েস্ট গৃহীত হয়েছে। প্রক্রিয়াকরণের জন্য অপেক্ষা করুন।`,
    { amount }
  );
}

/**
 * Create a notification for withdrawal processing
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {number} amount - The withdrawal amount
 * @param {string} transactionId - The transaction ID
 * @returns {Promise<Object>} The created notification
 */
async function createWithdrawalNotification(userId, amount, transactionId) {
  logDeprecationWarning('createWithdrawalNotification');
  
  return createAndSendNotification(
    userId,
    'withdrawal_processed',
    'উইথড্র সম্পন্ন',
    `আপনার ৳${amount} উইথড্র প্রক্রিয়া সম্পন্ন হয়েছে`,
    { amount, transactionId }
  );
}

/**
 * Create a notification for withdrawal rejection
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {number} amount - The withdrawal amount
 * @param {string} reason - The rejection reason
 * @returns {Promise<Object>} The created notification
 */
async function createWithdrawalRejectionNotification(userId, amount, reason) {
  logDeprecationWarning('createWithdrawalRejectionNotification');
  
  return createAndSendNotification(
    userId,
    'withdrawal_rejected',
    'উইথড্র প্রত্যাখ্যাত',
    `আপনার ৳${amount} উইথড্র প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'তথ্য সঠিক নয়'}। টাকা আপনার ব্যালেন্সে ফেরত দেওয়া হয়েছে।`,
    { amount, reason }
  );
}

/**
 * Create a notification for KYC submission
 */
async function createKYCSubmissionNotification(userId) {
  logDeprecationWarning('createKYCSubmissionNotification');
  
  return createAndSendNotification(
    userId,
    'kyc_submitted',
    'KYC রিকোয়েস্ট গৃহীত হয়েছে',
    'আপনার KYC ভেরিফিকেশন রিকোয়েস্ট গৃহীত হয়েছে। অনুমোদনের জন্য অপেক্ষা করুন।',
    {}
  );
}

/**
 * Create a notification for KYC/verification approval
 * @param {string} userId - The user's MongoDB ObjectId
 * @returns {Promise<Object>} The created notification
 */
async function createKYCApprovalNotification(userId) {
  logDeprecationWarning('createKYCApprovalNotification');
  
  return createAndSendNotification(
    userId,
    'kyc_approved',
    'KYC অনুমোদিত 🎉',
    'আপনার KYC অনুমোদিত হয়েছে! ৳১৮০ বোনাস আপনার প্রফিট ব্যালেন্সে যোগ হয়েছে। এখন Withdraw করতে পারবেন।',
    {}
  );
}

/**
 * Create a notification for KYC/verification rejection
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {string} reason - The rejection reason
 * @returns {Promise<Object>} The created notification
 */
async function createKYCRejectionNotification(userId, reason) {
  logDeprecationWarning('createKYCRejectionNotification');
  
  return createAndSendNotification(
    userId,
    'kyc_rejected',
    'KYC প্রত্যাখ্যাত',
    `আপনার KYC ভেরিফিকেশন প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'তথ্য সঠিক নয়'}। অনুগ্রহ করে সঠিক তথ্য দিয়ে পুনরায় জমা দিন।`,
    { reason }
  );
}

/**
 * Create a notification for successful referral
 */
async function createReferralSuccessNotification(userId, referredUserName) {
  logDeprecationWarning('createReferralSuccessNotification');
  
  return createAndSendNotification(
    userId,
    'referral_success',
    'রেফারেল সফল',
    `${referredUserName} আপনার রেফারেল কোড ব্যবহার করে যোগ দিয়েছেন!`,
    { referredUserName }
  );
}

/**
 * Create a notification for referral bonus
 * @param {string} userId - The user's MongoDB ObjectId
 * @param {string} referralName - The name of the referred user
 * @param {number} amount - The referral bonus amount
 * @returns {Promise<Object>} The created notification
 */
async function createReferralNotification(userId, referralName, amount) {
  logDeprecationWarning('createReferralNotification');
  
  return createAndSendNotification(
    userId,
    'referral_bonus',
    'রেফারেল বোনাস',
    `${referralName} এর রেফারেল থেকে ৳${amount} বোনাস পেয়েছেন`,
    { referralName, amount }
  );
}

/**
 * Create a system announcement notification for all users
 * @param {string} title - The announcement title
 * @param {string} message - The announcement message
 * @returns {Promise<Object>} Result with count of notifications created
 */
async function createSystemAnnouncement(title, message) {
  logDeprecationWarning('createSystemAnnouncement');
  
  try {
    // Get all users
    const users = await User.find({});
    
    if (users.length === 0) {
      return { success: true, count: 0, message: 'No users found' };
    }

    // Create notification objects for all users
    const notifications = users.map(user => ({
      userId: user._id,
      type: 'system_announcement',
      title,
      message
    }));

    // Bulk insert all notifications
    const result = await Notification.insertMany(notifications);
    
    // Send push notifications using pushNotificationService
    const pushPromises = users
      .filter(user => user.pushToken)
      .map(user => pushNotificationService.sendToUser(user._id, {
        title,
        body: message,
        data: { type: 'system_announcement' }
      }));
    
    await Promise.allSettled(pushPromises);
    
    return {
      success: true,
      count: result.length,
      message: `System announcement sent to ${result.length} users`
    };
  } catch (error) {
    console.error('Error creating system announcement:', error);
    throw error;
  }
}

/**
 * Send push notification to admin
 * Admin push tokens should be stored in environment variable or database
 */
async function sendAdminNotification(title, message, data = {}) {
  logDeprecationWarning('sendAdminNotification');
  
  try {
    // Get admin push token from environment variable
    const adminPushToken = process.env.ADMIN_PUSH_TOKEN;
    
    if (!adminPushToken) {
      console.log('Admin push token not configured');
      return;
    }

    // Legacy behavior: just log
    console.log('Admin notification (legacy):', title);
  } catch (error) {
    console.error('Error sending admin notification:', error);
  }
}

/**
 * Notify admin about new deposit request
 */
async function notifyAdminNewDeposit(userName, amount, method) {
  logDeprecationWarning('notifyAdminNewDeposit');
  
  return sendAdminNotification(
    'নতুন ডিপোজিট রিকোয়েস্ট',
    `${userName} ৳${amount} ডিপোজিট জমা দিয়েছেন (${method})`,
    { type: 'new_deposit', userName, amount, method }
  );
}

/**
 * Notify admin about new withdrawal request
 */
async function notifyAdminNewWithdrawal(userName, amount, method) {
  logDeprecationWarning('notifyAdminNewWithdrawal');
  
  return sendAdminNotification(
    'নতুন উইথড্র রিকোয়েস্ট',
    `${userName} ৳${amount} উইথড্র রিকোয়েস্ট করেছেন (${method})`,
    { type: 'new_withdrawal', userName, amount, method }
  );
}

/**
 * Notify admin about new KYC verification
 */
async function notifyAdminNewKYC(userName, nidNumber) {
  logDeprecationWarning('notifyAdminNewKYC');
  
  return sendAdminNotification(
    'নতুন KYC ভেরিফিকেশন',
    `${userName} KYC ভেরিফিকেশন জমা দিয়েছেন (NID: ${nidNumber})`,
    { type: 'new_kyc', userName, nidNumber }
  );
}

/**
 * Notify admin about new agent registration
 */
async function notifyAdminNewAgent(agentName, email, phone) {
  logDeprecationWarning('notifyAdminNewAgent');
  
  return sendAdminNotification(
    'নতুন এজেন্ট রেজিস্ট্রেশন',
    `${agentName} এজেন্ট হিসেবে রেজিস্টার করেছেন (${email})`,
    { type: 'new_agent', agentName, email, phone }
  );
}

/**
 * Notify admin about new support ticket
 */
async function notifyAdminNewSupportTicket(userName, message) {
  logDeprecationWarning('notifyAdminNewSupportTicket');
  
  return sendAdminNotification(
    'নতুন সাপোর্ট টিকেট',
    `${userName} একটি সাপোর্ট টিকেট তৈরি করেছেন`,
    { type: 'new_support', userName, message }
  );
}

export {
  sendPushNotification,
  createRegistrationNotification,
  createLoginNotification,
  createDepositSubmissionNotification,
  createDepositNotification,
  createDepositRejectionNotification,
  createWithdrawalSubmissionNotification,
  createWithdrawalNotification,
  createWithdrawalRejectionNotification,
  createKYCSubmissionNotification,
  createKYCApprovalNotification,
  createKYCRejectionNotification,
  createReferralSuccessNotification,
  createReferralNotification,
  createSystemAnnouncement,
  sendAdminNotification,
  notifyAdminNewDeposit,
  notifyAdminNewWithdrawal,
  notifyAdminNewKYC,
  notifyAdminNewAgent,
  notifyAdminNewSupportTicket
};
