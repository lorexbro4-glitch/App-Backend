﻿import nodemailer from 'nodemailer';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// ==================== DEPOSIT EMAILS ====================

// Send deposit submission confirmation email
const sendDepositSubmissionEmail = async (email, name, amount, method) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'ডিপোজিট রিকোয়েস্ট গৃহীত হয়েছে - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">✅ ডিপোজিট রিকোয়েস্ট গৃহীত</h2>
          <p style="color: #d1fae5; margin: 0; font-size: 16px;">আপনার ডিপোজিট রিকোয়েস্ট জমা হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">আপনার ডিপোজিট রিকোয়েস্ট আমরা পেয়েছি এবং এটি বর্তমানে পর্যালোচনা করা হচ্ছে।</p>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 25px 0;">
          <h3 style="color: #1e293b; margin: 0 0 15px 0;">📋 রিকোয়েস্ট বিবরণ:</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; color: #64748b;">পরিমাণ:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">৳${amount}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">পেমেন্ট মেথড:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">${method}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">স্ট্যাটাস:</td>
              <td style="padding: 8px 0; color: #f59e0b; font-weight: bold; text-align: right;">পেন্ডিং</td>
            </tr>
          </table>
        </div>
        
        <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0; line-height: 1.6;">⏳ আপনার ডিপোজিট রিকোয়েস্ট শীঘ্রই অনুমোদিত হবে। অনুমোদনের পর আপনি ইমেইল এবং নোটিফিকেশন পাবেন।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">ধন্যবাদ,<br>YFBD টিম</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send deposit approval email
const sendDepositApprovalEmail = async (email, name, amount) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: '🎉 ডিপোজিট অনুমোদিত হয়েছে - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">🎉 ডিপোজিট সফল!</h2>
          <p style="color: #d1fae5; margin: 0; font-size: 16px;">আপনার ডিপোজিট অনুমোদিত হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">সুসংবাদ! আপনার ডিপোজিট রিকোয়েস্ট অনুমোদিত হয়েছে এবং টাকা আপনার অ্যাকাউন্টে যোগ করা হয়েছে।</p>
        
        <div style="background: #f0fdf4; padding: 25px; border-radius: 12px; margin: 25px 0; text-align: center; border: 2px solid #10b981;">
          <p style="color: #065f46; margin: 0 0 10px 0; font-size: 14px;">অনুমোদিত পরিমাণ</p>
          <h1 style="color: #059669; margin: 0; font-size: 42px;">৳${amount}</h1>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💰 এখন কি করবেন?</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>আপনার ব্যালেন্স চেক করুন</li>
            <li>মাসিক সর্বোচ্চ ১৬% লাভ অর্জন শুরু করুন</li>
            <li>রেফারেল করে অতিরিক্ত আয় করুন</li>
          </ul>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার বিশ্বাসের জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send deposit rejection email
const sendDepositRejectionEmail = async (email, name, amount, reason) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'ডিপোজিট রিকোয়েস্ট প্রত্যাখ্যাত - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">❌ ডিপোজিট প্রত্যাখ্যাত</h2>
          <p style="color: #fecaca; margin: 0; font-size: 16px;">আপনার ডিপোজিট রিকোয়েস্ট প্রত্যাখ্যাত হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">দুঃখিত, আপনার ডিপোজিট রিকোয়েস্ট (৳${amount}) প্রত্যাখ্যাত হয়েছে।</p>
        
        <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #ef4444;">
          <h3 style="color: #991b1b; margin: 0 0 10px 0;">📝 প্রত্যাখ্যানের কারণ:</h3>
          <p style="color: #991b1b; margin: 0; line-height: 1.6;">${reason || 'কারণ উল্লেখ করা হয়নি'}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💡 পরবর্তী পদক্ষেপ:</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>সঠিক তথ্য দিয়ে আবার চেষ্টা করুন</li>
            <li>ট্রানজেকশন আইডি এবং স্ক্রিনশট যাচাই করুন</li>
            <li>সমস্যা থাকলে সাপোর্টে যোগাযোগ করুন</li>
          </ul>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার সহযোগিতার জন্য ধন্যবাদ।</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// ==================== WITHDRAWAL EMAILS ====================

// Send withdrawal submission confirmation email
const sendWithdrawalSubmissionEmail = async (email, name, amount, type, method) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'উইথড্র রিকোয়েস্ট গৃহীত হয়েছে - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">✅ উইথড্র রিকোয়েস্ট গৃহীত</h2>
          <p style="color: #ede9fe; margin: 0; font-size: 16px;">আপনার উইথড্র রিকোয়েস্ট জমা হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">আপনার উইথড্র রিকোয়েস্ট আমরা পেয়েছি এবং এটি বর্তমানে প্রসেস করা হচ্ছে।</p>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 25px 0;">
          <h3 style="color: #1e293b; margin: 0 0 15px 0;">📋 রিকোয়েস্ট বিবরণ:</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; color: #64748b;">পরিমাণ:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">৳${amount}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">টাইপ:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">${type === 'profit' ? 'লাভ' : 'মূলধন'}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">পেমেন্ট মেথড:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">${method}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">স্ট্যাটাস:</td>
              <td style="padding: 8px 0; color: #f59e0b; font-weight: bold; text-align: right;">পেন্ডিং</td>
            </tr>
          </table>
        </div>
        
        <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0; line-height: 1.6;">⏳ আপনার উইথড্র রিকোয়েস্ট শীঘ্রই প্রসেস হবে। অনুমোদনের পর টাকা আপনার অ্যাকাউন্টে পাঠানো হবে।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">ধন্যবাদ,<br>YFBD টিম</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send withdrawal approval email
const sendWithdrawalApprovalEmail = async (email, name, amount, method) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: '🎉 উইথড্র সফল হয়েছে - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">🎉 উইথড্র সফল!</h2>
          <p style="color: #d1fae5; margin: 0; font-size: 16px;">আপনার উইথড্র রিকোয়েস্ট অনুমোদিত হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">সুসংবাদ! আপনার উইথড্র রিকোয়েস্ট অনুমোদিত হয়েছে এবং টাকা আপনার ${method} অ্যাকাউন্টে পাঠানো হয়েছে।</p>
        
        <div style="background: #f0fdf4; padding: 25px; border-radius: 12px; margin: 25px 0; text-align: center; border: 2px solid #10b981;">
          <p style="color: #065f46; margin: 0 0 10px 0; font-size: 14px;">উইথড্র পরিমাণ</p>
          <h1 style="color: #059669; margin: 0; font-size: 42px;">৳${amount}</h1>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <p style="color: #1e40af; margin: 0; line-height: 1.6;">💳 টাকা আপনার ${method} অ্যাকাউন্টে পাঠানো হয়েছে। কয়েক মিনিটের মধ্যে আপনি টাকা পাবেন।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার বিশ্বাসের জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send withdrawal rejection email
const sendWithdrawalRejectionEmail = async (email, name, amount, reason) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'উইথড্র রিকোয়েস্ট প্রত্যাখ্যাত - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">❌ উইথড্র প্রত্যাখ্যাত</h2>
          <p style="color: #fecaca; margin: 0; font-size: 16px;">আপনার উইথড্র রিকোয়েস্ট প্রত্যাখ্যাত হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">দুঃখিত, আপনার উইথড্র রিকোয়েস্ট (৳${amount}) প্রত্যাখ্যাত হয়েছে এবং টাকা আপনার অ্যাকাউন্টে ফেরত দেওয়া হয়েছে।</p>
        
        <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #ef4444;">
          <h3 style="color: #991b1b; margin: 0 0 10px 0;">📝 প্রত্যাখ্যানের কারণ:</h3>
          <p style="color: #991b1b; margin: 0; line-height: 1.6;">${reason || 'কারণ উল্লেখ করা হয়নি'}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💡 পরবর্তী পদক্ষেপ:</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>সঠিক তথ্য দিয়ে আবার চেষ্টা করুন</li>
            <li>অ্যাকাউন্ট নম্বর যাচাই করুন</li>
            <li>সমস্যা থাকলে সাপোর্টে যোগাযোগ করুন</li>
          </ul>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার সহযোগিতার জন্য ধন্যবাদ।</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// ==================== VERIFICATION (KYC) EMAILS ====================

// Send verification submission confirmation email
const sendVerificationSubmissionEmail = async (email, name, nidNumber) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'KYC ভেরিফিকেশন রিকোয়েস্ট গৃহীত হয়েছে - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">✅ KYC রিকোয়েস্ট গৃহীত</h2>
          <p style="color: #dbeafe; margin: 0; font-size: 16px;">আপনার KYC ভেরিফিকেশন রিকোয়েস্ট জমা হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">আপনার KYC ভেরিফিকেশন রিকোয়েস্ট আমরা পেয়েছি এবং এটি বর্তমানে পর্যালোচনা করা হচ্ছে।</p>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 25px 0;">
          <h3 style="color: #1e293b; margin: 0 0 15px 0;">📋 রিকোয়েস্ট বিবরণ:</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px 0; color: #64748b;">নাম:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">${name}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">NID নম্বর:</td>
              <td style="padding: 8px 0; color: #1e293b; font-weight: bold; text-align: right;">${nidNumber}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #64748b;">স্ট্যাটাস:</td>
              <td style="padding: 8px 0; color: #f59e0b; font-weight: bold; text-align: right;">পেন্ডিং</td>
            </tr>
          </table>
        </div>
        
        <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0; line-height: 1.6;">⏳ আপনার KYC ভেরিফিকেশন শীঘ্রই পর্যালোচনা করা হবে। অনুমোদনের পর আপনি উইথড্র করতে পারবেন।</p>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">📝 গুরুত্বপূর্ণ তথ্য:</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>KYC অনুমোদিত না হলে উইথড্র করতে পারবেন না</li>
            <li>সঠিক এবং স্পষ্ট ছবি আপলোড করুন</li>
            <li>NID এবং সেলফি ছবি মিলতে হবে</li>
          </ul>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">ধন্যবাদ,<br>YFBD টিম</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send verification approval email
const sendVerificationApprovalEmail = async (email, name) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: '🎉 KYC অনুমোদিত + ৳১৮০ বোনাস পেয়েছেন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 8px 0;">🎉 KYC অনুমোদিত!</h2>
          <p style="color: #d1fae5; margin: 0; font-size: 16px;">আপনার KYC ভেরিফিকেশন সফল হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">অভিনন্দন! আপনার KYC ভেরিফিকেশন অনুমোদিত হয়েছে। পুরস্কার হিসেবে আপনার অ্যাকাউন্টে <strong>৳১৮০ বোনাস</strong> যোগ করা হয়েছে!</p>
        
        <div style="background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%); padding: 28px; border-radius: 16px; margin: 25px 0; text-align: center; border: 2px solid #f59e0b;">
          <p style="color: #92400e; margin: 0 0 6px 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">🎁 KYC সম্পন্ন বোনাস</p>
          <h1 style="color: #d97706; margin: 0; font-size: 52px; font-weight: 900;">৳১৮০</h1>
          <p style="color: #92400e; margin: 8px 0 0 0; font-size: 14px;">আপনার প্রফিট ব্যালেন্সে যোগ হয়েছে</p>
        </div>

        <div style="background: #f0fdf4; padding: 25px; border-radius: 12px; margin: 25px 0; text-align: center; border: 2px solid #10b981;">
          <h3 style="color: #059669; margin: 0; font-size: 20px;">✅ ভেরিফাইড অ্যাকাউন্ট</h3>
          <p style="color: #065f46; margin: 10px 0 0 0;">আপনার অ্যাকাউন্ট সম্পূর্ণভাবে ভেরিফাইড</p>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💰 এখন আপনি পারবেন:</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>লাভ এবং মূলধন উইথড্র করতে</li>
            <li>সীমাহীন ডিপোজিট করতে</li>
            <li>সব ফিচার ব্যবহার করতে</li>
            <li>রেফারেল বোনাস পেতে</li>
          </ul>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার বিশ্বাসের জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send verification rejection email
const sendVerificationRejectionEmail = async (email, name, reason) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'KYC ভেরিফিকেশন প্রত্যাখ্যাত - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">❌ KYC প্রত্যাখ্যাত</h2>
          <p style="color: #fecaca; margin: 0; font-size: 16px;">আপনার KYC ভেরিফিকেশন প্রত্যাখ্যাত হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">দুঃখিত, আপনার KYC ভেরিফিকেশন রিকোয়েস্ট প্রত্যাখ্যাত হয়েছে।</p>
        
        <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #ef4444;">
          <h3 style="color: #991b1b; margin: 0 0 10px 0;">📝 প্রত্যাখ্যানের কারণ:</h3>
          <p style="color: #991b1b; margin: 0; line-height: 1.6;">${reason || 'কারণ উল্লেখ করা হয়নি'}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💡 পরবর্তী পদক্ষেপ:</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>সঠিক এবং স্পষ্ট ছবি আপলোড করুন</li>
            <li>NID এবং সেলফি ছবি মিলিয়ে দেখুন</li>
            <li>সব তথ্য সঠিকভাবে পূরণ করুন</li>
            <li>আবার KYC সাবমিট করুন</li>
          </ul>
        </div>
        
        <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0; line-height: 1.6;">⚠️ KYC অনুমোদিত না হলে আপনি উইথড্র করতে পারবেন না। দয়া করে সঠিক তথ্য দিয়ে আবার চেষ্টা করুন।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার সহযোগিতার জন্য ধন্যবাদ।</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// ==================== REFERRAL BONUS EMAIL ====================

// Send referral bonus notification email
const sendReferralBonusEmail = async (email, name, bonusAmount, referralName) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: '🎁 রেফারেল বোনাস পেয়েছেন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">🎁 রেফারেল বোনাস!</h2>
          <p style="color: #fef3c7; margin: 0; font-size: 16px;">আপনি রেফারেল বোনাস পেয়েছেন</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">অভিনন্দন! আপনার রেফার করা ব্যক্তির ডিপোজিট অনুমোদিত হয়েছে এবং আপনি রেফারেল বোনাস পেয়েছেন।</p>
        
        <div style="background: #fffbeb; padding: 25px; border-radius: 12px; margin: 25px 0; text-align: center; border: 2px solid #f59e0b;">
          <p style="color: #92400e; margin: 0 0 10px 0; font-size: 14px;">রেফারেল বোনাস</p>
          <h1 style="color: #d97706; margin: 0; font-size: 42px;">৳${bonusAmount}</h1>
          <p style="color: #92400e; margin: 10px 0 0 0; font-size: 14px;">রেফারেল: ${referralName}</p>
        </div>
        
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #10b981;">
          <h3 style="color: #065f46; margin: 0 0 10px 0;">💰 বোনাস বিবরণ:</h3>
          <ul style="color: #065f46; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>বোনাস আপনার ব্যালেন্সে যোগ হয়েছে</li>
            <li>বোনাস রেফারেল ইনকামে যোগ হয়েছে</li>
            <li>এই বোনাস ৫% রেফারেল কমিশন</li>
            <li>আরও রেফার করে আরও আয় করুন</li>
          </ul>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">🚀 আরও আয় করুন:</h3>
          <p style="color: #1e40af; margin: 0; line-height: 1.6;">আপনার রেফারেল লিংক শেয়ার করুন এবং প্রতিটি ডিপোজিটে ৫% বোনাস পান। যত বেশি রেফার করবেন, তত বেশি আয় করবেন!</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার সাথে থাকার জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// ==================== KYC BONUS EMAIL ====================

// Send KYC bonus notification email (standalone, also called from approval)
const sendKYCBonusEmail = async (email, name) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: '🎁 ৳১৮০ KYC বোনাস পেয়েছেন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>

        <div style="background: linear-gradient(135deg, #d97706 0%, #f59e0b 50%, #fbbf24 100%); padding: 36px 30px; text-align: center; border-radius: 16px; margin-bottom: 30px;">
          <p style="color: rgba(255,255,255,0.9); margin: 0 0 8px 0; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">🎁 KYC সম্পন্ন বোনাস</p>
          <h1 style="color: #ffffff; margin: 0; font-size: 64px; font-weight: 900; line-height: 1;">৳১৮০</h1>
          <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px;">আপনার প্রফিট ব্যালেন্সে যোগ হয়েছে!</p>
        </div>

        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name},</p>
        <p style="color: #475569; line-height: 1.6;">অভিনন্দন! আপনার KYC ভেরিফিকেশন অনুমোদিত হয়েছে এবং পুরস্কার হিসেবে আপনার অ্যাকাউন্টে <strong style="color:#d97706;">৳১৮০ বোনাস</strong> যোগ করা হয়েছে।</p>

        <div style="background: #fffbeb; border: 2px solid #f59e0b; border-radius: 12px; padding: 20px; margin: 24px 0;">
          <table style="width:100%; border-collapse:collapse;">
            <tr>
              <td style="padding: 10px 0; color: #92400e; font-size: 14px;">বোনাসের ধরন</td>
              <td style="padding: 10px 0; text-align: right; color: #1e293b; font-weight: 700;">KYC সম্পন্ন বোনাস</td>
            </tr>
            <tr style="border-top:1px solid #fde68a;">
              <td style="padding: 10px 0; color: #92400e; font-size: 14px;">পরিমাণ</td>
              <td style="padding: 10px 0; text-align: right; color: #d97706; font-weight: 900; font-size: 20px;">৳১৮০</td>
            </tr>
            <tr style="border-top:1px solid #fde68a;">
              <td style="padding: 10px 0; color: #92400e; font-size: 14px;">যোগ হয়েছে</td>
              <td style="padding: 10px 0; text-align: right; color: #059669; font-weight: 700;">প্রফিট ব্যালেন্সে</td>
            </tr>
            <tr style="border-top:1px solid #fde68a;">
              <td style="padding: 10px 0; color: #92400e; font-size: 14px;">স্ট্যাটাস</td>
              <td style="padding: 10px 0; text-align: right;"><span style="background:#d1fae5; color:#065f46; padding:4px 12px; border-radius:20px; font-size:13px; font-weight:700;">✅ সম্পন্ন</span></td>
            </tr>
          </table>
        </div>

        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 24px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💰 এখন কী করবেন?</h3>
          <ul style="color: #1e40af; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>অ্যাপ খুলুন এবং আপনার ব্যালেন্স দেখুন</li>
            <li>বিনিয়োগ শুরু করুন এবং মাসে সর্বোচ্চ ১৬% লাভ পান</li>
            <li>বন্ধুদের রেফার করুন এবং আরও বোনাস পান</li>
            <li>লাভ বা মূলধন উইথড্র করুন যেকোনো সময়</li>
          </ul>
        </div>

        <p style="color: #475569; line-height: 1.6; text-align: center;">আপনার সাথে থাকার জন্য ধন্যবাদ! 🙏</p>

        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('KYC bonus email send error:', error);
    return { success: false, error: error.message };
  }
};

export {
  sendDepositSubmissionEmail,
  sendDepositApprovalEmail,
  sendDepositRejectionEmail,
  sendWithdrawalSubmissionEmail,
  sendWithdrawalApprovalEmail,
  sendWithdrawalRejectionEmail,
  sendVerificationSubmissionEmail,
  sendVerificationApprovalEmail,
  sendVerificationRejectionEmail,
  sendReferralBonusEmail,
  sendKYCBonusEmail,
};
