/**
 * Pagination Service
 * Provides page-based pagination with metadata
 */

class PaginationService {
  /**
   * Paginate query results
   * @param {Model} model - Mongoose model
   * @param {Object} query - Query filter
   * @param {Object} options - Pagination options
   * @returns {Promise<Object>} Paginated results with metadata
   */
  async paginate(model, query = {}, options = {}) {
    const {
      page = 1,
      pageSize = 20,
      select = null,
      populate = null,
      sort = { createdAt: -1 },
      lean = true
    } = options;

    // Validate pagination parameters
    const validatedParams = this.validateParams(page, pageSize);
    const validatedPage = validatedParams.page;
    const validatedPageSize = validatedParams.pageSize;

    // Calculate skip
    const skip = (validatedPage - 1) * validatedPageSize;

    // Build query
    let queryBuilder = model.find(query);

    if (select) {
      queryBuilder = queryBuilder.select(select);
    }

    if (populate) {
      if (Array.isArray(populate)) {
        populate.forEach(pop => {
          queryBuilder = queryBuilder.populate(pop);
        });
      } else {
        queryBuilder = queryBuilder.populate(populate);
      }
    }

    if (sort) {
      queryBuilder = queryBuilder.sort(sort);
    }

    queryBuilder = queryBuilder.skip(skip).limit(validatedPageSize);

    if (lean) {
      queryBuilder = queryBuilder.lean();
    }

    // Execute query and count in parallel
    const [data, totalCount] = await Promise.all([
      queryBuilder.exec(),
      model.countDocuments(query)
    ]);

    // Build pagination metadata
    const pagination = this.buildPaginationMetadata(
      totalCount,
      validatedPage,
      validatedPageSize
    );

    return {
      success: true,
      data,
      pagination
    };
  }

  /**
   * Validate pagination parameters
   * @param {number} page - Page number
   * @param {number} pageSize - Items per page
   * @returns {Object} Validated parameters
   */
  validateParams(page, pageSize) {
    let validatedPage = parseInt(page);
    let validatedPageSize = parseInt(pageSize);

    // Validate page number
    if (isNaN(validatedPage) || validatedPage < 1) {
      validatedPage = 1;
    }

    // Validate page size
    if (isNaN(validatedPageSize) || validatedPageSize < 1) {
      validatedPageSize = 20;
    }

    // Enforce maximum page size
    if (validatedPageSize > 100) {
      validatedPageSize = 100;
    }

    return {
      page: validatedPage,
      pageSize: validatedPageSize
    };
  }

  /**
   * Build pagination metadata
   * @param {number} totalCount - Total number of documents
   * @param {number} page - Current page number
   * @param {number} pageSize - Items per page
   * @returns {Object} Pagination metadata
   */
  buildPaginationMetadata(totalCount, page, pageSize) {
    const totalPages = Math.ceil(totalCount / pageSize);
    const hasNext = page < totalPages;
    const hasPrevious = page > 1;

    return {
      page,
      pageSize,
      totalCount,
      totalPages,
      hasNext,
      hasPrevious
    };
  }

  /**
   * Paginate with search
   * @param {Model} model - Mongoose model
   * @param {Object} searchQuery - Search query filter
   * @param {Object} options - Pagination options
   * @returns {Promise<Object>} Paginated results with metadata
   */
  async paginateWithSearch(model, searchQuery = {}, options = {}) {
    return this.paginate(model, searchQuery, options);
  }

  /**
   * Paginate with date range filter
   * @param {Model} model - Mongoose model
   * @param {Object} query - Base query filter
   * @param {Date} startDate - Start date
   * @param {Date} endDate - End date
   * @param {string} dateField - Date field name (default: 'createdAt')
   * @param {Object} options - Pagination options
   * @returns {Promise<Object>} Paginated results with metadata
   */
  async paginateWithDateRange(model, query = {}, startDate, endDate, dateField = 'createdAt', options = {}) {
    const dateQuery = { ...query };

    if (startDate || endDate) {
      dateQuery[dateField] = {};
      if (startDate) {
        dateQuery[dateField].$gte = new Date(startDate);
      }
      if (endDate) {
        dateQuery[dateField].$lte = new Date(endDate);
      }
    }

    return this.paginate(model, dateQuery, options);
  }
}

export default new PaginationService();
