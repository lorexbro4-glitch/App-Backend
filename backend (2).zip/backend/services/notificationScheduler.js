import cron from 'node-cron';
import NotificationQueue from '../models/NotificationQueue.js';
import User from '../models/User.js';
import pushNotificationService from './pushNotificationService.js';

class NotificationScheduler {
  constructor() {
    this.isRunning = false;
    this.cronJob = null;
  }

  /**
   * Start the notification scheduler
   */
  start() {
    if (this.isRunning) {
      console.log('Notification scheduler is already running');
      return;
    }

    // Schedule daily profit notifications at midnight Bangladesh time (18:00 UTC)
    this.cronJob = cron.schedule('0 18 * * *', async () => {
      console.log('Running daily profit notification scheduler...');
      await this.scheduleDailyProfitNotifications();
    });

    // Process pending notifications every 5 minutes
    this.processingJob = cron.schedule('*/5 * * * *', async () => {
      await this.processPendingNotifications();
    });

    // Retry failed notifications every 30 minutes
    this.retryJob = cron.schedule('*/30 * * * *', async () => {
      await this.retryFailedNotifications();
    });

    this.isRunning = true;
    console.log('Notification scheduler started');
    console.log('- Daily profit notifications: 12:00 AM Bangladesh time (18:00 UTC)');
    console.log('- Process pending: Every 5 minutes');
    console.log('- Retry failed: Every 30 minutes');
  }

  /**
   * Stop the notification scheduler
   */
  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
    }
    if (this.processingJob) {
      this.processingJob.stop();
    }
    if (this.retryJob) {
      this.retryJob.stop();
    }
    this.isRunning = false;
    console.log('Notification scheduler stopped');
  }

  /**
   * Schedule daily profit notifications for all users
   */
  async scheduleDailyProfitNotifications() {
    try {
      // Get all active users with valid push tokens
      const users = await User.find({
        isActive: true,
        pushToken: { $exists: true, $ne: null },
        pushTokenValid: true,
        'notificationPreferences.dailyProfit': { $ne: false } // Default to true if not set
      }).select('_id name balance dailyProfit notificationPreferences');

      console.log(`Found ${users.length} users for daily profit notifications`);

      let queued = 0;
      let skipped = 0;

      for (const user of users) {
        // Skip if user has no profit or negative profit
        const dailyProfit = user.dailyProfit || 0;
        if (dailyProfit <= 0) {
          skipped++;
          continue;
        }

        // Check if notification already queued for today
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        const existing = await NotificationQueue.findOne({
          userId: user._id,
          type: 'daily_profit',
          createdAt: { $gte: today, $lt: tomorrow }
        });

        if (existing) {
          skipped++;
          continue;
        }

        // Queue notification
        await this.queueNotification(user._id, {
          type: 'daily_profit',
          title: 'Daily Profit Added! 💰',
          body: `You earned ৳${dailyProfit.toFixed(2)} today. Current balance: ৳${user.balance.toFixed(2)}`,
          data: {
            type: 'daily_profit',
            amount: dailyProfit,
            balance: user.balance,
            timestamp: new Date().toISOString()
          },
          scheduledFor: new Date() // Send immediately
        });

        queued++;
      }

      console.log(`Daily profit notifications: ${queued} queued, ${skipped} skipped`);
      return { queued, skipped };
    } catch (error) {
      console.error('Error scheduling daily profit notifications:', error);
      throw error;
    }
  }

  /**
   * Queue a notification for later sending
   */
  async queueNotification(userId, notification) {
    try {
      const queuedNotification = await NotificationQueue.create({
        userId,
        type: notification.type,
        title: notification.title,
        body: notification.body,
        data: notification.data || {},
        scheduledFor: notification.scheduledFor || new Date(),
        maxRetries: notification.maxRetries || 3
      });

      return queuedNotification;
    } catch (error) {
      console.error('Error queuing notification:', error);
      throw error;
    }
  }

  /**
   * Process pending notifications that are due
   */
  async processPendingNotifications() {
    try {
      const now = new Date();
      
      // Find pending notifications that are due
      const notifications = await NotificationQueue.find({
        status: 'pending',
        scheduledFor: { $lte: now }
      }).limit(100); // Process in batches

      if (notifications.length === 0) {
        return { processed: 0, sent: 0, failed: 0 };
      }

      console.log(`Processing ${notifications.length} pending notifications...`);

      let sent = 0;
      let failed = 0;

      for (const notification of notifications) {
        const result = await this.sendNotification(notification);
        if (result.success) {
          sent++;
        } else {
          failed++;
        }
      }

      console.log(`Processed notifications: ${sent} sent, ${failed} failed`);
      return { processed: notifications.length, sent, failed };
    } catch (error) {
      console.error('Error processing pending notifications:', error);
      throw error;
    }
  }

  /**
   * Send a single notification
   */
  async sendNotification(notification) {
    try {
      // Check user notification preferences
      const user = await User.findById(notification.userId).select('notificationPreferences pushToken pushTokenValid');
      
      if (!user) {
        notification.status = 'failed';
        notification.lastError = 'User not found';
        await notification.save();
        return { success: false, error: 'User not found' };
      }

      // Check if user has disabled this notification type
      const prefKey = this.getPreferenceKey(notification.type);
      if (prefKey && user.notificationPreferences && user.notificationPreferences[prefKey] === false) {
        notification.status = 'failed';
        notification.lastError = 'User opted out';
        await notification.save();
        return { success: false, error: 'User opted out' };
      }

      // Check if user has valid push token
      if (!user.pushToken || !user.pushTokenValid) {
        notification.status = 'failed';
        notification.lastError = 'No valid push token';
        await notification.save();
        return { success: false, error: 'No valid push token' };
      }

      // Send push notification
      const result = await pushNotificationService.sendToUser(notification.userId, {
        title: notification.title,
        body: notification.body,
        data: notification.data
      });

      if (result.success) {
        notification.status = 'sent';
        notification.sentAt = new Date();
        notification.pushReceipt = result.receipt;
        await notification.save();
        return { success: true };
      } else {
        // Failed - will retry later
        notification.lastError = result.error;
        await notification.save();
        return { success: false, error: result.error };
      }
    } catch (error) {
      console.error('Error sending notification:', error);
      notification.lastError = error.message;
      await notification.save();
      return { success: false, error: error.message };
    }
  }

  /**
   * Retry failed notifications with exponential backoff
   */
  async retryFailedNotifications() {
    try {
      // Find failed notifications that haven't exceeded max retries
      const notifications = await NotificationQueue.find({
        status: 'pending',
        lastError: { $ne: null },
        $expr: { $lt: ['$retryCount', '$maxRetries'] }
      }).limit(50);

      if (notifications.length === 0) {
        return { retried: 0, sent: 0, failed: 0 };
      }

      console.log(`Retrying ${notifications.length} failed notifications...`);

      let sent = 0;
      let failed = 0;

      for (const notification of notifications) {
        // Calculate exponential backoff delay
        const backoffMinutes = Math.pow(2, notification.retryCount); // 1, 2, 4, 8 minutes
        const nextRetryTime = new Date(notification.updatedAt);
        nextRetryTime.setMinutes(nextRetryTime.getMinutes() + backoffMinutes);

        // Skip if not time to retry yet
        if (new Date() < nextRetryTime) {
          continue;
        }

        // Increment retry count
        notification.retryCount += 1;
        await notification.save();

        // Attempt to send
        const result = await this.sendNotification(notification);
        
        if (result.success) {
          sent++;
        } else {
          // Check if max retries exceeded
          if (notification.retryCount >= notification.maxRetries) {
            notification.status = 'failed';
            await notification.save();
            console.log(`Notification ${notification._id} failed after ${notification.retryCount} retries`);
          }
          failed++;
        }
      }

      console.log(`Retry results: ${sent} sent, ${failed} failed`);
      return { retried: notifications.length, sent, failed };
    } catch (error) {
      console.error('Error retrying failed notifications:', error);
      throw error;
    }
  }

  /**
   * Update user notification preferences
   */
  async updateNotificationPreferences(userId, preferences) {
    try {
      await User.findByIdAndUpdate(userId, {
        notificationPreferences: preferences
      });
      return { success: true };
    } catch (error) {
      console.error('Error updating notification preferences:', error);
      throw error;
    }
  }

  /**
   * Get preference key for notification type
   */
  getPreferenceKey(type) {
    const mapping = {
      'daily_profit': 'dailyProfit',
      'deposit_approved': 'depositApproved',
      'withdrawal_approved': 'withdrawalApproved',
      'announcement': 'announcements',
      'verification_approved': 'verificationUpdates',
      'verification_rejected': 'verificationUpdates'
    };
    return mapping[type] || null;
  }

  /**
   * Queue deposit approved notification
   */
  async queueDepositApprovedNotification(userId, amount) {
    return await this.queueNotification(userId, {
      type: 'deposit_approved',
      title: 'Deposit Approved ✅',
      body: `Your deposit of ৳${amount.toFixed(2)} has been approved and added to your balance.`,
      data: {
        type: 'deposit_approved',
        amount,
        timestamp: new Date().toISOString()
      },
      scheduledFor: new Date()
    });
  }

  /**
   * Queue withdrawal approved notification
   */
  async queueWithdrawalApprovedNotification(userId, amount) {
    return await this.queueNotification(userId, {
      type: 'withdrawal_approved',
      title: 'Withdrawal Approved ✅',
      body: `Your withdrawal of ৳${amount.toFixed(2)} has been approved and will be processed shortly.`,
      data: {
        type: 'withdrawal_approved',
        amount,
        timestamp: new Date().toISOString()
      },
      scheduledFor: new Date()
    });
  }

  /**
   * Queue verification approved notification
   */
  async queueVerificationApprovedNotification(userId) {
    return await this.queueNotification(userId, {
      type: 'verification_approved',
      title: 'Verification Approved ✅',
      body: 'Your account has been verified! You can now access all features.',
      data: {
        type: 'verification_approved',
        timestamp: new Date().toISOString()
      },
      scheduledFor: new Date()
    });
  }

  /**
   * Queue verification rejected notification
   */
  async queueVerificationRejectedNotification(userId, reason) {
    return await this.queueNotification(userId, {
      type: 'verification_rejected',
      title: 'Verification Rejected ❌',
      body: `Your verification was rejected. Reason: ${reason}`,
      data: {
        type: 'verification_rejected',
        reason,
        timestamp: new Date().toISOString()
      },
      scheduledFor: new Date()
    });
  }

  /**
   * Queue announcement notification
   */
  async queueAnnouncementNotification(userId, title, message) {
    return await this.queueNotification(userId, {
      type: 'announcement',
      title: title,
      body: message,
      data: {
        type: 'announcement',
        timestamp: new Date().toISOString()
      },
      scheduledFor: new Date()
    });
  }

  /**
   * Get notification statistics
   */
  async getStatistics() {
    try {
      const stats = await NotificationQueue.aggregate([
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 }
          }
        }
      ]);

      const result = {
        pending: 0,
        sent: 0,
        failed: 0,
        total: 0
      };

      stats.forEach(stat => {
        result[stat._id] = stat.count;
        result.total += stat.count;
      });

      return result;
    } catch (error) {
      console.error('Error getting notification statistics:', error);
      throw error;
    }
  }
}

export default new NotificationScheduler();
