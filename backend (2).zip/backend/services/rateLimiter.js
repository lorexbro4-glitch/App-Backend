/**
 * In-memory rate limiter for email sending and password resets
 * Tracks requests per user/IP and enforces limits
 */

class RateLimiter {
  constructor() {
    // Store: { key: [timestamp1, timestamp2, ...] }
    this.emailAttempts = new Map();
    this.passwordResetAttempts = new Map();
    
    // Clean up old entries every 5 minutes
    setInterval(() => this.cleanup(), 5 * 60 * 1000);
  }

  /**
   * Check if email sending is allowed for a user
   * @param {string} userId - User ID
   * @param {number} maxAttempts - Maximum attempts allowed (default: 3)
   * @param {number} windowMs - Time window in milliseconds (default: 1 hour)
   * @returns {Object} { allowed: boolean, retryAfter: number|null }
   */
  checkEmailLimit(userId, maxAttempts = 3, windowMs = 60 * 60 * 1000) {
    return this.checkLimit(this.emailAttempts, userId, maxAttempts, windowMs);
  }

  /**
   * Check if password reset is allowed for an IP
   * @param {string} ip - IP address
   * @param {number} maxAttempts - Maximum attempts allowed (default: 5)
   * @param {number} windowMs - Time window in milliseconds (default: 1 hour)
   * @returns {Object} { allowed: boolean, retryAfter: number|null }
   */
  checkPasswordResetLimit(ip, maxAttempts = 5, windowMs = 60 * 60 * 1000) {
    return this.checkLimit(this.passwordResetAttempts, ip, maxAttempts, windowMs);
  }

  /**
   * Record an email send attempt
   * @param {string} userId - User ID
   */
  recordEmailAttempt(userId) {
    this.recordAttempt(this.emailAttempts, userId);
  }

  /**
   * Record a password reset attempt
   * @param {string} ip - IP address
   */
  recordPasswordResetAttempt(ip) {
    this.recordAttempt(this.passwordResetAttempts, ip);
  }

  /**
   * Generic rate limit checker
   * @private
   */
  checkLimit(store, key, maxAttempts, windowMs) {
    const now = Date.now();
    const attempts = store.get(key) || [];
    
    // Filter attempts within the time window
    const recentAttempts = attempts.filter(timestamp => now - timestamp < windowMs);
    
    if (recentAttempts.length >= maxAttempts) {
      // Calculate when the oldest attempt will expire
      const oldestAttempt = Math.min(...recentAttempts);
      const retryAfter = Math.ceil((oldestAttempt + windowMs - now) / 1000); // in seconds
      
      return {
        allowed: false,
        retryAfter,
        attemptsRemaining: 0
      };
    }
    
    return {
      allowed: true,
      retryAfter: null,
      attemptsRemaining: maxAttempts - recentAttempts.length
    };
  }

  /**
   * Record an attempt
   * @private
   */
  recordAttempt(store, key) {
    const now = Date.now();
    const attempts = store.get(key) || [];
    attempts.push(now);
    store.set(key, attempts);
  }

  /**
   * Clean up old entries from memory
   * @private
   */
  cleanup() {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    // Clean email attempts
    for (const [key, attempts] of this.emailAttempts.entries()) {
      const recentAttempts = attempts.filter(timestamp => now - timestamp < oneHour);
      if (recentAttempts.length === 0) {
        this.emailAttempts.delete(key);
      } else {
        this.emailAttempts.set(key, recentAttempts);
      }
    }
    
    // Clean password reset attempts
    for (const [key, attempts] of this.passwordResetAttempts.entries()) {
      const recentAttempts = attempts.filter(timestamp => now - timestamp < oneHour);
      if (recentAttempts.length === 0) {
        this.passwordResetAttempts.delete(key);
      } else {
        this.passwordResetAttempts.set(key, recentAttempts);
      }
    }
  }

  /**
   * Reset limits for a specific key (useful for testing)
   * @param {string} type - 'email' or 'passwordReset'
   * @param {string} key - User ID or IP address
   */
  reset(type, key) {
    if (type === 'email') {
      this.emailAttempts.delete(key);
    } else if (type === 'passwordReset') {
      this.passwordResetAttempts.delete(key);
    }
  }

  /**
   * Clear all rate limit data (useful for testing)
   */
  clearAll() {
    this.emailAttempts.clear();
    this.passwordResetAttempts.clear();
  }
}

// Export singleton instance
export default new RateLimiter();
