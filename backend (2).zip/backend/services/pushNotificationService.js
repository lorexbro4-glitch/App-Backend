import { Expo } from 'expo-server-sdk';
import User from '../models/User.js';
import Agent from '../models/Agent.js';
import Admin from '../models/Admin.js';
import Notification from '../models/Notification.js';

class PushNotificationService {
  constructor() {
    this.expo = new Expo();
    this.maxRetries = 3;
    this.retryDelays = [1000, 2000, 4000]; // Exponential backoff: 1s, 2s, 4s
  }

  /**
   * Check if token is a valid Expo or FCM token
   * @param {String} token - Push token
   * @returns {Boolean}
   */
  isValidPushToken(token) {
    if (!token || typeof token !== 'string') {
      return false;
    }
    
    // Expo token format: ExponentPushToken[xxxxxx]
    if (Expo.isExpoPushToken(token)) {
      return true;
    }
    
    // FCM token format: long string (152+ characters)
    // FCM tokens don't have a specific prefix, just validate length
    if (token.length > 100 && !token.startsWith('ExponentPushToken[')) {
      return true;
    }
    
    return false;
  }

  /**
   * Validate notification input parameters
   * @param {ObjectId} userId - User or Agent ID
   * @param {Object} notification - Notification object
   * @returns {Object} - {valid, error}
   */
  validateNotificationInput(userId, notification) {
    if (!userId) {
      return { valid: false, error: 'User ID is required' };
    }
    if (!notification || typeof notification !== 'object') {
      return { valid: false, error: 'Notification object is required' };
    }
    if (!notification.title || typeof notification.title !== 'string' || notification.title.trim() === '') {
      return { valid: false, error: 'Notification title is required and must be a non-empty string' };
    }
    if (!notification.body || typeof notification.body !== 'string' || notification.body.trim() === '') {
      return { valid: false, error: 'Notification body is required and must be a non-empty string' };
    }
    return { valid: true };
  }

  /**
   * Retry logic with exponential backoff
   * @param {Function} fn - Function to retry
   * @param {Number} attempt - Current attempt number (0-indexed)
   * @returns {Promise<any>} - Result of function
   */
  async retryWithBackoff(fn, attempt = 0) {
    try {
      return await fn();
    } catch (error) {
      if (attempt < this.maxRetries - 1) {
        const delay = this.retryDelays[attempt];
        console.log(`Retry attempt ${attempt + 1}/${this.maxRetries} after ${delay}ms delay`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.retryWithBackoff(fn, attempt + 1);
      }
      throw error;
    }
  }

  /**
   * Comprehensive error logging
   * @param {String} context - Context of the error
   * @param {Object} details - Error details
   */
  logError(context, details) {
    console.error(`[PushNotificationService] ${context}`, {
      timestamp: new Date().toISOString(),
      userId: details.userId || null,
      agentId: details.agentId || null,
      token: details.token || null,
      notificationType: details.notificationType || null,
      error: details.error || null,
      errorMessage: details.errorMessage || null,
      attempt: details.attempt || null,
    });
  }

  /**
   * Send push notification to a specific user
   * @param {ObjectId} userId - User ID
   * @param {Object} notification - Notification object {title, body, data}
   * @returns {Promise<Object>} - {success, receipt, error}
   */
  async sendToUser(userId, notification) {
    // Validate input
    const validation = this.validateNotificationInput(userId, notification);
    if (!validation.valid) {
      this.logError('Input validation failed', {
        userId,
        error: validation.error,
        notificationType: notification?.data?.type || 'unknown',
      });
      return { success: false, error: validation.error };
    }

    try {
      const user = await User.findById(userId);
      if (!user || !user.pushToken || !user.pushTokenValid) {
        this.logError('No valid push token', {
          userId,
          token: user?.pushToken || null,
          notificationType: notification.data?.type || 'unknown',
          error: 'User has no valid push token',
        });
        return { success: false, error: 'No valid push token' };
      }

      // Validate token format
      if (!this.isValidPushToken(user.pushToken)) {
        this.logError('Invalid token format', {
          userId,
          token: user.pushToken,
          notificationType: notification.data?.type || 'unknown',
          error: 'Token does not match Expo or FCM push token format',
        });
        await this.handleInvalidToken(userId, user.pushToken);
        return { success: false, error: 'Invalid push token format' };
      }

      const message = {
        to: user.pushToken,
        sound: 'default',
        title: notification.title,
        body: notification.body,
        data: notification.data || {},
      };

      // Send with retry logic
      const result = await this.retryWithBackoff(async () => {
        const chunks = this.expo.chunkPushNotifications([message]);
        const tickets = [];

        for (const chunk of chunks) {
          const ticketChunk = await this.expo.sendPushNotificationsAsync(chunk);
          tickets.push(...ticketChunk);
        }

        const ticket = tickets[0];
        if (ticket.status === 'error') {
          if (ticket.details && ticket.details.error === 'DeviceNotRegistered') {
            await this.handleInvalidToken(userId, user.pushToken);
          }
          throw new Error(ticket.message || 'Push notification ticket error');
        }

        return { success: true, receipt: ticket.id };
      });

      console.log(`[PushNotificationService] Successfully sent notification to user ${userId}`);
      return result;
    } catch (error) {
      this.logError('Failed to send notification after retries', {
        userId,
        token: (await User.findById(userId))?.pushToken || null,
        notificationType: notification.data?.type || 'unknown',
        error: error.name,
        errorMessage: error.message,
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Send push notification to multiple users
   * @param {Array<ObjectId>} userIds - Array of user IDs
   * @param {Object} notification - Notification object {title, body, data}
   * @returns {Promise<Object>} - {sent, failed, receipts}
   */
  async sendToUsers(userIds, notification) {
    const results = await Promise.all(
      userIds.map(userId => this.sendToUser(userId, notification))
    );

    const sent = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    const receipts = results.filter(r => r.receipt).map(r => r.receipt);

    return { sent, failed, receipts };
  }

  /**
   * Send push notification to an agent
   * @param {ObjectId} agentId - Agent ID
   * @param {Object} notification - Notification object {title, body, data}
   * @returns {Promise<Object>} - {success, receipt, error}
   */
  async sendToAgent(agentId, notification) {
    // Validate input
    const validation = this.validateNotificationInput(agentId, notification);
    if (!validation.valid) {
      this.logError('Input validation failed', {
        agentId,
        error: validation.error,
        notificationType: notification?.data?.type || 'unknown',
      });
      return { success: false, error: validation.error };
    }

    try {
      const agent = await Agent.findById(agentId);
      if (!agent || !agent.pushToken) {
        this.logError('No valid push token', {
          agentId,
          token: agent?.pushToken || null,
          notificationType: notification.data?.type || 'unknown',
          error: 'Agent has no valid push token',
        });
        return { success: false, error: 'No valid push token' };
      }

      // Validate token format
      if (!this.isValidPushToken(agent.pushToken)) {
        this.logError('Invalid token format', {
          agentId,
          token: agent.pushToken,
          notificationType: notification.data?.type || 'unknown',
          error: 'Token does not match Expo or FCM push token format',
        });
        return { success: false, error: 'Invalid push token format' };
      }

      const message = {
        to: agent.pushToken,
        sound: 'default',
        title: notification.title,
        body: notification.body,
        data: notification.data || {},
      };

      // Send with retry logic
      const result = await this.retryWithBackoff(async () => {
        const chunks = this.expo.chunkPushNotifications([message]);
        const tickets = [];

        for (const chunk of chunks) {
          const ticketChunk = await this.expo.sendPushNotificationsAsync(chunk);
          tickets.push(...ticketChunk);
        }

        const ticket = tickets[0];
        if (ticket.status === 'error') {
          throw new Error(ticket.message || 'Push notification ticket error');
        }

        return { success: true, receipt: ticket.id };
      });

      console.log(`[PushNotificationService] Successfully sent notification to agent ${agentId}`);
      return result;
    } catch (error) {
      this.logError('Failed to send notification after retries', {
        agentId,
        token: (await Agent.findById(agentId))?.pushToken || null,
        notificationType: notification.data?.type || 'unknown',
        error: error.name,
        errorMessage: error.message,
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Register push token for a user
   * @param {ObjectId} userId - User ID
   * @param {String} pushToken - Expo push token
   * @returns {Promise<Object>} - {success, error, welcomeNotificationSent}
   */
  async registerToken(userId, pushToken) {
    try {
      // Validate token format
      if (!this.isValidPushToken(pushToken)) {
        this.logError('Invalid token format on registration', {
          userId,
          token: pushToken,
          error: 'Token does not match Expo or FCM push token format',
        });
        throw new Error('Invalid push token format');
      }

      // Update user with token
      await User.findByIdAndUpdate(userId, {
        pushToken,
        pushTokenUpdatedAt: new Date(),
        pushTokenValid: true,
      });

      console.log(`[PushNotificationService] Registered push token for user ${userId}`);

      // Send welcome notification to validate token
      const welcomeResult = await this.sendToUser(userId, {
        title: 'Notifications Enabled',
        body: 'You will now receive push notifications for important updates.',
        data: { type: 'welcome' },
      });

      if (welcomeResult.success) {
        console.log(`[PushNotificationService] Welcome notification sent to user ${userId}`);
      } else {
        this.logError('Welcome notification failed', {
          userId,
          token: pushToken,
          error: welcomeResult.error,
        });
      }

      return {
        success: true,
        welcomeNotificationSent: welcomeResult.success,
      };
    } catch (error) {
      this.logError('Error registering push token', {
        userId,
        token: pushToken,
        error: error.name,
        errorMessage: error.message,
      });
      throw error;
    }
  }

  /**
   * Register push token for an agent
   * @param {ObjectId} agentId - Agent ID
   * @param {String} pushToken - Expo push token
   * @returns {Promise<Object>} - {success, error, welcomeNotificationSent}
   */
  async registerAgentToken(agentId, pushToken) {
    try {
      // Validate token format
      if (!this.isValidPushToken(pushToken)) {
        this.logError('Invalid token format on registration', {
          agentId,
          token: pushToken,
          error: 'Token does not match Expo or FCM push token format',
        });
        throw new Error('Invalid push token format');
      }

      // Update agent with token
      await Agent.findByIdAndUpdate(agentId, {
        pushToken,
      });

      console.log(`[PushNotificationService] Registered push token for agent ${agentId}`);

      // Send welcome notification to validate token
      const welcomeResult = await this.sendToAgent(agentId, {
        title: 'Notifications Enabled',
        body: 'You will now receive push notifications for important updates.',
        data: { type: 'welcome' },
      });

      if (welcomeResult.success) {
        console.log(`[PushNotificationService] Welcome notification sent to agent ${agentId}`);
      } else {
        this.logError('Welcome notification failed', {
          agentId,
          token: pushToken,
          error: welcomeResult.error,
        });
      }

      return {
        success: true,
        welcomeNotificationSent: welcomeResult.success,
      };
    } catch (error) {
      this.logError('Error registering agent push token', {
        agentId,
        token: pushToken,
        error: error.name,
        errorMessage: error.message,
      });
      throw error;
    }
  }

  /**
   * Handle invalid push token
   * @param {ObjectId} userId - User ID
   * @param {String} pushToken - Invalid push token
   */
  async handleInvalidToken(userId, pushToken) {
    try {
      await User.findByIdAndUpdate(userId, {
        pushTokenValid: false,
      });
      console.log(`Marked push token as invalid for user ${userId}`);
    } catch (error) {
      console.error('Error handling invalid token:', error);
    }
  }

  /**
   * Create notification record and send push notification
   * @param {ObjectId} userId - User ID
   * @param {String} type - Notification type
   * @param {String} title - Notification title
   * @param {String} message - Notification message
   * @param {Object} metadata - Additional metadata
   * @returns {Promise<Object>} - Created notification
   */
  async createAndSendNotification(userId, type, title, message, metadata = {}) {
    try {
      console.log('📝 [createAndSendNotification] Creating notification record:', {
        userId,
        type,
        title,
        metadataKeys: Object.keys(metadata)
      });
      
      // Create notification record
      const notification = await Notification.create({
        userId,
        type,
        title,
        message,
        metadata,
      });

      console.log('✅ [createAndSendNotification] Notification record created:', {
        notificationId: notification._id,
        userId: notification.userId,
        type: notification.type
      });

      // Send push notification
      console.log('📤 [createAndSendNotification] Attempting to send push notification...');
      const pushResult = await this.sendToUser(userId, {
        title,
        body: message,
        data: { notificationId: notification._id.toString(), type },
      });

      console.log('📤 [createAndSendNotification] Push notification result:', {
        success: pushResult.success,
        error: pushResult.error || 'none'
      });

      // Update notification with push result
      notification.pushSent = pushResult.success;
      notification.pushReceipt = pushResult.receipt || null;
      notification.pushError = pushResult.error || null;
      notification.pushSentAt = pushResult.success ? new Date() : null;
      await notification.save();

      console.log('💾 [createAndSendNotification] Notification record updated with push result');

      return notification;
    } catch (error) {
      console.error('❌ [createAndSendNotification] Error:', {
        error: error.message,
        stack: error.stack,
        userId,
        type
      });
      throw error;
    }
  }

  /**
   * Send push notification to all admin devices
   * @param {Object} notification - Notification object {title, body, data}
   * @returns {Promise<Object>} - {sent, failed, receipts, errors}
   */
  async sendToAdmins(notification) {
    // Validate input
    if (!notification || typeof notification !== 'object') {
      this.logError('Admin notification validation failed', {
        error: 'Notification object is required',
        notificationType: notification?.data?.type || 'unknown',
      });
      return { sent: 0, failed: 0, receipts: [], errors: [{ error: 'Notification object is required' }] };
    }
    if (!notification.title || typeof notification.title !== 'string' || notification.title.trim() === '') {
      this.logError('Admin notification validation failed', {
        error: 'Notification title is required and must be a non-empty string',
        notificationType: notification?.data?.type || 'unknown',
      });
      return { sent: 0, failed: 0, receipts: [], errors: [{ error: 'Notification title is required' }] };
    }
    if (!notification.body || typeof notification.body !== 'string' || notification.body.trim() === '') {
      this.logError('Admin notification validation failed', {
        error: 'Notification body is required and must be a non-empty string',
        notificationType: notification?.data?.type || 'unknown',
      });
      return { sent: 0, failed: 0, receipts: [], errors: [{ error: 'Notification body is required' }] };
    }

    // Define admin-relevant notification types (only for PENDING items)
    const ADMIN_NOTIFICATION_TYPES = [
      'deposit_request',        // New pending deposit
      'withdrawal_request',     // New pending withdrawal
      'verification_request',   // New pending verification
      'kyc_verification',       // New pending KYC verification
      'agent_registration',     // New pending agent registration
      'token'                   // Admin device token registration (for testing)
    ];

    // Filter out non-admin notifications
    const notificationType = notification.data?.type || '';
    if (notificationType && !ADMIN_NOTIFICATION_TYPES.includes(notificationType)) {
      console.log(`[PushNotificationService] Filtering out non-admin notification type: ${notificationType}`);
      return { sent: 0, failed: 0, receipts: [], errors: [] };
    }

    try {
      // Query all active admins
      const admins = await Admin.find({ isActive: true });
      
      if (admins.length === 0) {
        console.log('[PushNotificationService] No active admins found for notification');
        return { sent: 0, failed: 0, receipts: [], errors: [] };
      }

      // Collect all push tokens from all admins into flat array
      const allTokens = [];
      for (const admin of admins) {
        if (admin.pushTokens && admin.pushTokens.length > 0) {
          for (const tokenObj of admin.pushTokens) {
            allTokens.push(tokenObj.token);
          }
        }
      }

      if (allTokens.length === 0) {
        console.log('[PushNotificationService] No push tokens found for admins');
        return { sent: 0, failed: 0, receipts: [], errors: [] };
      }

      // Remove duplicate tokens
      const uniqueTokens = [...new Set(allTokens)];

      // Validate each token format and filter out invalid ones
      const validTokens = [];
      for (const token of uniqueTokens) {
        if (this.isValidPushToken(token)) {
          validTokens.push(token);
        } else {
          console.warn(`[PushNotificationService] Invalid admin token format, removing: ${token}`);
          await this.removeInvalidAdminToken(token);
        }
      }

      if (validTokens.length === 0) {
        console.warn('[PushNotificationService] No valid push tokens found for admins');
        return { sent: 0, failed: 0, receipts: [], errors: [] };
      }

      // Log notification attempt
      console.log(`[PushNotificationService] Sending admin notification: type=${notification.data?.type || 'unknown'}, admins=${admins.length}, tokens=${validTokens.length}`);

      // Build message objects for each valid token
      const messages = validTokens.map(token => ({
        to: token,
        sound: 'default',
        title: notification.title,
        body: notification.body,
        data: notification.data || {},
      }));

      // Chunk messages using expo.chunkPushNotifications()
      const chunks = this.expo.chunkPushNotifications(messages);

      // Send each chunk with existing retry logic
      const receipts = [];
      const errors = [];
      let sent = 0;
      let failed = 0;

      for (const chunk of chunks) {
        try {
          const ticketChunk = await this.retryWithBackoff(async () => {
            return await this.expo.sendPushNotificationsAsync(chunk);
          });

          // Process each ticket in the chunk
          for (let i = 0; i < ticketChunk.length; i++) {
            const ticket = ticketChunk[i];
            const message = chunk[i];

            if (ticket.status === 'ok') {
              receipts.push(ticket.id);
              sent++;
              console.log(`[PushNotificationService] Admin notification sent successfully: receipt=${ticket.id}`);
            } else if (ticket.status === 'error') {
              failed++;
              const errorDetails = {
                token: message.to,
                error: ticket.details?.error || 'Unknown error',
                message: ticket.message || 'Push notification ticket error',
              };
              errors.push(errorDetails);

              // Handle DeviceNotRegistered error by removing invalid token
              if (ticket.details && ticket.details.error === 'DeviceNotRegistered') {
                console.warn(`[PushNotificationService] Invalid admin token removed: token=${message.to}, error=DeviceNotRegistered`);
                await this.removeInvalidAdminToken(message.to);
              }

              this.logError('Admin notification send failed', {
                token: message.to,
                notificationType: notification.data?.type || 'unknown',
                error: ticket.details?.error || 'Unknown error',
                errorMessage: ticket.message,
              });
            }
          }
        } catch (error) {
          // If entire chunk fails after retries, mark all messages in chunk as failed
          failed += chunk.length;
          for (const message of chunk) {
            errors.push({
              token: message.to,
              error: error.name,
              message: error.message,
            });
          }
          this.logError('Admin notification chunk failed after retries', {
            chunkSize: chunk.length,
            notificationType: notification.data?.type || 'unknown',
            error: error.name,
            errorMessage: error.message,
          });
        }
      }

      // Log final summary
      console.log(`[PushNotificationService] Admin notification complete: sent=${sent}, failed=${failed}`);

      return { sent, failed, receipts, errors };
    } catch (error) {
      this.logError('Failed to send admin notifications', {
        notificationType: notification?.data?.type || 'unknown',
        error: error.name,
        errorMessage: error.message,
      });
      return { sent: 0, failed: 0, receipts: [], errors: [{ error: error.name, message: error.message }] };
    }
  }

  /**
   * Remove invalid push token from admin's pushTokens array
   * @param {String} token - Invalid push token
   */
  async removeInvalidAdminToken(token) {
    try {
      // Find admin with matching token in pushTokens array
      const admin = await Admin.findOne({ 'pushTokens.token': token });
      
      if (admin) {
        await admin.removePushToken(token);
        console.log(`[PushNotificationService] Invalid admin token removed: admin=${admin.username}, token=${token}`);
      }
    } catch (error) {
      console.error('[PushNotificationService] Error removing invalid admin token:', error);
    }
  }
}

export default new PushNotificationService();
