import Transaction from '../models/Transaction.js';

// Status translations in English
const STATUS_TEXT = {
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
  completed: 'Completed',
  failed: 'Failed',
};

class TransactionHistoryService {
  /**
   * Create transaction record for request submission
   * @param {ObjectId} userId - User ID
   * @param {String} type - 'deposit' or 'withdrawal'
   * @param {Number} amount - Amount
   * @param {ObjectId} requestId - Request ID (Deposit or Withdraw)
   * @returns {Promise<Transaction>}
   */
  async createRequestTransaction(userId, type, amount, requestId) {
    try {
      const transactionType = type === 'deposit' ? 'deposit_request' : 'withdraw_request';
      const requestType = type === 'deposit' ? 'Deposit' : 'Withdraw';

      const transaction = await Transaction.create({
        user: userId,
        type: transactionType,
        amount,
        status: 'pending',
        description: type === 'deposit' 
          ? `ডিপোজিট রিকোয়েস্ট জমা দেওয়া হয়েছে: ৳${amount}`
          : `উইথড্র রিকোয়েস্ট জমা দেওয়া হয়েছে: ৳${amount}`,
        requestId,
        requestType,
        displayStatus: STATUS_TEXT.pending,
      });

      return transaction;
    } catch (error) {
      console.error('Error creating request transaction:', error);
      throw error;
    }
  }

  /**
   * Create transaction record for admin action (approval/rejection)
   * @param {ObjectId} userId - User ID
   * @param {String} requestType - 'deposit' or 'withdrawal'
   * @param {String} action - 'approved' or 'rejected'
   * @param {Number} amount - Amount
   * @param {ObjectId} requestId - Request ID
   * @param {ObjectId} submissionTransactionId - ID of submission transaction
   * @param {String} reason - Rejection reason (optional)
   * @returns {Promise<Transaction>}
   */
  async createActionTransaction(userId, requestType, action, amount, requestId, submissionTransactionId, reason = null) {
    try {
      // Normalize requestType to match enum values (withdraw vs withdrawal)
      const normalizedType = requestType === 'withdrawal' ? 'withdraw' : requestType;
      const transactionType = `${normalizedType}_${action}`;
      const status = action === 'approved' ? 'completed' : 'failed';
      const displayStatus = STATUS_TEXT[action];

      let description = '';
      if (requestType === 'deposit') {
        description = action === 'approved'
          ? `ডিপোজিট অনুমোদিত: ৳${amount}`
          : `ডিপোজিট প্রত্যাখ্যাত: ৳${amount}`;
      } else {
        description = action === 'approved'
          ? `উইথড্র অনুমোদিত: ৳${amount}`
          : `উইথড্র প্রত্যাখ্যাত: ৳${amount}`;
      }

      if (reason) {
        description += ` - ${reason}`;
      }

      const transaction = await Transaction.create({
        user: userId,
        type: transactionType,
        amount,
        status,
        description,
        requestId,
        requestType: requestType === 'deposit' ? 'Deposit' : 'Withdraw',
        relatedTransactionId: submissionTransactionId,
        displayStatus,
      });

      return transaction;
    } catch (error) {
      console.error('Error creating action transaction:', error);
      throw error;
    }
  }

  /**
   * Get complete transaction history for a user with linked records
   * @param {ObjectId} userId - User ID
   * @param {Object} options - Query options {limit, skip, sort}
   * @returns {Promise<Array>} - Array of transactions
   */
  async getCompleteHistory(userId, options = {}) {
    try {
      const {
        limit = 50,
        skip = 0,
        sort = { createdAt: -1 },
      } = options;

      const transactions = await Transaction.find({ user: userId })
        .sort(sort)
        .limit(limit)
        .skip(skip)
        .populate('relatedTransactionId')
        .lean();

      // Group related transactions together
      const grouped = [];
      const processed = new Set();

      for (const transaction of transactions) {
        if (processed.has(transaction._id.toString())) {
          continue;
        }

        // Check if this is a submission transaction
        if (transaction.type.includes('_request')) {
          // Find related action transaction
          const actionTransaction = transactions.find(
            t => t.relatedTransactionId && 
            t.relatedTransactionId.toString() === transaction._id.toString()
          );

          if (actionTransaction) {
            grouped.push({
              submission: transaction,
              action: actionTransaction,
              type: 'linked',
            });
            processed.add(transaction._id.toString());
            processed.add(actionTransaction._id.toString());
          } else {
            grouped.push({
              submission: transaction,
              action: null,
              type: 'pending',
            });
            processed.add(transaction._id.toString());
          }
        } else if (!transaction.relatedTransactionId) {
          // Standalone transaction (profit_added, referral_bonus, etc.)
          grouped.push({
            transaction,
            type: 'standalone',
          });
          processed.add(transaction._id.toString());
        }
      }

      return grouped;
    } catch (error) {
      console.error('Error getting complete history:', error);
      throw error;
    }
  }

  /**
   * Get status text in English
   * @param {String} status - Status in English
   * @returns {String} - Status text
   */
  getStatusText(status) {
    return STATUS_TEXT[status] || status;
  }
}

export default new TransactionHistoryService();
