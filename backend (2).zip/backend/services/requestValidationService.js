import User from '../models/User.js';
import Deposit from '../models/Deposit.js';
import Withdraw from '../models/Withdraw.js';

class RequestValidationService {
  /**
   * Check if user has a pending deposit request
   * @param {ObjectId} userId - User ID
   * @returns {Promise<Boolean>}
   */
  async hasPendingDeposit(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) return false;

      // Check cached flag first
      if (user.hasPendingDeposit) {
        // Verify with database
        const pendingDeposit = await Deposit.findOne({
          user: userId,
          status: 'pending',
        });
        return !!pendingDeposit;
      }

      return false;
    } catch (error) {
      console.error('Error checking pending deposit:', error);
      // Fallback to database check
      const pendingDeposit = await Deposit.findOne({
        user: userId,
        status: 'pending',
      });
      return !!pendingDeposit;
    }
  }

  /**
   * Check if user has a pending withdrawal request
   * @param {ObjectId} userId - User ID
   * @returns {Promise<Boolean>}
   */
  async hasPendingWithdrawal(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) return false;

      // Check cached flag first
      if (user.hasPendingWithdrawal) {
        // Verify with database
        const pendingWithdrawal = await Withdraw.findOne({
          user: userId,
          status: 'pending',
        });
        return !!pendingWithdrawal;
      }

      return false;
    } catch (error) {
      console.error('Error checking pending withdrawal:', error);
      // Fallback to database check
      const pendingWithdrawal = await Withdraw.findOne({
        user: userId,
        status: 'pending',
      });
      return !!pendingWithdrawal;
    }
  }

  /**
   * Check if capital is locked (dynamic calculation from lastDepositDate)
   * @param {ObjectId} userId - User ID
   * @returns {Promise<Object>} - {isLocked, lockUntil, daysRemaining}
   */
  async checkCapitalLock(userId) {
    try {
      const user = await User.findById(userId);
      
      if (!user || !user.lastDepositDate) {
        return {
          isLocked: false,
          lockUntil: null,
          daysRemaining: 0,
        };
      }

      // Calculate lock date (90 days from last deposit)
      const lockDate = new Date(user.lastDepositDate);
      lockDate.setDate(lockDate.getDate() + 90);
      
      // Check if still locked
      const now = new Date();
      const isLocked = now < lockDate;
      
      // Calculate days remaining
      const diffTime = lockDate.getTime() - now.getTime();
      const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      return {
        isLocked,
        lockUntil: lockDate,
        daysRemaining: daysRemaining > 0 ? daysRemaining : 0,
      };
    } catch (error) {
      console.error('Error checking capital lock:', error);
      return {
        isLocked: false,
        lockUntil: null,
        daysRemaining: 0,
      };
    }
  }

  /**
   * Calculate capital lock date (90 days from last deposit)
   * @param {Date} lastDepositDate - Last deposit date
   * @returns {Date} - Capital lock until date
   */
  calculateCapitalLockDate(lastDepositDate) {
    if (!lastDepositDate) return null;

    const lockDate = new Date(lastDepositDate);
    lockDate.setDate(lockDate.getDate() + 90);
    return lockDate;
  }

  /**
   * Validate capital lock for withdrawal
   * @param {ObjectId} userId - User ID
   * @param {String} withdrawalType - 'capital' or 'profit'
   * @returns {Promise<Object>} - {isLocked, lockUntil, canWithdrawCapital, message}
   */
  async validateCapitalLock(userId, withdrawalType) {
    try {
      // Profit withdrawals are always allowed
      if (withdrawalType === 'profit') {
        return {
          isLocked: false,
          lockUntil: null,
          canWithdrawCapital: true,
          message: null,
        };
      }

      const user = await User.findById(userId);
      if (!user) {
        return {
          isLocked: false,
          lockUntil: null,
          canWithdrawCapital: false,
          message: 'User not found',
        };
      }

      // Calculate capital lock date
      const lockUntil = this.calculateCapitalLockDate(user.lastDepositDate);
      if (!lockUntil) {
        return {
          isLocked: false,
          lockUntil: null,
          canWithdrawCapital: true,
          message: null,
        };
      }

      // Compare dates at midnight to avoid time-of-day issues
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      
      const lockDate = new Date(lockUntil);
      lockDate.setHours(0, 0, 0, 0);

      const isLocked = now < lockDate;

      if (isLocked) {
        const formattedDate = this.formatDateBengali(lockUntil);
        return {
          isLocked: true,
          lockUntil,
          canWithdrawCapital: false,
          message: `মূলধন উত্তোলন ${formattedDate} তারিখের পরে সম্ভব`, // Capital withdrawal possible after {date}
        };
      }

      return {
        isLocked: false,
        lockUntil,
        canWithdrawCapital: true,
        message: null,
      };
    } catch (error) {
      console.error('Error validating capital lock:', error);
      throw error;
    }
  }

  /**
   * Format date in Bengali format (DD/MM/YYYY)
   * @param {Date} date - Date to format
   * @returns {String} - Formatted date
   */
  formatDateBengali(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  /**
   * Update user's pending request flags
   * @param {ObjectId} userId - User ID
   * @param {String} requestType - 'deposit' or 'withdrawal'
   * @param {Boolean} hasPending - Whether user has pending request
   */
  async updatePendingFlag(userId, requestType, hasPending) {
    try {
      const update = {};
      if (requestType === 'deposit') {
        update.hasPendingDeposit = hasPending;
      } else if (requestType === 'withdrawal') {
        update.hasPendingWithdrawal = hasPending;
      }

      await User.findByIdAndUpdate(userId, update);
    } catch (error) {
      console.error('Error updating pending flag:', error);
    }
  }

  /**
   * Update user's last deposit date (capital lock is calculated dynamically)
   * @param {ObjectId} userId - User ID
   * @param {Date} lastDepositDate - Last deposit date
   */
  async updateCapitalLock(userId, lastDepositDate) {
    try {
      // Only update lastDepositDate - capitalLockUntil is calculated dynamically
      await User.findByIdAndUpdate(userId, {
        lastDepositDate,
      });
    } catch (error) {
      console.error('Error updating capital lock:', error);
    }
  }
}

export default new RequestValidationService();
