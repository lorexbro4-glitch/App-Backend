import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema({
  action: {
    type: String,
    required: true,
    enum: [
      'user.create', 'user.update', 'user.delete',
      'deposit.approve', 'deposit.reject',
      'withdrawal.approve', 'withdrawal.reject',
      'settings.update',
      'announcement.create', 'announcement.update', 'announcement.delete',
      'verification.approve', 'verification.reject',
      'agent.approve', 'agent.reject',
      'user.gift'
    ],
    index: true
  },
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  adminEmail: {
    type: String,
    required: true
  },
  resourceType: {
    type: String,
    required: true,
    enum: ['User', 'Deposit', 'Withdraw', 'Settings', 'Announcement', 'Verification', 'Agent'],
    index: true
  },
  resourceId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    index: true
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  ipAddress: {
    type: String,
    default: null
  },
  userAgent: {
    type: String,
    default: null
  },
  changes: {
    before: mongoose.Schema.Types.Mixed,
    after: mongoose.Schema.Types.Mixed
  },
  metadata: {
    reason: String,
    requestId: String,
    additionalInfo: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

// Compound indexes for common queries
auditLogSchema.index({ adminId: 1, timestamp: -1 });
auditLogSchema.index({ resourceType: 1, resourceId: 1 });
auditLogSchema.index({ action: 1, timestamp: -1 });

// TTL index - automatically delete logs older than 365 days
auditLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 31536000 }); // 365 days

export default mongoose.model('AuditLog', auditLogSchema);
