import mongoose from 'mongoose';

const notificationQueueSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  type: {
    type: String,
    required: true,
    enum: ['daily_profit', 'deposit_approved', 'withdrawal_approved', 'announcement', 'verification_approved', 'verification_rejected'],
    index: true
  },
  title: {
    type: String,
    required: true
  },
  body: {
    type: String,
    required: true
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  status: {
    type: String,
    enum: ['pending', 'sent', 'failed'],
    default: 'pending',
    index: true
  },
  scheduledFor: {
    type: Date,
    required: true,
    index: true
  },
  sentAt: {
    type: Date,
    default: null
  },
  retryCount: {
    type: Number,
    default: 0
  },
  maxRetries: {
    type: Number,
    default: 3
  },
  lastError: {
    type: String,
    default: null
  },
  pushReceipt: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Compound indexes for efficient queries
notificationQueueSchema.index({ status: 1, scheduledFor: 1 });
notificationQueueSchema.index({ userId: 1, type: 1, createdAt: -1 });
notificationQueueSchema.index({ status: 1, retryCount: 1 });

// TTL index to auto-delete old notifications after 30 days
notificationQueueSchema.index({ createdAt: 1 }, { expireAfterSeconds: 2592000 });

export default mongoose.model('NotificationQueue', notificationQueueSchema);
