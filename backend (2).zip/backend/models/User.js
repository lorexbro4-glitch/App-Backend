import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    unique: true,
    sparse: true,
    lowercase: true,
    trim: true,
    minlength: 5,
    maxlength: 15,
    validate: {
      validator: function(v) {
        // Only allow a-z, 0-9, and underscore
        return /^[a-z0-9_]+$/.test(v);
      },
      message: 'Username can only contain lowercase letters, numbers, and underscores'
    }
  },
  phone: {
    type: String,
    sparse: true,
  },
  password: {
    type: String,
    required: true,
  },
  withdrawPassword: {
    type: String,
    default: null,
  },
  name: {
    type: String,
    default: '',
  },
  email: {
    type: String,
    unique: true,
    sparse: true,
    lowercase: true,
    trim: true,
  },
  emailVerified: {
    type: Boolean,
    default: false,
  },
  emailVerificationToken: {
    type: String,
    default: null,
  },
  emailVerificationExpires: {
    type: Date,
    default: null,
  },
  passwordResetToken: {
    type: String,
    default: null,
  },
  passwordResetExpires: {
    type: Date,
    default: null,
  },
  profilePicture: {
    type: String,
    default: null,
  },
  googleId: {
    type: String,
    unique: true,
    sparse: true,
  },
  authProvider: {
    type: String,
    enum: ['phone', 'email', 'google'],
    default: 'phone',
  },
  // Push notification token
  pushToken: {
    type: String,
    default: null,
  },
  pushTokenUpdatedAt: {
    type: Date,
    default: null,
  },
  pushTokenValid: {
    type: Boolean,
    default: true,
  },
  // Notification preferences
  notificationPreferences: {
    dailyProfit: {
      type: Boolean,
      default: true,
    },
    depositApproved: {
      type: Boolean,
      default: true,
    },
    withdrawalApproved: {
      type: Boolean,
      default: true,
    },
    announcements: {
      type: Boolean,
      default: true,
    },
    verificationUpdates: {
      type: Boolean,
      default: true,
    },
  },
  // Balance fields
  balance: {
    type: Number,
    default: 0,
  },
  capital: {
    type: Number,
    default: 0,
  },
  totalProfit: {
    type: Number,
    default: 0,
  },
  // Legacy fields (keep for backward compatibility)
  depositTotal: {
    type: Number,
    default: 0,
  },
  profitTotal: {
    type: Number,
    default: 0,
  },
  referralIncome: {
    type: Number,
    default: 0,
  },
  referralCount: {
    type: Number,
    default: 0,
  },
  referredBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  // Status fields
  isVerified: {
    type: Boolean,
    default: false,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  // Legacy fields (keep for backward compatibility)
  verified: {
    type: Boolean,
    default: false,
  },
  banned: {
    type: Boolean,
    default: false,
  },
  joinDate: {
    type: Date,
    default: Date.now,
  },
  lastDepositDate: {
    type: Date,
    default: null,
  },
  firstDepositDate: {
    type: Date,
    default: null,
  },
  lastProfitAdd: {
    type: Date,
    default: Date.now,
  },
  // Capital lock fields
  capitalLockUntil: {
    type: Date,
    default: null,
  },
  // Pending request tracking
  hasPendingDeposit: {
    type: Boolean,
    default: false,
  },
  hasPendingWithdrawal: {
    type: Boolean,
    default: false,
  },
  // KYC bonus field
  kycBonusGiven: {
    type: Boolean,
    default: false,
  },
  // ── House edge trade control ──────────────────────────────────────────────
  tradeControl: {
    totalTrades:    { type: Number, default: 0 },
    houseTaken:     { type: Number, default: 0 },    // total taken from user this cycle
    userProfit:     { type: Number, default: 0 },    // total paid to user this cycle
    lastReset:      { type: Date,   default: null }, // when 12h cycle last reset
    // Admin direct control — overrides all cycle logic
    adminOverride:  { type: String, default: null }, // 'force_loss' | 'force_win' | null
    overrideTrades: { type: Number, default: 0 },    // trades left under override (0=permanent)
  },
}, {
  timestamps: true
});

// Indexes for efficient queries
// Note: email, googleId, and username already have unique indexes from schema definition
userSchema.index({ emailVerificationToken: 1 });
userSchema.index({ passwordResetToken: 1 });
userSchema.index({ pushToken: 1 });
userSchema.index({ hasPendingDeposit: 1 });
userSchema.index({ hasPendingWithdrawal: 1 });

// TTL index: automatically delete unverified accounts after 1 hour
// Only fires when emailVerificationExpires is set (i.e. not-yet-verified email accounts)
// Verified accounts have emailVerificationExpires = null so they are NOT affected
userSchema.index(
  { emailVerificationExpires: 1 },
  { expireAfterSeconds: 3600, partialFilterExpression: { emailVerified: false } }
);

// Additional indexes for Phase 1 improvements
userSchema.index({ phone: 1, isActive: 1 });
userSchema.index({ referredBy: 1 });
userSchema.index({ isVerified: 1, isActive: 1 });

export default mongoose.model('User', userSchema);
