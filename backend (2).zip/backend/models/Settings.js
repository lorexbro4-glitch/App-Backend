import mongoose from 'mongoose';

const settingsSchema = new mongoose.Schema({
  appDownloadLink: {
    type: String,
    default: 'https://upload.app/your-app-link',
  },
  appName: {
    type: String,
    default: 'YFBD',
  },
  // Add more settings as needed
  maintenanceMode: {
    type: Boolean,
    default: false,
  },
  maintenanceMessage: {
    type: String,
    default: 'সিস্টেম আপডেট চলছে। কিছুক্ষণ পর আবার চেষ্টা করুন।',
  },
  // Admin settings
  withdrawalNumbers: {
    bkash: { 
      number: { type: String, default: '01712345678' },
      mode: { type: String, enum: ['personal', 'agent'], default: 'personal' }
    },
    nagad: { 
      number: { type: String, default: '01712345679' },
      mode: { type: String, enum: ['personal', 'agent'], default: 'personal' }
    },
    rocket: { 
      number: { type: String, default: '01712345680' },
      mode: { type: String, enum: ['personal', 'agent'], default: 'personal' }
    }
  },
  profitRate: {
    type: Number,
    default: 12
  },
  minDeposit: {
    type: Number,
    default: 500
  },
  maxDeposit: {
    type: Number,
    default: 50000
  },
  referralBonus: {
    type: Number,
    default: 5
  },
  capitalLockMonths: {
    type: Number,
    default: 3
  },
  referralUrl: {
    type: String,
    default: ''
  },
  referralQrImage: {
    type: String,
    default: ''
  },
  // Force Update Settings
  forceUpdateEnabled: {
    type: Boolean,
    default: false
  },
  minimumAppVersion: {
    type: String,
    default: '2.1.0'
  },
  updateMessage: {
    type: String,
    default: 'নতুন ভার্সন উপলব্ধ! অ্যাপ ব্যবহার করতে আপডেট করুন।'
  },
  // Update countdown timer (in minutes). 0 = no timer, download available immediately.
  updateDelayMinutes: {
    type: Number,
    default: 0
  },
  // Timestamp (ms) when the admin last set/reset the update timer.
  // The countdown starts from this moment for all users.
  updateTimerSetAt: {
    type: Number,
    default: null
  },
  // Profit distribution tracking
  lastProfitDate: {
    type: String,  // stored as 'YYYY-MM-DD' in Bangladesh time
    default: null
  },
  profitDistributionFailed: {
    type: Boolean,
    default: false
  },
  // Leaderboard display total users — persisted so server restarts don't reset it
  displayTotalUsers: {
    type: Number,
    default: 2001604
  }
}, {
  timestamps: true
});

export default mongoose.model('Settings', settingsSchema);
