import mongoose from 'mongoose';

const appRatingSchema = new mongoose.Schema({
  totalRatings: { type: Number, default: 100000 },
  totalScore:   { type: Number, default: 480000 }, // 100000 * 4.8
  star5: { type: Number, default: 84000 },
  star4: { type: Number, default: 10000 },
  star3: { type: Number, default: 4000 },
  star2: { type: Number, default: 1000 },
  star1: { type: Number, default: 1000 },
}, { timestamps: true });

export default mongoose.model('AppRating', appRatingSchema);
