import mongoose from 'mongoose';

/**
 * Trade — one binary option trade placed by a user
 */
const tradeSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  assetId:    { type: String, required: true },   // 'EUR/USD'
  assetLabel: { type: String, required: true },   // display name
  direction:  { type: String, enum: ['up', 'down'], required: true },
  amount:     { type: Number, required: true, min: 1 },
  payout:     { type: Number, required: true },   // e.g. 82 (%)
  entryPrice: { type: Number, required: true },
  closePrice: { type: Number, default: null },
  expirySeconds: { type: Number, required: true },
  openedAt:   { type: Date, default: Date.now },
  expiresAt:  { type: Date, required: true },
  status: {
    type: String,
    enum: ['open', 'won', 'lost'],
    default: 'open',
    index: true,
  },
  profit: { type: Number, default: 0 }, // earned profit (0 if lost)
}, {
  timestamps: true,
});

tradeSchema.index({ user: 1, status: 1, openedAt: -1 });
tradeSchema.index({ user: 1, openedAt: -1 });
// Auto-expire settled trades from this collection after 30 days
tradeSchema.index({ openedAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 30 });

export default mongoose.model('Trade', tradeSchema);
