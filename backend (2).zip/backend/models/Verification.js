import mongoose from 'mongoose';

const verificationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
  },
  // Legacy field (keep for backward compatibility)
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  name: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  nidNumber: {
    type: String,
    required: true,
  },
  dateOfBirth: {
    type: Date,
    required: true,
  },
  // Legacy field (keep for backward compatibility)
  dob: {
    type: String,
  },
  address: {
    type: String,
    required: true,
  },
  withdrawPassword: {
    type: String,
    required: true,
  },
  nidFrontImage: {
    type: String,
    required: false, // Not required to allow deletion after processing
  },
  nidBackImage: {
    type: String,
    required: false, // Not required to allow deletion after processing
  },
  selfieImage: {
    type: String,
    required: false, // Make it optional for backward compatibility
  },
  // Legacy fields (keep for backward compatibility)
  nidFront: {
    type: String,
  },
  nidBack: {
    type: String,
  },
  selfie: {
    type: String,
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  rejectionReason: {
    type: String,
    default: null,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  processedAt: {
    type: Date,
    default: null,
  },
}, {
  timestamps: true
});

// Sync fields
verificationSchema.pre('save', function(next) {
  if (this.user && !this.userId) {
    this.userId = this.user;
  }
  if (this.userId && !this.user) {
    this.user = this.userId;
  }
  if (this.nidFrontImage && !this.nidFront) {
    this.nidFront = this.nidFrontImage;
  }
  if (this.nidFront && !this.nidFrontImage) {
    this.nidFrontImage = this.nidFront;
  }
  if (this.nidBackImage && !this.nidBack) {
    this.nidBack = this.nidBackImage;
  }
  if (this.nidBack && !this.nidBackImage) {
    this.nidBackImage = this.nidBack;
  }
  if (this.selfieImage && !this.selfie) {
    this.selfie = this.selfieImage;
  }
  if (this.selfie && !this.selfieImage) {
    this.selfieImage = this.selfie;
  }
  if (this.dateOfBirth && !this.dob) {
    this.dob = this.dateOfBirth.toISOString();
  }
  if (this.dob && !this.dateOfBirth) {
    this.dateOfBirth = new Date(this.dob);
  }
  next();
});

export default mongoose.model('Verification', verificationSchema);
