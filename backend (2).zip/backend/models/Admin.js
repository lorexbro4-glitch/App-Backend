import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const adminSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
  },
  password: {
    type: String,
    required: true,
  },
  pushTokens: [{
    token: {
      type: String,
      required: true,
    },
    registeredAt: {
      type: Date,
      default: Date.now,
    },
  }],
  isActive: {
    type: Boolean,
    default: true,
  },
  lastLoginAt: {
    type: Date,
    default: null,
  },
}, {
  timestamps: true
});

// Indexes for efficient queries
// Note: username already has unique: true in schema, so no need to add index again
adminSchema.index({ 'pushTokens.token': 1 });

// Hash password before saving
adminSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Compare password method for authentication
adminSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Add or update push token in array
adminSchema.methods.addPushToken = async function(token) {
  // Check if token already exists
  const existingTokenIndex = this.pushTokens.findIndex(pt => pt.token === token);
  
  if (existingTokenIndex !== -1) {
    // Update existing token's registeredAt timestamp
    this.pushTokens[existingTokenIndex].registeredAt = new Date();
  } else {
    // Add new token
    this.pushTokens.push({
      token: token,
      registeredAt: new Date(),
    });
  }
  
  return await this.save();
};

// Remove invalid push token from array
adminSchema.methods.removePushToken = async function(token) {
  this.pushTokens = this.pushTokens.filter(pt => pt.token !== token);
  return await this.save();
};

export default mongoose.model('Admin', adminSchema);
