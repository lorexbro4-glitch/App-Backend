import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  // Legacy field (keep for backward compatibility)
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  type: {
    type: String,
    required: true,
    enum: [
      'deposit',
      'deposit_request',
      'deposit_approved',
      'deposit_rejected',
      'withdrawal',
      'withdraw_request',
      'withdraw_approved',
      'withdraw_rejected',
      'profit_added',
      'referral_bonus',
      'gift',
    ],
  },
  amount: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed'],
    default: 'completed',
  },
  description: {
    type: String,
    default: '',
  },
  // Legacy field (keep for backward compatibility)
  note: {
    type: String,
    default: '',
  },
  date: {
    type: Date,
    default: Date.now,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  // Transaction linking fields
  requestId: {
    type: mongoose.Schema.Types.ObjectId,
    refPath: 'requestType',
  },
  requestType: {
    type: String,
    enum: ['Deposit', 'Withdraw'],
  },
  relatedTransactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
  },
  displayStatus: {
    type: String,
    default: '',
  },
}, {
  timestamps: true
});

// Sync fields
transactionSchema.pre('save', function(next) {
  if (this.user && !this.userId) {
    this.userId = this.user;
  }
  if (this.userId && !this.user) {
    this.user = this.userId;
  }
  if (this.description && !this.note) {
    this.note = this.description;
  }
  if (this.note && !this.description) {
    this.description = this.note;
  }
  next();
});

// Indexes
transactionSchema.index({ user: 1, createdAt: -1 });
transactionSchema.index({ requestId: 1 });
transactionSchema.index({ relatedTransactionId: 1 });

export default mongoose.model('Transaction', transactionSchema);
