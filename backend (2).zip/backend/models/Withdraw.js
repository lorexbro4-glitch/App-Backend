import mongoose from 'mongoose';

const withdrawSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  // Legacy field (keep for backward compatibility)
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  amount: {
    type: Number,
    required: true,
  },
  type: {
    type: String,
    enum: ['profit', 'capital'],
    required: true,
  },
  method: {
    type: String,
    required: true,
    enum: ['Bkash', 'Nagad', 'Rocket'],
  },
  accountNumber: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  rejectionReason: {
    type: String,
    default: null,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  processedAt: {
    type: Date,
    default: null,
  },
  // Idempotency
  idempotencyKey: {
    type: String,
    unique: true,
    sparse: true,
  },
  // Transaction linking
  submissionTransactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
  },
  actionTransactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
  },
}, {
  timestamps: true
});

// Sync userId with user field
withdrawSchema.pre('save', function(next) {
  // Normalize payment method values to match enum
  if (this.method) {
    const methodLower = this.method.toLowerCase();
    if (methodLower === 'bkash') this.method = 'Bkash';
    else if (methodLower === 'nagad') this.method = 'Nagad';
    else if (methodLower === 'rocket') this.method = 'Rocket';
  }
  
  if (this.user && !this.userId) {
    this.userId = this.user;
  }
  if (this.userId && !this.user) {
    this.user = this.userId;
  }
  next();
});

// Indexes
withdrawSchema.index({ user: 1, status: 1 });

// Additional indexes for Phase 1 improvements
withdrawSchema.index({ user: 1, status: 1, createdAt: -1 });
withdrawSchema.index({ status: 1, createdAt: -1 });

export default mongoose.model('Withdraw', withdrawSchema);
