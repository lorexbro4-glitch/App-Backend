import mongoose from 'mongoose';

/**
 * Candle — stores OHLCV data per asset per 5-second bucket.
 * TTL: keep 24 hours so candles survive server restarts.
 * Frontend always requests last 60 candles (= last 5 minutes at 5s/candle).
 */
const candleSchema = new mongoose.Schema({
  assetId: {
    type: String,
    required: true,
    index: true,
  },
  // Bucket start timestamp (floored to 5-second boundary)
  openTime: {
    type: Date,
    required: true,
  },
  open:   { type: Number, required: true },
  high:   { type: Number, required: true },
  low:    { type: Number, required: true },
  close:  { type: Number, required: true },
  volume: { type: Number, default: 0 },
  isLive: { type: Boolean, default: false },
}, {
  timestamps: false,
});

// Compound unique index: one candle per asset per 5s bucket
candleSchema.index({ assetId: 1, openTime: -1 }, { unique: true });

// Keep candles for 24 hours so server restarts don't wipe history
// MongoDB TTL runs every ~60s so this is approximate
candleSchema.index({ openTime: 1 }, { expireAfterSeconds: 86400 });

export default mongoose.model('Candle', candleSchema);
