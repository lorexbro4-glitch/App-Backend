import mongoose from 'mongoose';

const appDistributionSchema = new mongoose.Schema({
  appName: {
    type: String,
    required: true,
    enum: ['InvestmentApp', 'AgentApp', 'AdminMobileApp']
  },
  version: {
    type: String,
    required: true
  },
  fileSize: {
    type: Number,
    required: true // in bytes
  },
  fileName: {
    type: String,
    required: true
  },
  filePath: {
    type: String,
    required: true
  },
  uploadedBy: {
    type: String,
    required: true
  },
  uploadedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for efficient queries
appDistributionSchema.index({ appName: 1, uploadedAt: -1 });

export default mongoose.model('AppDistribution', appDistributionSchema);
