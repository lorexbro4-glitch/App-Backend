import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  type: {
    type: String,
    enum: [
      'registration',
      'login',
      'deposit_submitted',
      'deposit_approved',
      'deposit_rejected',
      'withdrawal_submitted',
      'withdrawal_approved',
      'withdrawal_processed',
      'withdrawal_rejected',
      'referral_bonus',
      'referral_success',
      'kyc_submitted',
      'kyc_approved',
      'kyc_rejected',
      'system_announcement',
      'gift'
    ],
    required: true,
    index: true,
  },
  title: {
    type: String,
    required: true,
    maxlength: 100,
  },
  message: {
    type: String,
    required: true,
    maxlength: 500,
  },
  read: {
    type: Boolean,
    default: false,
    index: true,
  },
  // Push notification delivery tracking
  pushSent: {
    type: Boolean,
    default: false,
  },
  pushReceipt: {
    type: String,
    default: null,
  },
  pushError: {
    type: String,
    default: null,
  },
  pushSentAt: {
    type: Date,
    default: null,
  },
  metadata: {
    amount: {
      type: Number,
    },
    transactionId: {
      type: String,
    },
    referralName: {
      type: String,
    },
    reason: {
      type: String,
    },
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true,
  },
}, {
  timestamps: true
});

// Compound indexes for efficient queries
notificationSchema.index({ userId: 1, createdAt: -1 });
notificationSchema.index({ userId: 1, read: 1 });

// TTL index to auto-delete old notifications after 90 days (7776000 seconds)
notificationSchema.index({ createdAt: 1 }, { expireAfterSeconds: 7776000 });

export default mongoose.model('Notification', notificationSchema);
