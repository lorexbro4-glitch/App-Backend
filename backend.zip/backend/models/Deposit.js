import mongoose from 'mongoose';

const depositSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  // Legacy field (keep for backward compatibility)
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  amount: {
    type: Number,
    required: true,
  },
  method: {
    type: String,
    required: true,
    enum: ['Bkash', 'Nagad', 'Rocket'],
  },
  // Legacy field (keep for backward compatibility)
  paymentMethod: {
    type: String,
    enum: ['Bkash', 'Nagad', 'Rocket'],
  },
  transactionId: {
    type: String,
    required: true,
  },
  senderNumber: {
    type: String,
    required: true,
  },
  // Legacy field (keep for backward compatibility)
  phoneNumber: {
    type: String,
  },
  screenshot: {
    type: String,
    default: null,
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  rejectionReason: {
    type: String,
    default: null,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  processedAt: {
    type: Date,
    default: null,
  },
  // Idempotency
  idempotencyKey: {
    type: String,
    unique: true,
    sparse: true,
  },
  // Transaction linking
  submissionTransactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
  },
  actionTransactionId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Transaction',
  },
}, {
  timestamps: true
});

// Sync userId with user field
depositSchema.pre('save', function(next) {
  // Normalize payment method values to match enum
  if (this.method) {
    const methodLower = this.method.toLowerCase();
    if (methodLower === 'bkash') this.method = 'Bkash';
    else if (methodLower === 'nagad') this.method = 'Nagad';
    else if (methodLower === 'rocket') this.method = 'Rocket';
  }
  if (this.paymentMethod) {
    const paymentMethodLower = this.paymentMethod.toLowerCase();
    if (paymentMethodLower === 'bkash') this.paymentMethod = 'Bkash';
    else if (paymentMethodLower === 'nagad') this.paymentMethod = 'Nagad';
    else if (paymentMethodLower === 'rocket') this.paymentMethod = 'Rocket';
  }
  
  if (this.user && !this.userId) {
    this.userId = this.user;
  }
  if (this.userId && !this.user) {
    this.user = this.userId;
  }
  if (this.method && !this.paymentMethod) {
    this.paymentMethod = this.method;
  }
  if (this.paymentMethod && !this.method) {
    this.method = this.paymentMethod;
  }
  if (this.senderNumber && !this.phoneNumber) {
    this.phoneNumber = this.senderNumber;
  }
  if (this.phoneNumber && !this.senderNumber) {
    this.senderNumber = this.phoneNumber;
  }
  next();
});

// Indexes
depositSchema.index({ user: 1, status: 1 });

// Additional indexes for Phase 1 improvements
depositSchema.index({ user: 1, status: 1, createdAt: -1 });
depositSchema.index({ status: 1, createdAt: -1 });

export default mongoose.model('Deposit', depositSchema);
