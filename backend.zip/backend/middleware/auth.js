import jwt from 'jsonwebtoken';
import Agent from '../models/Agent.js';
import User from '../models/User.js';

const JWT_SECRET = process.env.JWT_SECRET || 'your_secret_key';

export default async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({message: 'টোকেন নেই'});
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;

    // ── Ban check for regular users ───────────────────────────────────────────
    if (!decoded.role || decoded.role === 'user') {
      const user = await User.findById(decoded.userId).select('banned isActive').lean();
      if (!user) {
        return res.status(401).json({ message: 'ব্যবহারকারী পাওয়া যায়নি' });
      }
      if (user.banned || !user.isActive) {
        return res.status(403).json({ message: 'account_banned', banned: true });
      }
    }

    // If this is an agent route, verify approval status
    if (decoded.role === 'agent') {
      const agent = await Agent.findById(decoded.userId);
      
      if (!agent) {
        return res.status(404).json({message: 'এজেন্ট পাওয়া যায়নি'});
      }

      if (agent.approvalStatus !== 'approved') {
        return res.status(403).json({
          message: 'আপনার অ্যাকাউন্ট এখনও অনুমোদিত নয়',
          approvalStatus: agent.approvalStatus
        });
      }

      if (!agent.isActive) {
        return res.status(403).json({
          message: 'আপনার অ্যাকাউন্ট নিষ্ক্রিয়',
          approvalStatus: agent.approvalStatus
        });
      }
    }

    next();
  } catch (error) {
    return res.status(401).json({message: 'অবৈধ টোকেন'});
  }
};
