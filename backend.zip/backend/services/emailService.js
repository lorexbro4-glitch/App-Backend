﻿import nodemailer from 'nodemailer';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER, // Your Gmail
    pass: process.env.EMAIL_PASS // App password
  }
});

// Generate 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send verification email with OTP (existing functionality)
const sendVerificationEmail = async (email, otp, name) => {
  console.log(`📧 [sendVerificationEmail] Preparing email for: ${email}`);
  console.log(`📧 [sendVerificationEmail] OTP: ${otp}`);
  console.log(`📧 [sendVerificationEmail] Name: ${name}`);
  
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'ইমেইল যাচাই করুন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <h2 style="color: #1e293b;">স্বাগতম ${name || 'প্রিয় ব্যবহারকারী'}!</h2>
        <p style="color: #475569; line-height: 1.6;">YFBD তে রেজিস্ট্রেশনের জন্য আপনাকে ধন্যবাদ। আপনার ইমেইল যাচাই করতে নিচের কোডটি ব্যবহার করুন:</p>
        
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center; margin: 30px 0; border-radius: 12px;">
          <p style="color: #e0e7ff; margin: 0 0 10px 0; font-size: 14px;">আপনার যাচাইকরণ কোড</p>
          <h1 style="color: #ffffff; letter-spacing: 8px; margin: 0; font-size: 36px;">${otp}</h1>
        </div>
        
        <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="color: #64748b; margin: 0; font-size: 14px;">⏰ এই কোডটি <strong>১০ মিনিটের</strong> জন্য বৈধ থাকবে।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনি যদি এই অ্যাকাউন্ট তৈরি না করে থাকেন, তাহলে দয়া করে এই ইমেইলটি উপেক্ষা করুন।</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    console.log(`📧 [sendVerificationEmail] Sending email via nodemailer...`);
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ [sendVerificationEmail] Email sent successfully!`);
    console.log(`✅ [sendVerificationEmail] Message ID: ${info.messageId}`);
    console.log(`✅ [sendVerificationEmail] Response: ${info.response}`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ [sendVerificationEmail] Email send error:', error);
    console.error('❌ [sendVerificationEmail] Error details:', error.message);
    return { success: false, error: error.message };
  }
};

// Send verification email with token link (new functionality for email-based auth)
const sendVerificationEmailWithToken = async (email, token) => {
  const verificationUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-email/${token}`;
  
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'ইমেইল যাচাই করুন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <h2 style="color: #1e293b;">স্বাগতম!</h2>
        <p style="color: #475569; line-height: 1.6;">YFBD তে রেজিস্ট্রেশনের জন্য আপনাকে ধন্যবাদ। আপনার ইমেইল যাচাই করতে নিচের বাটনে ক্লিক করুন:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verificationUrl}" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold; font-size: 16px;">ইমেইল যাচাই করুন</a>
        </div>
        
        <p style="color: #64748b; font-size: 14px;">অথবা এই লিংকটি আপনার ব্রাউজারে কপি করুন:</p>
        <p style="background: #f1f5f9; padding: 12px; word-break: break-all; font-size: 12px; border-radius: 6px; color: #475569;">${verificationUrl}</p>
        
        <div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
          <p style="color: #92400e; margin: 0; font-size: 14px;">⏰ এই লিংকটি <strong>২৪ ঘন্টার</strong> জন্য বৈধ থাকবে।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনি যদি এই অ্যাকাউন্ট তৈরি না করে থাকেন, তাহলে দয়া করে এই ইমেইলটি উপেক্ষা করুন।</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send password reset email with OTP (existing functionality)
const sendPasswordResetEmail = async (email, otp, name) => {
  console.log(`📧 [sendPasswordResetEmail] Preparing email for: ${email}`);
  console.log(`📧 [sendPasswordResetEmail] OTP: ${otp}`);
  console.log(`📧 [sendPasswordResetEmail] Name: ${name}`);
  
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'পাসওয়ার্ড রিসেট করুন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <h2 style="color: #1e293b;">পাসওয়ার্ড রিসেট অনুরোধ</h2>
        <p style="color: #475569; line-height: 1.6;">হ্যালো ${name || 'প্রিয় ব্যবহারকারী'},</p>
        <p style="color: #475569; line-height: 1.6;">আমরা আপনার পাসওয়ার্ড রিসেট করার অনুরোধ পেয়েছি। আপনার পাসওয়ার্ড রিসেট করতে নিচের কোডটি ব্যবহার করুন:</p>
        
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center; margin: 30px 0; border-radius: 12px;">
          <p style="color: #e0e7ff; margin: 0 0 10px 0; font-size: 14px;">আপনার রিসেট কোড</p>
          <h1 style="color: #ffffff; letter-spacing: 8px; margin: 0; font-size: 36px;">${otp}</h1>
        </div>
        
        <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="color: #64748b; margin: 0; font-size: 14px;">⏰ এই কোডটি <strong>১০ মিনিটের</strong> জন্য বৈধ থাকবে।</p>
        </div>
        
        <div style="background: #fef2f2; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ef4444;">
          <p style="color: #991b1b; margin: 0; font-size: 14px;">🔒 আপনি যদি পাসওয়ার্ড রিসেট অনুরোধ না করে থাকেন, তাহলে দয়া করে এই ইমেইলটি উপেক্ষা করুন এবং আপনার অ্যাকাউন্ট নিরাপদ থাকবে।</p>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    console.log(`📧 [sendPasswordResetEmail] Sending email via nodemailer...`);
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ [sendPasswordResetEmail] Email sent successfully!`);
    console.log(`✅ [sendPasswordResetEmail] Message ID: ${info.messageId}`);
    console.log(`✅ [sendPasswordResetEmail] Response: ${info.response}`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ [sendPasswordResetEmail] Email send error:', error);
    console.error('❌ [sendPasswordResetEmail] Error details:', error.message);
    return { success: false, error: error.message };
  }
};

// Send password reset email with token link (new functionality for email-based auth)
const sendPasswordResetEmailWithToken = async (email, token) => {
  const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password/${token}`;
  
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'পাসওয়ার্ড রিসেট করুন - YFBD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <h2 style="color: #1e293b;">পাসওয়ার্ড রিসেট অনুরোধ</h2>
        <p style="color: #475569; line-height: 1.6;">আমরা আপনার পাসওয়ার্ড রিসেট করার অনুরোধ পেয়েছি। আপনার পাসওয়ার্ড রিসেট করতে নিচের বাটনে ক্লিক করুন:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold; font-size: 16px;">পাসওয়ার্ড রিসেট করুন</a>
        </div>
        
        <p style="color: #64748b; font-size: 14px;">অথবা এই লিংকটি আপনার ব্রাউজারে কপি করুন:</p>
        <p style="background: #f1f5f9; padding: 12px; word-break: break-all; font-size: 12px; border-radius: 6px; color: #475569;">${resetUrl}</p>
        
        <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="color: #64748b; margin: 0; font-size: 14px;">⏰ এই লিংকটি <strong>১ ঘন্টার</strong> জন্য বৈধ থাকবে।</p>
        </div>
        
        <div style="background: #fef2f2; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ef4444;">
          <p style="color: #991b1b; margin: 0; font-size: 14px;">🔒 আপনি যদি পাসওয়ার্ড রিসেট অনুরোধ না করে থাকেন, তাহলে দয়া করে এই ইমেইলটি উপেক্ষা করুন এবং আপনার অ্যাকাউন্ট নিরাপদ থাকবে।</p>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send welcome email
const sendWelcomeEmail = async (email, name) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'YFBD তে স্বাগতম! 🎉',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">🎉 স্বাগতম ${name}!</h2>
          <p style="color: #e0e7ff; margin: 0; font-size: 16px;">আপনার ইমেইল সফলভাবে যাচাই করা হয়েছে</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">আপনার YFBD পরিবারে যোগদানের জন্য আমরা অত্যন্ত আনন্দিত! এখন আপনি আমাদের সাথে বিনিয়োগ শুরু করতে এবং আপনার আর্থিক লক্ষ্য অর্জন করতে পারবেন।</p>
        
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #10b981;">
          <h3 style="color: #065f46; margin: 0 0 10px 0;">💰 এখনই শুরু করুন!</h3>
          <p style="color:#047857; margin: 0; line-height: 1.6;">আপনার প্রথম ডিপোজিট করুন এবং মাসিক সর্বোচ্চ <strong>১৬% লাভ</strong> অর্জন শুরু করুন</p>
        </div>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 25px 0;">
          <h3 style="color: #1e293b; margin: 0 0 15px 0;">📱 পরবর্তী পদক্ষেপ:</h3>
          <ul style="color: #475569; line-height: 1.8; margin: 0; padding-left: 20px;">
            <li>আপনার প্রোফাইল সম্পূর্ণ করুন</li>
            <li>আপনার প্রথম ডিপোজিট করুন</li>
            <li>বিনিয়োগ শুরু করুন এবং লাভ অর্জন করুন</li>
            <li>রেফারেল করে অতিরিক্ত আয় করুন</li>
          </ul>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💬 সাহায্য প্রয়োজন?</h3>
          <p style="color: #1e40af; margin: 0; line-height: 1.6;">আপনার কোন প্রশ্ন থাকলে, আমাদের সাপোর্ট টিম সবসময় আপনাকে সাহায্য করতে প্রস্তুত। অ্যাপের মধ্যে সাপোর্ট চ্যাট ব্যবহার করুন।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6; text-align: center; margin: 30px 0;">আপনার সাথে থাকার জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Send welcome email for agents
const sendAgentWelcomeEmail = async (email, name) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'YFBD এজেন্ট টিমে স্বাগতম! 🎉',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #3b82f6; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">এজেন্ট পোর্টাল</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center; border-radius: 12px; margin-bottom: 30px;">
          <h2 style="color: #ffffff; margin: 0 0 10px 0;">🎉 স্বাগতম ${name}!</h2>
          <p style="color: #d1fae5; margin: 0; font-size: 16px;">আপনি এখন YFBD এজেন্ট টিমের সদস্য</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6;">YFBD এজেন্ট টিমে যোগদানের জন্য আপনাকে ধন্যবাদ! আপনার ইমেইল সফলভাবে যাচাই করা হয়েছে এবং এখন আপনি ইউজারদের সাহায্য করতে পারবেন।</p>
        
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #10b981;">
          <h3 style="color: #065f46; margin: 0 0 10px 0;">👨‍💼 আপনার দায়িত্ব:</h3>
          <ul style="color: #047857; line-height: 1.8; margin: 10px 0 0 0; padding-left: 20px;">
            <li>ইউজারদের প্রশ্নের উত্তর দিন</li>
            <li>সমস্যা সমাধানে সাহায্য করুন</li>
            <li>দ্রুত এবং বিনয়ের সাথে সেবা প্রদান করুন</li>
            <li>টিকেট স্ট্যাটাস আপডেট করুন</li>
          </ul>
        </div>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 25px 0;">
          <h3 style="color: #1e293b; margin: 0 0 15px 0;">📱 এজেন্ট অ্যাপ ব্যবহার করুন:</h3>
          <ul style="color: #475569; line-height: 1.8; margin: 0; padding-left: 20px;">
            <li>ইউজার টিকেট দেখুন এবং উত্তর দিন</li>
            <li>চ্যাট করুন এবং সমস্যা সমাধান করুন</li>
            <li>টিকেট স্ট্যাটাস এবং প্রায়োরিটি আপডেট করুন</li>
            <li>ইউজার প্রোফাইল দেখুন</li>
            <li>রিপোর্ট তৈরি করুন</li>
          </ul>
        </div>
        
        <div style="background: #eff6ff; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #3b82f6;">
          <h3 style="color: #1e40af; margin: 0 0 10px 0;">💡 টিপস:</h3>
          <p style="color: #1e40af; margin: 0; line-height: 1.6;">সবসময় বিনয়ী এবং সহায়ক থাকুন। দ্রুত উত্তর দিন এবং ইউজারদের সমস্যা বুঝতে চেষ্টা করুন। আপনার সেবা YFBD এর সুনাম বৃদ্ধি করবে।</p>
        </div>
        
        <p style="color: #475569; line-height: 1.6; text-align: center; margin: 30px 0;">আমাদের টিমে যোগদানের জন্য ধন্যবাদ! 🙏</p>
        
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD - এজেন্ট পোর্টাল</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// ─── Broadcast Email (admin → all users) ──────────────────────────────────────
const sendBroadcastEmail = async (email, name, title, body) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: `📢 ${title} - YFBD`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #6366f1; margin: 0;">YFBD</h1>
          <p style="color: #64748b; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ সঙ্গী</p>
        </div>

        <div style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); padding: 30px; text-align: center; border-radius: 14px; margin-bottom: 30px;">
          <p style="color: rgba(255,255,255,0.85); margin: 0 0 8px 0; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">📢 অফিসিয়াল বার্তা</p>
          <h2 style="color: #ffffff; margin: 0; font-size: 22px;">${title}</h2>
        </div>

        <p style="color: #475569; line-height: 1.6;">প্রিয় ${name || 'ব্যবহারকারী'},</p>

        <div style="background: #f8fafc; border-left: 4px solid #6366f1; padding: 20px; border-radius: 0 10px 10px 0; margin: 20px 0;">
          <p style="color: #1e293b; line-height: 1.8; margin: 0; font-size: 15px;">${body}</p>
        </div>

        <p style="color: #475569; line-height: 1.6;">ধন্যবাদ,<br><strong>YFBD টিম</strong></p>

        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
        <div style="text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 5px 0;">YFBD</p>
          <p style="color: #cbd5e1; font-size: 11px; margin: 5px 0;">আপনার বিশ্বস্ত বিনিয়োগ প্ল্যাটফর্ম</p>
        </div>
      </div>
    `,
  };
  try {
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Broadcast email error:', error);
    return { success: false, error: error.message };
  }
};

export {
  generateOTP,
  sendVerificationEmail,
  sendVerificationEmailWithToken,
  sendPasswordResetEmail,
  sendPasswordResetEmailWithToken,
  sendWelcomeEmail,
  sendAgentWelcomeEmail,
  sendBroadcastEmail,
};
