import express from 'express';
const router = express.Router();
import Deposit from '../models/Deposit.js';
import auth from '../middleware/auth.js';
import { validate, schemas } from '../middleware/validation.js';
import { createDepositSubmissionNotification, notifyAdminNewDeposit } from '../services/notificationService.js';
import { idempotencyMiddleware, updateIdempotencyCache } from '../middleware/idempotency.js';
import requestValidationService from '../services/requestValidationService.js';
import transactionHistoryService from '../services/transactionHistoryService.js';
import pushNotificationService from '../services/pushNotificationService.js';
import { notifyDepositRequest } from '../services/telegramNotificationService.js';
import { notifyAdminDepositRequest } from '../services/adminEmailNotificationService.js';
import { sendDepositSubmissionEmail } from '../services/requestEmailService.js';
import BENGALI_TEXT from '../constants/bengaliText.js';
import logger from '../config/logger.js';

// Create Deposit
router.post('/', auth, validate(schemas.deposit), idempotencyMiddleware({ model: 'Deposit' }), async (req, res, next) => {
  try {
    const {amount, paymentMethod, method, transactionId, phoneNumber, senderNumber, screenshot} = req.body;

    const finalMethod = method || paymentMethod;
    const finalSenderNumber = senderNumber || phoneNumber;

    // Detailed validation with specific error messages
    if (!amount) {
      return res.status(400).json({message: 'পরিমাণ লিখুন'});
    }
    
    // Validate amount is a positive number
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({message: 'সঠিক পরিমাণ লিখুন'});
    }
    
    // Validate minimum and maximum amount
    if (parsedAmount < 500) {
      return res.status(400).json({message: 'ন্যূনতম ৫০০ টাকা ডিপোজিট করুন'});
    }
    if (parsedAmount > 50000) {
      return res.status(400).json({message: 'একবারে সর্বোচ্চ ৫০,০০০ টাকা ডিপোজিট করতে পারবেন'});
    }
    
    if (!finalMethod) {
      return res.status(400).json({message: 'পেমেন্ট মেথড নির্বাচন করুন (Bkash অথবা Nagad)'});
    }
    if (!transactionId || transactionId.trim() === '') {
      return res.status(400).json({message: 'ট্রানজেকশন আইডি লিখুন'});
    }
    if (!finalSenderNumber || finalSenderNumber.trim() === '') {
      return res.status(400).json({message: 'ফোন নম্বর লিখুন'});
    }
    
    // Validate phone number format (11 digits starting with 01)
    const cleanedPhone = finalSenderNumber.replace(/\s+/g, '').replace(/-/g, '');
    const phoneRegex = /^01[0-9]{9}$/;
    if (!phoneRegex.test(cleanedPhone)) {
      return res.status(400).json({message: 'সঠিক ফোন নম্বর লিখুন (০১ দিয়ে শুরু, ১১ ডিজিট)'});
    }

    // Check email verification (for email-registered users)
    const User = (await import('../models/User.js')).default;
    const user = await User.findById(req.userId);
    if (!user) {
      console.error('User not found during deposit submission:', {
        userId: req.userId,
        token: req.headers.authorization?.substring(0, 50)
      });
      return res.status(404).json({message: 'ইউজার পাওয়া যায়নি। আবার লগইন করুন'});
    }

    // If user has email and it's not verified, block deposit
    if (user.email && !user.emailVerified) {
      return res.status(403).json({
        message: 'ডিপোজিট করার আগে আপনার ইমেইল ভেরিফাই করুন',
        requiresEmailVerification: true
      });
    }

    // Check for pending deposit request
    const hasPending = await requestValidationService.hasPendingDeposit(req.userId);
    if (hasPending) {
      return res.status(400).json({
        message: BENGALI_TEXT.PENDING_DEPOSIT_EXISTS,
        hasPendingRequest: true,
      });
    }

    const deposit = new Deposit({
      user: req.userId,
      userId: req.userId,
      amount: parsedAmount,
      method: finalMethod,
      paymentMethod: finalMethod,
      transactionId: transactionId.trim(),
      senderNumber: cleanedPhone,
      phoneNumber: cleanedPhone,
      screenshot,
      idempotencyKey: req.idempotencyKey,
    });

    await deposit.save();

    // Update idempotency cache
    if (req.idempotencyKey) {
      updateIdempotencyCache(req.idempotencyKey, deposit._id.toString());
    }

    // Create submission transaction
    const submissionTransaction = await transactionHistoryService.createRequestTransaction(
      req.userId,
      'deposit',
      parsedAmount,
      deposit._id
    );

    // Link transaction to deposit
    deposit.submissionTransactionId = submissionTransaction._id;
    await deposit.save();

    // Update user's pending deposit flag
    await requestValidationService.updatePendingFlag(req.userId, 'deposit', true);

    // Send deposit submission notification
    try {
      await createDepositSubmissionNotification(req.userId, parsedAmount);
      // Notify admin about new deposit request
      await notifyAdminNewDeposit(user.name || user.phone, parsedAmount, finalMethod);
      
      // Send Telegram notification to admin
      await notifyDepositRequest({
        amount: parsedAmount,
        method: finalMethod,
        userName: user.name,
        userPhone: user.phone,
        createdAt: deposit.createdAt,
      });
      
      // Send Email notification to admin
      await notifyAdminDepositRequest({
        amount: parsedAmount,
        method: finalMethod,
        userName: user.name,
        userPhone: user.phone,
        createdAt: deposit.createdAt,
      });
      
      // Send submission confirmation email to user
      if (user.email) {
        await sendDepositSubmissionEmail(user.email, user.name, parsedAmount, finalMethod);
        logger.info('Deposit submission email sent to user');
      }
    } catch (notifError) {
      logger.error('Failed to send deposit notification:', notifError);
      // Don't fail the deposit if notification fails
    }

    // Send push notification to all admin devices
    try {
      const adminNotificationResult = await pushNotificationService.sendToAdmins({
        title: 'নতুন ডিপোজিট রিকোয়েস্ট',
        body: `${user.name || user.phone} - ৳${parsedAmount} (${finalMethod})`,
        data: {
          type: 'deposit_request',
          userId: user._id.toString(),
          depositId: deposit._id.toString(),
          amount: parsedAmount,
        },
      });
      logger.info('Admin push notification sent for new deposit:', {
        depositId: deposit._id.toString(),
        sent: adminNotificationResult.sent,
        failed: adminNotificationResult.failed,
      });
    } catch (adminNotifError) {
      logger.error('Failed to send admin push notification for deposit:', adminNotifError);
      // Don't fail the deposit submission if admin notification fails
    }

    res.status(201).json({
      message: BENGALI_TEXT.DEPOSIT_SUBMITTED,
      deposit,
    });
  } catch (error) {
    logger.error('Deposit error:', error);
    // Return user-friendly error message
    if (error.name === 'ValidationError') {
      return res.status(400).json({message: 'সঠিক তথ্য দিন'});
    }
    if (error.code === 11000) {
      const field = error.keyPattern?.transactionId ? 'transactionId' : Object.keys(error.keyPattern || {})[0];
      if (field === 'transactionId') {
        return res.status(400).json({message: 'এই ট্রানজেকশন আইডি আগে ব্যবহার করা হয়েছে। সঠিক ট্রানজেকশন আইডি দিন।'});
      }
      return res.status(400).json({message: 'ডুপ্লিকেট তথ্য পাওয়া গেছে। আবার চেষ্টা করুন।'});
    }
    res.status(500).json({message: 'ডিপোজিট সাবমিট করতে সমস্যা হয়েছে। আবার চেষ্টা করুন'});
  }
});

// Get Deposit History
router.get('/history', auth, async (req, res, next) => {
  try {
    const deposits = await Deposit.find({
      $or: [{ userId: req.userId }, { user: req.userId }]
    })
      .sort({createdAt: -1})
      .limit(20);

    res.json({deposits});
  } catch (error) {
    logger.error('Get deposit history error:', error);
    next(error);
  }
});

export default router;
