﻿import express from 'express';
const router = express.Router();
import User from '../models/User.js';
import Admin from '../models/Admin.js';
import Deposit from '../models/Deposit.js';
import Withdraw from '../models/Withdraw.js';
import Verification from '../models/Verification.js';
import Transaction from '../models/Transaction.js';
import jwt from 'jsonwebtoken';
import pushNotificationService from '../services/pushNotificationService.js';
import transactionHistoryService from '../services/transactionHistoryService.js';
import requestValidationService from '../services/requestValidationService.js';
import {
  createSystemAnnouncement
} from '../services/notificationService.js';
import Agent from '../models/Agent.js';
import Report from '../models/Report.js';
import {
  sendDepositApprovalEmail,
  sendDepositRejectionEmail,
  sendWithdrawalApprovalEmail,
  sendWithdrawalRejectionEmail,
  sendVerificationApprovalEmail,
  sendVerificationRejectionEmail,
  sendReferralBonusEmail,
  sendKYCBonusEmail,
} from '../services/requestEmailService.js';

// Admin authentication middleware
const adminAuth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    if (!decoded.isAdmin) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    req.admin = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Admin login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    // Find admin by username
    const admin = await Admin.findOne({ username: username.toLowerCase() });
    
    if (!admin) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Check if admin is active
    if (!admin.isActive) {
      return res.status(403).json({ message: 'Account is disabled' });
    }
    
    // Compare password
    const isPasswordValid = await admin.comparePassword(password);
    
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Update lastLoginAt timestamp
    admin.lastLoginAt = new Date();
    await admin.save();
    
    // Generate JWT token
    const token = jwt.sign(
      { username: admin.username, isAdmin: true },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );
    
    res.json({ token });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Dashboard stats
router.get('/dashboard', adminAuth, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isActive: true });
    
    const deposits = await Deposit.find();
    const totalDeposits = deposits.reduce((sum, d) => sum + (d.amount || 0), 0);
    const pendingDeposits = await Deposit.countDocuments({ status: 'pending' });
    
    const withdrawals = await Withdraw.find();
    const totalWithdrawals = withdrawals.reduce((sum, w) => sum + (w.amount || 0), 0);
    const pendingWithdrawals = await Withdraw.countDocuments({ status: 'pending' });
    
    const pendingVerifications = await Verification.countDocuments({ status: 'pending' });
    
    const users = await User.find();
    const totalProfit = users.reduce((sum, u) => sum + (u.totalProfit || 0), 0);

    // Chart data for last 7 days
    const chartData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      
      const dayDeposits = await Deposit.find({
        createdAt: { $gte: date, $lt: nextDate },
        status: 'approved'
      });
      
      const dayWithdrawals = await Withdraw.find({
        createdAt: { $gte: date, $lt: nextDate },
        status: 'approved'
      });
      
      chartData.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        deposits: dayDeposits.reduce((sum, d) => sum + d.amount, 0),
        withdrawals: dayWithdrawals.reduce((sum, w) => sum + w.amount, 0)
      });
    }

    res.json({
      stats: {
        totalUsers,
        activeUsers,
        totalDeposits,
        totalWithdrawals,
        pendingDeposits,
        pendingWithdrawals,
        pendingVerifications,
        totalProfit
      },
      chartData
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all users
router.get('/users', adminAuth, async (req, res) => {
  try {
    const { 
      page = 1, 
      pageSize = 20, 
      search = '',
      isVerified,
      isActive,
      sortBy = 'createdAt',
      sortOrder = 'desc'
    } = req.query;
    
    // Build query
    let query = {};
    
    // Search filter - use @ prefix for username-only search
    if (search) {
      const trimmedSearch = search.trim();
      
      // If search starts with @, search only by username (exact match)
      if (trimmedSearch.startsWith('@')) {
        const username = trimmedSearch.substring(1).toLowerCase(); // Remove @ and convert to lowercase
        query = { username: username };
      } else {
        // For other searches, use partial matching on all fields
        const searchConditions = [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
          { phone: { $regex: search, $options: 'i' } },
          { username: { $regex: search, $options: 'i' } }
        ];
        
        // If search looks like a MongoDB ObjectId (24 hex characters), search by _id
        if (/^[0-9a-fA-F]{24}$/.test(search)) {
          searchConditions.push({ _id: search });
        }
        
        query = { $or: searchConditions };
      }
    }
    
    // Verification filter
    if (isVerified !== undefined) {
      query.isVerified = isVerified === 'true';
    }
    
    // Active status filter
    if (isActive !== undefined) {
      query.isActive = isActive === 'true';
    }
    
    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
    
    // Manual pagination
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [users, totalCount] = await Promise.all([
      User.find(query)
        .select('name email phone username balance capital totalProfit isVerified isActive createdAt withdrawPassword referralCount referralIncome')
        .sort(sort)
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      User.countDocuments(query)
    ]);
    
    // Map _id to uid for frontend compatibility
    const data = users.map(user => ({
      ...user,
      uid: user._id.toString()
    }));
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update user
router.put('/users/:id', adminAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Store original values for audit log
    const originalUser = { ...user.toObject() };
    
    // Update user fields
    const allowedFields = [
      'name', 'phone', 'email', 'username', 'withdrawPassword',
      'balance', 'capital', 'totalProfit', 'depositTotal', 'profitTotal',
      'referralIncome', 'referralCount',
      'isActive', 'isVerified', 'emailVerified', 'banned',
      'joinDate', 'firstDepositDate', 'lastDepositDate', 'capitalLockUntil'
    ];
    
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        user[field] = req.body[field];
      }
    });
    
    await user.save();
    
    // Log audit trail
    const auditLogger = (await import('../services/auditLogger.js')).default;
    await auditLogger.logUserUpdate(
      req.admin.username,
      user._id.toString(),
      originalUser,
      user.toObject(),
      req
    );
    
    res.json({ message: 'User updated successfully', user });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Gift money to user
router.post('/users/:userId/gift', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { amount, idempotencyKey } = req.body;
    
    // Check idempotency if key provided
    if (idempotencyKey) {
      const existingTransaction = await Transaction.findOne({
        user: req.params.userId,
        type: 'gift',
        description: { $regex: idempotencyKey },
      });
      
      if (existingTransaction) {
        return res.status(409).json({
          message: 'অনুরোধটি ইতিমধ্যে প্রক্রিয়াধীন',
          transaction: existingTransaction,
        });
      }
    }
    
    const user = await User.findById(req.params.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.balance = (user.balance || 0) + amount;
    await user.save();

    // Create transaction record with idempotency key in description
    const description = idempotencyKey 
      ? `Gift from admin [${idempotencyKey}]`
      : 'Gift from admin';
      
    await Transaction.create({
      user: user._id,
      type: 'gift',
      amount,
      description,
      status: 'completed'
    });

    // Log audit trail
    await auditLogger.logUserGift(
      req.admin.username,
      req.admin.username,
      user._id,
      amount,
      req
    );

    // Send push notification
    try {
      await pushNotificationService.createAndSendNotification(
        user._id,
        'gift',
        'Gift Received',
        `You received a gift of ৳${amount} from admin`,
        { amount }
      );
    } catch (notifError) {
      console.error('Failed to send gift notification:', notifError);
    }

    res.json({ message: 'Gift sent successfully', user });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Toggle user status
router.patch('/users/:userId/status', adminAuth, async (req, res) => {
  try {
    const { isActive } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { isActive },
      { new: true }
    );
    res.json({ user });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update user data (admin can edit all fields)
router.put('/users/:userId', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const userId = req.params.userId;
    const updateData = req.body;

    // Get user before update for audit log
    const userBefore = await User.findById(userId).lean();
    
    if (!userBefore) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Remove fields that shouldn't be updated directly
    delete updateData._id;
    delete updateData.__v;
    delete updateData.password; // Login password should be updated separately
    delete updateData.createdAt;
    delete updateData.updatedAt;

    // Allow withdrawPassword to be updated (it's different from login password)

    const user = await User.findByIdAndUpdate(
      userId,
      updateData,
      { new: true, runValidators: true }
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Log audit trail with before/after state
    await auditLogger.logUserUpdate(
      req.admin.username,
      req.admin.username,
      userId,
      userBefore,
      user.toObject(),
      req
    );

    res.json({ message: 'User updated successfully', user });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get deposits
router.get('/deposits', adminAuth, async (req, res) => {
  try {
    const { 
      status, 
      page = 1, 
      pageSize = 20,
      search = '',
      method,
      startDate,
      endDate
    } = req.query;
    
    // Build query
    let query = {};
    
    // Status filter
    if (status) {
      query.status = status;
    }
    
    // Method filter
    if (method) {
      query.method = method;
    }
    
    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }
    
    // Search filter (by user name, email, or transaction ID)
    if (search) {
      // First find users matching search
      const users = await User.find({
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } }
        ]
      }).select('_id').lean();
      
      const userIds = users.map(u => u._id);
      
      query.$or = [
        { user: { $in: userIds } },
        { transactionId: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Manual pagination
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [data, totalCount] = await Promise.all([
      Deposit.find(query)
        .populate('user', 'name phone email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      Deposit.countDocuments(query)
    ]);
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get deposits error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve deposit
router.patch('/deposits/:depositId/approve', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const deposit = await Deposit.findById(req.params.depositId);
    if (!deposit) {
      return res.status(404).json({ message: 'Deposit not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (deposit.status !== 'pending') {
      return res.status(400).json({ 
        message: `Deposit already ${deposit.status}`,
        deposit 
      });
    }

    deposit.status = 'approved';
    deposit.processedAt = new Date();
    // Delete screenshot to save database space
    deposit.screenshot = null;
    await deposit.save();

    // Update user balance and capital
    const user = await User.findById(deposit.user);
    if (!user) {
      console.error('User not found for deposit approval:', deposit.user);
      return res.status(404).json({ message: 'User not found' });
    }
    
    user.balance = (user.balance || 0) + deposit.amount;
    user.capital = (user.capital || 0) + deposit.amount;
    user.depositTotal = (user.depositTotal || 0) + deposit.amount;
    
    // Set firstDepositDate if this is the first deposit
    if (!user.firstDepositDate) {
      user.firstDepositDate = new Date();
    }
    
    // Always update lastDepositDate and capital lock (for capital lock calculation)
    await requestValidationService.updateCapitalLock(deposit.user, new Date());
    
    // Clear pending deposit flag
    await requestValidationService.updatePendingFlag(deposit.user, 'deposit', false);
    
    await user.save();

    // Create action transaction linked to submission transaction
    const actionTransaction = await transactionHistoryService.createActionTransaction(
      deposit.user,
      'deposit',
      'approved',
      deposit.amount,
      deposit._id,
      deposit.submissionTransactionId,
      null
    );

    // Link action transaction back to deposit
    deposit.actionTransactionId = actionTransaction._id;
    await deposit.save();

    // Log audit trail
    await auditLogger.logDepositApprove(
      req.admin.username,
      req.admin.username,
      deposit._id,
      deposit.amount,
      req
    );

    // Create notification for deposit approval and send push notification
    try {
      console.log('📲 [DEPOSIT APPROVAL] Starting notification creation for user:', deposit.user);
      console.log('📲 [DEPOSIT APPROVAL] Notification details:', {
        userId: deposit.user,
        type: 'deposit_approved',
        amount: deposit.amount,
        transactionId: actionTransaction._id.toString()
      });
      
      const notificationResult = await pushNotificationService.createAndSendNotification(
        deposit.user,
        'deposit_approved',
        'ডিপোজিট অনুমোদিত',
        `আপনার ৳${deposit.amount} ডিপোজিট অনুমোদিত হয়েছে`,
        { amount: deposit.amount, transactionId: actionTransaction._id.toString() }
      );
      
      console.log('✅ [DEPOSIT APPROVAL] Notification created successfully:', {
        notificationId: notificationResult._id,
        userId: notificationResult.userId,
        type: notificationResult.type,
        pushSent: notificationResult.pushSent,
        pushError: notificationResult.pushError
      });
    } catch (notifError) {
      console.error('❌ [DEPOSIT APPROVAL] Failed to create notification:', {
        error: notifError.message,
        stack: notifError.stack,
        userId: deposit.user
      });
      // Don't fail the main operation if notification fails
    }

    // Send approval email to user (async, don't wait)
    sendDepositApprovalEmail(user.email, user.name, deposit.amount)
      .then(() => console.log('✉️ Deposit approval email sent to user'))
      .catch(emailError => console.error('❌ Failed to send deposit approval email:', emailError));

    // Award referral bonus if user was referred
    if (user.referredBy) {
      try {
        const referrer = await User.findById(user.referredBy);
        if (referrer) {
          const referralBonus = Math.round(deposit.amount * 0.05);

          console.log(`💰 [REFERRAL BONUS] Depositor: ${user._id}, Referrer: ${referrer._id}, Deposit: ৳${deposit.amount}, Bonus: ৳${referralBonus}`);

          if (referralBonus <= 0) {
            console.warn(`⚠️ [REFERRAL BONUS] Bonus is 0 for deposit ৳${deposit.amount} — skipping`);
          } else {
            const updateResult = await User.findByIdAndUpdate(
              referrer._id,
              { $inc: {
                referralIncome: referralBonus,  // track on referral page
                totalProfit: referralBonus,     // shows in balance card
                profitTotal: referralBonus,     // legacy field
                balance: referralBonus,
              }},
              { new: true }
            );

            if (updateResult) {
              console.log(`✅ [REFERRAL BONUS] ৳${referralBonus} credited. Referrer new balance: ৳${updateResult.balance}, referralIncome: ৳${updateResult.referralIncome}`);
            } else {
              console.error(`❌ [REFERRAL BONUS] findByIdAndUpdate returned null for referrer ${referrer._id}`);
            }

            // Create transaction for referral bonus
            await Transaction.create({
              user: referrer._id,
              type: 'referral_bonus',
              amount: referralBonus,
              description: `Referral bonus from ${user.name || user.phone || user.email}`,
              status: 'completed'
            });

            // Create notification for referral bonus
            await pushNotificationService.createAndSendNotification(
              referrer._id,
              'referral_bonus',
              'রেফারেল বোনাস',
              `${user.name || user.phone || 'একজন ব্যবহারকারী'} এর ডিপোজিট থেকে ৳${referralBonus} রেফারেল বোনাস পেয়েছেন`,
              { referralName: user.name || user.phone, amount: referralBonus }
            );

            // Send referral bonus email
            try {
              await sendReferralBonusEmail(
                referrer.email,
                referrer.name || referrer.phone,
                referralBonus,
                user.name || user.phone
              );
            } catch (emailError) {
              console.error('Failed to send referral bonus email:', emailError);
            }
          }
        } else {
          console.warn(`⚠️ [REFERRAL BONUS] Referrer not found for ID: ${user.referredBy}`);
        }
      } catch (referralError) {
        console.error('❌ [REFERRAL BONUS] Failed to process referral bonus:', referralError);
        // Don't fail the main operation if referral bonus fails
      }
    }

    res.json({ message: 'Deposit approved', deposit });
  } catch (error) {
    console.error('Approve deposit error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Reject deposit
router.patch('/deposits/:depositId/reject', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { reason } = req.body;
    const deposit = await Deposit.findById(req.params.depositId);
    
    if (!deposit) {
      return res.status(404).json({ message: 'Deposit not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (deposit.status !== 'pending') {
      return res.status(400).json({ 
        message: `Deposit already ${deposit.status}`,
        deposit 
      });
    }

    deposit.status = 'rejected';
    deposit.rejectionReason = reason;
    deposit.processedAt = new Date();
    deposit.screenshot = null; // Delete screenshot to save database space
    await deposit.save();

    // Create action transaction linked to submission transaction
    const actionTransaction = await transactionHistoryService.createActionTransaction(
      deposit.user,
      'deposit',
      'rejected',
      deposit.amount,
      deposit._id,
      deposit.submissionTransactionId,
      reason
    );

    // Link action transaction back to deposit
    deposit.actionTransactionId = actionTransaction._id;
    await deposit.save();

    // Clear pending deposit flag
    await requestValidationService.updatePendingFlag(deposit.user, 'deposit', false);

    // Log audit trail
    await auditLogger.logDepositReject(
      req.admin.username,
      req.admin.username,
      deposit._id,
      deposit.amount,
      reason,
      req
    );

    // Create notification for deposit rejection and send push notification
    try {
      console.log('📲 [DEPOSIT REJECTION] Starting notification creation for user:', deposit.user);
      console.log('📲 [DEPOSIT REJECTION] Notification details:', {
        userId: deposit.user,
        type: 'deposit_rejected',
        amount: deposit.amount,
        reason,
        transactionId: actionTransaction._id.toString()
      });
      
      const notificationResult = await pushNotificationService.createAndSendNotification(
        deposit.user,
        'deposit_rejected',
        'ডিপোজিট প্রত্যাখ্যাত',
        `আপনার ৳${deposit.amount} ডিপোজিট প্রত্যাখ্যাত হয়েছে। কারণ: ${reason}`,
        { amount: deposit.amount, reason, transactionId: actionTransaction._id.toString() }
      );
      
      console.log('✅ [DEPOSIT REJECTION] Notification created successfully:', {
        notificationId: notificationResult._id,
        userId: notificationResult.userId,
        type: notificationResult.type,
        pushSent: notificationResult.pushSent,
        pushError: notificationResult.pushError
      });
    } catch (notifError) {
      console.error('❌ [DEPOSIT REJECTION] Failed to create notification:', {
        error: notifError.message,
        stack: notifError.stack,
        userId: deposit.user
      });
      // Don't fail the main operation if notification fails
    }

    // Send rejection email to user (async, don't wait)
    User.findById(deposit.user)
      .then(user => {
        if (user) {
          return sendDepositRejectionEmail(user.email, user.name, deposit.amount, reason);
        }
      })
      .then(() => console.log('✉️ Deposit rejection email sent to user'))
      .catch(emailError => console.error('❌ Failed to send deposit rejection email:', emailError));

    res.json({ message: 'Deposit rejected', deposit });
  } catch (error) {
    console.error('Reject deposit error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get withdrawals
router.get('/withdrawals', adminAuth, async (req, res) => {
  try {
    const { 
      status, 
      page = 1, 
      pageSize = 20,
      search = '',
      method,
      startDate,
      endDate
    } = req.query;
    
    // Build query
    let query = {};
    
    // Status filter
    if (status) {
      query.status = status;
    }
    
    // Method filter
    if (method) {
      query.method = method;
    }
    
    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }
    
    // Search filter (by user name or email)
    if (search) {
      // First find users matching search
      const users = await User.find({
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } }
        ]
      }).select('_id').lean();
      
      const userIds = users.map(u => u._id);
      query.user = { $in: userIds };
    }
    
    // Manual pagination
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [data, totalCount] = await Promise.all([
      Withdraw.find(query)
        .populate('user', 'name phone email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      Withdraw.countDocuments(query)
    ]);
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get withdrawals error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve withdrawal
router.patch('/withdrawals/:withdrawalId/approve', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { idempotencyKey } = req.body;
    
    // Idempotency check
    if (idempotencyKey) {
      const { checkIdempotency } = await import('../middleware/idempotency.js');
      const existingResult = await checkIdempotency(idempotencyKey);
      if (existingResult) {
        return res.json({ 
          message: 'Withdrawal already approved', 
          withdrawal: await Withdraw.findById(existingResult),
          fromCache: true
        });
      }
    }
    
    const withdrawal = await Withdraw.findById(req.params.withdrawalId);
    if (!withdrawal) {
      return res.status(404).json({ message: 'Withdrawal not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (withdrawal.status !== 'pending') {
      return res.status(400).json({ 
        message: `Withdrawal already ${withdrawal.status}`,
        withdrawal 
      });
    }

    withdrawal.status = 'approved';
    withdrawal.processedAt = new Date();
    await withdrawal.save();

    // Update idempotency cache
    if (idempotencyKey) {
      const { updateIdempotencyCache } = await import('../middleware/idempotency.js');
      updateIdempotencyCache(idempotencyKey, withdrawal._id.toString());
    }

    // Create action transaction linked to submission transaction
    const actionTransaction = await transactionHistoryService.createActionTransaction(
      withdrawal.user,
      'withdrawal',
      'approved',
      withdrawal.amount,
      withdrawal._id,
      withdrawal.submissionTransactionId,
      null
    );

    // Link action transaction back to withdrawal
    withdrawal.actionTransactionId = actionTransaction._id;
    await withdrawal.save();

    // Clear pending withdrawal flag
    await requestValidationService.updatePendingFlag(withdrawal.user, 'withdrawal', false);

    // Log audit trail
    await auditLogger.logWithdrawalApprove(
      req.admin.username,
      req.admin.username,
      withdrawal._id,
      withdrawal.amount,
      req
    );

    // Create notification for withdrawal processing and send push notification
    try {
      console.log('📲 [WITHDRAWAL APPROVAL] Starting notification creation for user:', withdrawal.user);
      console.log('📲 [WITHDRAWAL APPROVAL] Notification details:', {
        userId: withdrawal.user,
        type: 'withdrawal_approved',
        amount: withdrawal.amount,
        transactionId: actionTransaction._id.toString()
      });
      
      const notificationResult = await pushNotificationService.createAndSendNotification(
        withdrawal.user,
        'withdrawal_approved',
        'উইথড্র অনুমোদিত',
        `আপনার ৳${withdrawal.amount} উইথড্র অনুমোদিত হয়েছে`,
        { 
          amount: withdrawal.amount, 
          transactionId: actionTransaction._id.toString(),
          withdrawalId: withdrawal._id.toString()
        }
      );
      
      console.log('✅ [WITHDRAWAL APPROVAL] Notification created successfully:', {
        notificationId: notificationResult._id,
        userId: notificationResult.userId,
        type: notificationResult.type,
        pushSent: notificationResult.pushSent,
        pushError: notificationResult.pushError
      });
    } catch (notifError) {
      console.error('❌ [WITHDRAWAL APPROVAL] Failed to create notification:', {
        error: notifError.message,
        stack: notifError.stack,
        userId: withdrawal.user
      });
      // Don't fail the main operation if notification fails
    }

    // Send approval email to user (async, don't wait)
    User.findById(withdrawal.user)
      .then(user => {
        if (user && user.email) {
          return sendWithdrawalApprovalEmail(user.email, user.name, withdrawal.amount, withdrawal.method);
        }
      })
      .then(() => console.log('✉️ Withdrawal approval email sent to user'))
      .catch(emailError => console.error('❌ Failed to send withdrawal approval email:', emailError));

    res.json({ message: 'Withdrawal approved', withdrawal });
  } catch (error) {
    console.error('Approve withdrawal error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Reject withdrawal
router.patch('/withdrawals/:withdrawalId/reject', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { reason, idempotencyKey } = req.body;
    
    // Idempotency check
    if (idempotencyKey) {
      const { checkIdempotency } = await import('../middleware/idempotency.js');
      const existingResult = await checkIdempotency(idempotencyKey);
      if (existingResult) {
        return res.json({ 
          message: 'Withdrawal already rejected', 
          withdrawal: await Withdraw.findById(existingResult),
          fromCache: true
        });
      }
    }
    
    const withdrawal = await Withdraw.findById(req.params.withdrawalId);
    
    if (!withdrawal) {
      return res.status(404).json({ message: 'Withdrawal not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (withdrawal.status !== 'pending') {
      return res.status(400).json({ 
        message: `Withdrawal already ${withdrawal.status}`,
        withdrawal 
      });
    }

    withdrawal.status = 'rejected';
    withdrawal.rejectionReason = reason;
    withdrawal.processedAt = new Date();
    await withdrawal.save();

    // Update idempotency cache
    if (idempotencyKey) {
      const { updateIdempotencyCache } = await import('../middleware/idempotency.js');
      updateIdempotencyCache(idempotencyKey, withdrawal._id.toString());
    }

    // Refund amount to user
    const user = await User.findById(withdrawal.user);
    if (withdrawal.type === 'profit') {
      user.totalProfit = (user.totalProfit || 0) + withdrawal.amount;
    } else {
      user.capital = (user.capital || 0) + withdrawal.amount;
    }
    user.balance = (user.balance || 0) + withdrawal.amount;
    await user.save();

    // Create action transaction linked to submission transaction
    const actionTransaction = await transactionHistoryService.createActionTransaction(
      withdrawal.user,
      'withdrawal',
      'rejected',
      withdrawal.amount,
      withdrawal._id,
      withdrawal.submissionTransactionId,
      reason
    );

    // Link action transaction back to withdrawal
    withdrawal.actionTransactionId = actionTransaction._id;
    await withdrawal.save();

    // Clear pending withdrawal flag
    await requestValidationService.updatePendingFlag(withdrawal.user, 'withdrawal', false);

    // Log audit trail
    await auditLogger.logWithdrawalReject(
      req.admin.username,
      req.admin.username,
      withdrawal._id,
      withdrawal.amount,
      reason,
      req
    );

    // Create notification for withdrawal rejection and send push notification
    try {
      console.log('📲 [WITHDRAWAL REJECTION] Starting notification creation for user:', withdrawal.user);
      console.log('📲 [WITHDRAWAL REJECTION] Notification details:', {
        userId: withdrawal.user,
        type: 'withdrawal_rejected',
        amount: withdrawal.amount,
        reason: reason || 'তথ্য সঠিক নয়',
        transactionId: actionTransaction._id.toString()
      });
      
      const notificationResult = await pushNotificationService.createAndSendNotification(
        withdrawal.user,
        'withdrawal_rejected',
        'উইথড্র প্রত্যাখ্যাত',
        `আপনার ৳${withdrawal.amount} উইথড্র প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'তথ্য সঠিক নয়'}`,
        { 
          amount: withdrawal.amount, 
          reason: reason || 'তথ্য সঠিক নয়',
          transactionId: actionTransaction._id.toString(),
          withdrawalId: withdrawal._id.toString()
        }
      );
      
      console.log('✅ [WITHDRAWAL REJECTION] Notification created successfully:', {
        notificationId: notificationResult._id,
        userId: notificationResult.userId,
        type: notificationResult.type,
        pushSent: notificationResult.pushSent,
        pushError: notificationResult.pushError
      });
    } catch (notifError) {
      console.error('❌ [WITHDRAWAL REJECTION] Failed to create notification:', {
        error: notifError.message,
        stack: notifError.stack,
        userId: withdrawal.user
      });
      // Don't fail the main operation if notification fails
    }

    // Send rejection email to user (async, don't wait)
    User.findById(withdrawal.user)
      .then(user => {
        if (user && user.email) {
          return sendWithdrawalRejectionEmail(user.email, user.name, withdrawal.amount, reason);
        }
      })
      .then(() => console.log('✉️ Withdrawal rejection email sent to user'))
      .catch(emailError => console.error('❌ Failed to send withdrawal rejection email:', emailError));

    res.json({ message: 'Withdrawal rejected', withdrawal });
  } catch (error) {
    console.error('Reject withdrawal error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get transactions (admin view)
router.get('/transactions', adminAuth, async (req, res) => {
  try {
    const { 
      page = 1, 
      pageSize = 20,
      search = '',
      type,
      startDate,
      endDate
    } = req.query;
    
    // Build query
    let query = {};
    
    // Type filter
    if (type) {
      query.type = type;
    }
    
    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }
    
    // Search filter (by user name or email)
    if (search) {
      // First find users matching search
      const users = await User.find({
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } }
        ]
      }).select('_id').lean();
      
      const userIds = users.map(u => u._id);
      query.user = { $in: userIds };
    }
    
    // Manual pagination
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [data, totalCount] = await Promise.all([
      Transaction.find(query)
        .populate('user', 'name phone email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      Transaction.countDocuments(query)
    ]);
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get verifications
router.get('/verifications', adminAuth, async (req, res) => {
  try {
    const { 
      status, 
      page = 1, 
      pageSize = 20,
      search = '',
      startDate,
      endDate
    } = req.query;
    
    // Build query
    let query = {};
    
    // Status filter
    if (status) {
      query.status = status;
    }
    
    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }
    
    // Search filter (by user name, email, or NID number)
    if (search) {
      // First find users matching search
      const users = await User.find({
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } }
        ]
      }).select('_id').lean();
      
      const userIds = users.map(u => u._id);
      
      query.$or = [
        { user: { $in: userIds } },
        { nidNumber: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Manual pagination
    const pageNum = parseInt(page);
    const pageSizeNum = parseInt(pageSize);
    const skip = (pageNum - 1) * pageSizeNum;
    
    const [data, totalCount] = await Promise.all([
      Verification.find(query)
        .populate('user', 'name phone email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(pageSizeNum)
        .lean(),
      Verification.countDocuments(query)
    ]);
    
    const totalPages = Math.ceil(totalCount / pageSizeNum);
    
    res.json({
      success: true,
      data,
      pagination: {
        page: pageNum,
        pageSize: pageSizeNum,
        totalCount,
        totalPages,
        hasNext: pageNum < totalPages,
        hasPrevious: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get verifications error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve verification
router.patch('/verifications/:verificationId/approve', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const verification = await Verification.findById(req.params.verificationId);
    if (!verification) {
      return res.status(404).json({ message: 'Verification not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (verification.status !== 'pending') {
      return res.status(400).json({ 
        message: `Verification already ${verification.status}`,
        verification 
      });
    }

    // Update user verification status AND name from KYC BEFORE updating verification
    const user = await User.findById(verification.user);
    if (user) {
      user.isVerified = true;
      user.name = verification.name; // Update name from KYC

      // ── KYC Completion Bonus: ৳180 added to balance as profit ──
      const KYC_BONUS = 180;
      if (!user.kycBonusGiven) {
        user.balance = (user.balance || 0) + KYC_BONUS;
        user.totalProfit = (user.totalProfit || 0) + KYC_BONUS;
        user.profitTotal = (user.profitTotal || 0) + KYC_BONUS;
        user.kycBonusGiven = true;
      }

      await user.save();
    }

    // Update verification status and remove images using findByIdAndUpdate to bypass validation
    const updatedVerification = await Verification.findByIdAndUpdate(
      req.params.verificationId,
      {
        $set: {
          status: 'approved',
          processedAt: new Date()
        },
        $unset: {
          nidFrontImage: '',
          nidBackImage: '',
          selfieImage: '',
          nidFront: '',
          nidBack: '',
          selfie: ''
        }
      },
      { new: true, runValidators: false }
    );

    // Log audit trail
    await auditLogger.logAction(
      'verification.approve',
      req.admin.username,
      req.admin.username,
      'Verification',
      verification._id,
      { before: { status: 'pending' }, after: { status: 'approved' } },
      { userName: verification.name, nidNumber: verification.nidNumber },
      req
    );

    // Create notification for KYC approval
    try {
      await pushNotificationService.createAndSendNotification(
        verification.user,
        'kyc_approved',
        'KYC অনুমোদিত 🎉',
        'আপনার KYC অনুমোদিত হয়েছে! ৳১৮০ বোনাস আপনার অ্যাকাউন্টে যোগ হয়েছে। এখন Withdraw করতে পারবেন।',
        {}
      );
    } catch (notifError) {
      console.error('Failed to create KYC approval notification:', notifError);
      // Don't fail the main operation if notification fails
    }

    // Send approval email to user (with ৳180 bonus mention)
    try {
      if (user && user.email) {
        await sendVerificationApprovalEmail(user.email, user.name);
        await sendKYCBonusEmail(user.email, user.name);
        console.log('Verification approval + KYC bonus email sent to user');
      }
    } catch (emailError) {
      console.error('Failed to send verification approval email:', emailError);
      // Don't fail the main operation if email fails
    }

    res.json({ message: 'Verification approved', verification: updatedVerification });
  } catch (error) {
    console.error('Approve verification error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Reject verification
router.patch('/verifications/:verificationId/reject', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { reason } = req.body;
    
    const verification = await Verification.findById(req.params.verificationId);
    if (!verification) {
      return res.status(404).json({ message: 'Verification not found' });
    }

    // IDEMPOTENCY CHECK: Prevent double-processing
    if (verification.status !== 'pending') {
      return res.status(400).json({ 
        message: `Verification already ${verification.status}`,
        verification 
      });
    }

    const updatedVerification = await Verification.findByIdAndUpdate(
      req.params.verificationId,
      { 
        $set: {
          status: 'rejected', 
          rejectionReason: reason,
          processedAt: new Date()
        },
        $unset: {
          // Delete images to save database space (3-6 MB per verification!)
          nidFrontImage: '',
          nidBackImage: '',
          selfieImage: '',
          nidFront: '',
          nidBack: '',
          selfie: ''
        }
      },
      { new: true, runValidators: false }
    );

    if (!updatedVerification) {
      return res.status(404).json({ message: 'Verification not found' });
    }

    // Log audit trail
    await auditLogger.logAction(
      'verification.reject',
      req.admin.username,
      req.admin.username,
      'Verification',
      verification._id,
      { before: { status: 'pending' }, after: { status: 'rejected' } },
      { userName: verification.name, nidNumber: verification.nidNumber, reason },
      req
    );

    // Create notification for KYC rejection
    try {
      await pushNotificationService.createAndSendNotification(
        updatedVerification.user,
        'kyc_rejected',
        'KYC প্রত্যাখ্যাত',
        `আপনার KYC ভেরিফিকেশন প্রত্যাখ্যাত হয়েছে। কারণ: ${reason || 'তথ্য সঠিক নয়'}। অনুগ্রহ করে সঠিক তথ্য দিয়ে পুনরায় জমা দিন।`,
        { reason }
      );
    } catch (notifError) {
      console.error('Failed to create KYC rejection notification:', notifError);
      // Don't fail the main operation if notification fails
    }

    // Send rejection email to user
    try {
      const user = await User.findById(updatedVerification.user);
      if (user) {
        await sendVerificationRejectionEmail(user.email, user.name, reason);
        console.log('Verification rejection email sent to user');
      }
    } catch (emailError) {
      console.error('Failed to send verification rejection email:', emailError);
      // Don't fail the main operation if email fails
    }

    res.json({ message: 'Verification rejected', verification: updatedVerification });
  } catch (error) {
    console.error('Reject verification error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get leaderboard
router.get('/leaderboard', adminAuth, async (req, res) => {
  try {
    const leaderboard = await User.find({ isActive: true })
      .sort({ capital: -1 })
      .limit(100)
      .select('name phone capital totalProfit balance referralCount');
    res.json({ leaderboard });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get settings
router.get('/settings', adminAuth, async (req, res) => {
  try {
    const Settings = (await import('../models/Settings.js')).default;
    let settings = await Settings.findOne();
    
    if (!settings) {
      settings = new Settings();
      await settings.save();
    }
    
    // Normalize withdrawalNumbers to new structure if needed
    const normalizedWithdrawalNumbers = {};
    for (const [method, value] of Object.entries(settings.withdrawalNumbers || {})) {
      if (typeof value === 'string') {
        // Old structure: convert string to object
        normalizedWithdrawalNumbers[method] = {
          number: value,
          mode: 'personal'
        };
      } else if (value && typeof value === 'object') {
        // New structure or needs cleaning
        normalizedWithdrawalNumbers[method] = {
          number: value.number || '',
          mode: value.mode || 'personal'
        };
      }
    }
    
    res.json({ 
      settings: {
        withdrawalNumbers: normalizedWithdrawalNumbers,
        profitRate: settings.profitRate,
        minDeposit: settings.minDeposit,
        maxDeposit: settings.maxDeposit,
        referralBonus: settings.referralBonus,
        capitalLockMonths: settings.capitalLockMonths,
        referralUrl: settings.referralUrl || '',
        referralQrImage: settings.referralQrImage || '',
        forceUpdateEnabled: settings.forceUpdateEnabled,
        minimumAppVersion: settings.minimumAppVersion,
        updateMessage: settings.updateMessage,
        appDownloadLink: settings.appDownloadLink
      }
    });
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update settings
router.put('/settings', adminAuth, async (req, res) => {
  try {
    const Settings = (await import('../models/Settings.js')).default;
    const auditLogger = (await import('../services/auditLogger.js')).default;
    
    let settings = await Settings.findOne();
    if (!settings) {
      settings = new Settings();
    }
    
    const currentSettings = { ...settings.toObject() };
    
    // Normalize and update withdrawalNumbers if provided
    if (req.body.withdrawalNumbers) {
      const normalizedWithdrawalNumbers = {};
      for (const [method, value] of Object.entries(req.body.withdrawalNumbers)) {
        if (typeof value === 'string') {
          // Old structure: convert string to object
          normalizedWithdrawalNumbers[method] = {
            number: value,
            mode: 'personal'
          };
        } else if (value && typeof value === 'object') {
          // New structure - ensure it's clean
          normalizedWithdrawalNumbers[method] = {
            number: value.number || '',
            mode: value.mode || 'personal'
          };
        }
      }
      settings.withdrawalNumbers = normalizedWithdrawalNumbers;
    }
    
    // Update other fields if provided
    if (req.body.profitRate !== undefined) settings.profitRate = req.body.profitRate;
    if (req.body.minDeposit !== undefined) settings.minDeposit = req.body.minDeposit;
    if (req.body.maxDeposit !== undefined) settings.maxDeposit = req.body.maxDeposit;
    if (req.body.referralBonus !== undefined) settings.referralBonus = req.body.referralBonus;
    if (req.body.capitalLockMonths !== undefined) settings.capitalLockMonths = req.body.capitalLockMonths;
    if (req.body.referralUrl !== undefined) settings.referralUrl = req.body.referralUrl;
    if (req.body.referralQrImage !== undefined) settings.referralQrImage = req.body.referralQrImage;
    
    // Update force update fields if provided
    if (req.body.forceUpdateEnabled !== undefined) settings.forceUpdateEnabled = req.body.forceUpdateEnabled;
    if (req.body.minimumAppVersion !== undefined) settings.minimumAppVersion = req.body.minimumAppVersion;
    if (req.body.updateMessage !== undefined) settings.updateMessage = req.body.updateMessage;
    if (req.body.appDownloadLink !== undefined) settings.appDownloadLink = req.body.appDownloadLink;
    
    await settings.save();
    
    // Log audit trail with before/after state
    await auditLogger.logSettingsUpdate(
      req.admin.username,
      req.admin.username,
      'system-settings',
      currentSettings,
      settings.toObject(),
      req
    );
    
    res.json({ 
      message: 'Settings updated successfully',
      settings: {
        withdrawalNumbers: settings.withdrawalNumbers,
        profitRate: settings.profitRate,
        minDeposit: settings.minDeposit,
        maxDeposit: settings.maxDeposit,
        referralBonus: settings.referralBonus,
        capitalLockMonths: settings.capitalLockMonths,
        referralUrl: settings.referralUrl,
        forceUpdateEnabled: settings.forceUpdateEnabled,
        minimumAppVersion: settings.minimumAppVersion,
        updateMessage: settings.updateMessage,
        appDownloadLink: settings.appDownloadLink
      }
    });
  } catch (error) {
    console.error('Update settings error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get announcements
router.get('/announcements', adminAuth, async (req, res) => {
  try {
    // In production, store in database
    res.json({ announcements: [] });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Create announcement
router.post('/announcements', adminAuth, async (req, res) => {
  try {
    const { title, message, type } = req.body;
    
    // Create system announcement notifications for all users
    try {
      const result = await createSystemAnnouncement(title, message);
      res.json({ 
        message: 'Announcement sent',
        sentTo: result.count
      });
    } catch (notifError) {
      console.error('Failed to create announcement notifications:', notifError);
      res.status(500).json({ message: 'Failed to send announcement' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete announcement
router.delete('/announcements/:id', adminAuth, async (req, res) => {
  try {
    // In production, delete from database
    res.json({ message: 'Announcement deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Agent Management Routes

// Get all agents (pending, approved, rejected)
router.get('/agents', adminAuth, async (req, res) => {
  try {
    const { status } = req.query;
    const query = status ? { approvalStatus: status } : {};
    
    const agents = await Agent.find(query)
      .select('-password')
      .sort({ createdAt: -1 });
    
    res.json({ agents });
  } catch (error) {
    console.error('Get agents error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get pending agent applications
router.get('/agents/pending', adminAuth, async (req, res) => {
  try {
    const agents = await Agent.find({ approvalStatus: 'pending' })
      .select('-password')
      .sort({ createdAt: -1 });
    
    res.json({ agents });
  } catch (error) {
    console.error('Get pending agents error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve agent
router.post('/agents/:id/approve', adminAuth, async (req, res) => {
  try {
    console.log('🔄 [AGENT APPROVE] Request received for agent ID:', req.params.id);
    console.log('🔄 [AGENT APPROVE] Admin user:', req.admin?.username);
    
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const agent = await Agent.findById(req.params.id);
    
    if (!agent) {
      console.error('❌ [AGENT APPROVE] Agent not found:', req.params.id);
      return res.status(404).json({ message: 'Agent not found' });
    }

    console.log('📋 [AGENT APPROVE] Agent found:', {
      id: agent._id,
      name: agent.name,
      email: agent.email,
      approvalStatus: agent.approvalStatus
    });

    if (agent.approvalStatus !== 'pending') {
      console.error('❌ [AGENT APPROVE] Agent is not pending:', agent.approvalStatus);
      return res.status(400).json({ message: 'Agent is not pending approval' });
    }

    agent.approvalStatus = 'approved';
    agent.isActive = true;
    agent.approvedAt = new Date();
    // In production, set approvedBy to admin user ID
    await agent.save();

    console.log('✅ [AGENT APPROVE] Agent approved successfully:', agent._id);

    // Log audit trail
    await auditLogger.logAction(
      'agent.approve',
      req.admin.username,
      req.admin.username,
      'Agent',
      agent._id,
      { before: { approvalStatus: 'pending' }, after: { approvalStatus: 'approved' } },
      { agentName: agent.name, agentEmail: agent.email, agentPhone: agent.phone },
      req
    );

    // Send agent welcome email
    try {
      const { sendAgentWelcomeEmail } = await import('../services/emailService.js');
      await sendAgentWelcomeEmail(agent.email, agent.name);
      console.log(`✅ Agent welcome email sent to: ${agent.email}`);
    } catch (emailError) {
      console.error('⚠️ Failed to send agent welcome email:', emailError);
      // Don't fail the approval if email fails
    }

    res.json({ message: 'Agent approved successfully', agent });
  } catch (error) {
    console.error('❌ [AGENT APPROVE] Error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Reject agent
router.post('/agents/:id/reject', adminAuth, async (req, res) => {
  try {
    console.log('🔄 [AGENT REJECT] Request received for agent ID:', req.params.id);
    console.log('🔄 [AGENT REJECT] Admin user:', req.admin?.username);
    console.log('🔄 [AGENT REJECT] Reason:', req.body.reason || 'No reason provided');
    
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { reason } = req.body;

    const agent = await Agent.findById(req.params.id);
    
    if (!agent) {
      console.error('❌ [AGENT REJECT] Agent not found:', req.params.id);
      return res.status(404).json({ message: 'Agent not found' });
    }

    console.log('📋 [AGENT REJECT] Agent found:', {
      id: agent._id,
      name: agent.name,
      email: agent.email,
      approvalStatus: agent.approvalStatus
    });

    if (agent.approvalStatus !== 'pending') {
      console.error('❌ [AGENT REJECT] Agent is not pending:', agent.approvalStatus);
      return res.status(400).json({ message: 'Agent is not pending approval' });
    }

    agent.approvalStatus = 'rejected';
    agent.rejectionReason = reason ? reason.trim() : 'No reason provided';
    agent.isActive = false;
    await agent.save();

    console.log('✅ [AGENT REJECT] Agent rejected successfully:', agent._id);

    // Log audit trail
    await auditLogger.logAction(
      'agent.reject',
      req.admin.username,
      req.admin.username,
      'Agent',
      agent._id,
      { before: { approvalStatus: 'pending' }, after: { approvalStatus: 'rejected' } },
      { agentName: agent.name, agentEmail: agent.email, agentPhone: agent.phone, reason: agent.rejectionReason },
      req
    );

    // TODO: Send rejection notification to agent via email/SMS

    res.json({ message: 'Agent rejected', agent });
  } catch (error) {
    console.error('❌ [AGENT REJECT] Error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Toggle agent active status
router.patch('/agents/:id/status', adminAuth, async (req, res) => {
  try {
    const { isActive } = req.body;
    
    const agent = await Agent.findById(req.params.id);
    
    if (!agent) {
      return res.status(404).json({ message: 'Agent not found' });
    }

    if (agent.approvalStatus !== 'approved') {
      return res.status(400).json({ message: 'Can only toggle status for approved agents' });
    }

    agent.isActive = isActive;
    await agent.save();

    res.json({ message: 'Agent status updated', agent });
  } catch (error) {
    console.error('Toggle agent status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get badge counts for sidebar notifications
router.get('/badge-counts', adminAuth, async (req, res) => {
  try {
    const Agent = (await import('../models/Agent.js')).default;
    
    const [pendingDeposits, pendingWithdrawals, pendingVerifications, pendingAgents] = await Promise.all([
      Deposit.countDocuments({ status: 'pending' }),
      Withdraw.countDocuments({ status: 'pending' }),
      Verification.countDocuments({ status: 'pending' }),
      Agent.countDocuments({ approvalStatus: 'pending' })
    ]);

    res.json({
      deposits: pendingDeposits,
      withdrawals: pendingWithdrawals,
      verifications: pendingVerifications,
      agents: pendingAgents
    });
  } catch (error) {
    console.error('Get badge counts error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Audit Log Routes

// Get audit logs
router.get('/audit-logs', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { 
      page = 1, 
      pageSize = 20,
      action,
      adminId,
      resourceType,
      resourceId,
      startDate,
      endDate
    } = req.query;
    
    const filters = {
      action,
      adminId,
      resourceType,
      resourceId,
      startDate,
      endDate
    };
    
    const pagination = {
      page: parseInt(page),
      pageSize: parseInt(pageSize)
    };
    
    const result = await auditLogger.queryLogs(filters, pagination);
    res.json(result);
  } catch (error) {
    console.error('Get audit logs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get audit log statistics
router.get('/audit-logs/stats', adminAuth, async (req, res) => {
  try {
    const auditLogger = (await import('../services/auditLogger.js')).default;
    const { startDate, endDate } = req.query;
    
    const stats = await auditLogger.getStats({ startDate, endDate });
    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Get audit stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create Fake Transaction History for User
router.post('/users/:userId/fake-transactions', adminAuth, async (req, res) => {
  try {
    const { userId } = req.params;
    const { deposits = [], withdrawals = [] } = req.body;

    // Validate user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Helper function to generate realistic transaction ID
    const generateTransactionId = () => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let result = '';
      for (let i = 0; i < 10; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    };

    const createdDeposits = [];
    const createdWithdrawals = [];

    // Create fake deposits
    for (const depositData of deposits) {
      const {
        amount,
        method = 'Bkash',
        transactionId,
        status = 'approved',
        createdAt,
        processedAt
      } = depositData;

      // Normalize payment method to match enum
      let normalizedMethod = method;
      const methodLower = method.toLowerCase();
      if (methodLower === 'bkash') normalizedMethod = 'Bkash';
      else if (methodLower === 'nagad') normalizedMethod = 'Nagad';
      else if (methodLower === 'rocket') normalizedMethod = 'Rocket';

      const deposit = await Deposit.create({
        userId: user._id,
        user: user._id,
        amount,
        method: normalizedMethod,
        transactionId: transactionId || generateTransactionId(),
        phoneNumber: user.phone || '01700000000',
        senderNumber: '01700000000',
        status,
        createdAt: createdAt ? new Date(createdAt) : new Date(),
        processedAt: processedAt ? new Date(processedAt) : (status !== 'pending' ? new Date() : null),
        updatedAt: processedAt ? new Date(processedAt) : new Date(),
      });

      createdDeposits.push(deposit);

      // Update user balance if approved
      if (status === 'approved') {
        user.balance += amount;
        user.totalDeposit += amount;
      }
    }

    // Create fake withdrawals
    for (const withdrawalData of withdrawals) {
      const {
        amount,
        type = 'profit',
        method = 'Bkash',
        accountNumber,
        status = 'approved',
        createdAt,
        processedAt
      } = withdrawalData;

      // Normalize payment method to match enum
      let normalizedMethod = method;
      const methodLower = method.toLowerCase();
      if (methodLower === 'bkash') normalizedMethod = 'Bkash';
      else if (methodLower === 'nagad') normalizedMethod = 'Nagad';
      else if (methodLower === 'rocket') normalizedMethod = 'Rocket';

      const withdrawal = await Withdraw.create({
        userId: user._id,
        user: user._id,
        amount,
        type,
        method: normalizedMethod,
        accountNumber: accountNumber || user.phone || '01700000000',
        status,
        createdAt: createdAt ? new Date(createdAt) : new Date(),
        processedAt: processedAt ? new Date(processedAt) : (status !== 'pending' ? new Date() : null),
        updatedAt: processedAt ? new Date(processedAt) : new Date(),
      });

      createdWithdrawals.push(withdrawal);

      // Update user balance if approved
      if (status === 'approved') {
        if (type === 'profit') {
          user.totalProfit = Math.max(0, (user.totalProfit || 0) - amount);
        }
        // Note: We don't deduct from balance for fake data
      }
    }

    // Save user with updated balances
    await user.save();

    res.json({
      message: 'Fake transaction history created successfully',
      deposits: createdDeposits.length,
      withdrawals: createdWithdrawals.length,
      data: {
        deposits: createdDeposits,
        withdrawals: createdWithdrawals
      }
    });
  } catch (error) {
    console.error('Create fake transactions error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ========================================
// ADMIN NOTIFICATION ROUTES
// ========================================

// Get all notifications for admin
router.get('/notifications', adminAuth, async (req, res) => {
  try {
    const Notification = (await import('../models/Notification.js')).default;
    // Admin sees all system notifications (no userId filter for admin)
    const notifications = await Notification.find({})
      .sort({ createdAt: -1 })
      .limit(100);
    res.json({ notifications });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ message: 'Failed to fetch notifications' });
  }
});

// Mark notification as read
router.put('/notifications/:id/read', adminAuth, async (req, res) => {
  try {
    const Notification = (await import('../models/Notification.js')).default;
    await Notification.findByIdAndUpdate(req.params.id, { read: true });
    res.json({ message: 'Marked as read' });
  } catch (error) {
    console.error('Mark notification as read error:', error);
    res.status(500).json({ message: 'Failed to mark as read' });
  }
});

// Mark all notifications as read
router.put('/notifications/read-all', adminAuth, async (req, res) => {
  try {
    const Notification = (await import('../models/Notification.js')).default;
    await Notification.updateMany(
      { read: false },
      { read: true }
    );
    res.json({ message: 'All marked as read' });
  } catch (error) {
    console.error('Mark all notifications as read error:', error);
    res.status(500).json({ message: 'Failed to mark all as read' });
  }
});

// Get unread count
router.get('/notifications/unread-count', adminAuth, async (req, res) => {
  try {
    const Notification = (await import('../models/Notification.js')).default;
    const count = await Notification.countDocuments({
      read: false
    });
    res.json({ count });
  } catch (error) {
    console.error('Get unread count error:', error);
    res.status(500).json({ message: 'Failed to get count' });
  }
});

// Register push token (legacy endpoint - kept for backward compatibility)
router.post('/push-token', adminAuth, async (req, res) => {
  try {
    const { token } = req.body;
    // Store admin push token (implement based on your admin storage)
    res.json({ message: 'Token registered' });
  } catch (error) {
    console.error('Register push token error:', error);
    res.status(500).json({ message: 'Failed to register token' });
  }
});

// Register admin push token for notifications
router.post('/register-push-token', adminAuth, async (req, res) => {
  try {
    const { Expo } = await import('expo-server-sdk');
    const Admin = (await import('../models/Admin.js')).default;
    const { pushToken } = req.body;

    // Validate push token format
    if (!pushToken || !Expo.isExpoPushToken(pushToken)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid push token format. Expected ExponentPushToken[...]'
      });
    }

    // Find admin by username from JWT token
    const admin = await Admin.findOne({ username: req.admin.username });
    if (!admin) {
      return res.status(404).json({
        success: false,
        error: 'Admin not found'
      });
    }

    // Add push token to admin's pushTokens array
    await admin.addPushToken(pushToken);

    console.log(`✅ Admin push token registered: ${req.admin.username}, token: ${pushToken.substring(0, 30)}...`);

    // Send welcome notification to verify token
    try {
      await pushNotificationService.sendToAdmins({
        title: 'স্বাগতম!',
        body: 'আপনার ডিভাইস সফলভাবে নোটিফিকেশনের জন্য নিবন্ধিত হয়েছে।',
        data: {
          type: 'welcome',
          timestamp: new Date().toISOString()
        }
      });
      console.log('✅ Welcome notification sent to admin');
    } catch (notifError) {
      console.error('⚠️ Failed to send welcome notification:', notifError);
      // Don't fail the registration if welcome notification fails
    }

    res.json({
      success: true,
      message: 'Push token registered successfully',
      welcomeNotificationSent: true
    });
  } catch (error) {
    console.error('Register admin push token error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: error.message
    });
  }
});

// Get all agent reports
router.get('/reports', adminAuth, async (req, res) => {
  try {
    const Report = (await import('../models/Report.js')).default;
    const { status, reportType, priority } = req.query;
    
    const filter = {};
    if (status) filter.status = status;
    if (reportType) filter.reportType = reportType;
    if (priority) filter.priority = priority;

    const reports = await Report.find(filter)
      .populate('agentId', 'name phone email')
      .populate('ticketId')
      .populate('userId', 'name phone')
      .sort({ createdAt: -1 })
      .limit(100);

    res.json({ reports });
  } catch (error) {
    console.error('Get reports error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Update report status
router.patch('/reports/:reportId/status', adminAuth, async (req, res) => {
  try {
    const Report = (await import('../models/Report.js')).default;
    const { status, adminResponse } = req.body;

    const validStatuses = ['pending', 'reviewing', 'resolved', 'closed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'অবৈধ স্ট্যাটাস' });
    }

    const report = await Report.findById(req.params.reportId);
    if (!report) {
      return res.status(404).json({ message: 'রিপোর্ট পাওয়া যায়নি' });
    }

    report.status = status;
    if (adminResponse) {
      report.adminResponse = adminResponse;
    }
    if (status === 'resolved' || status === 'closed') {
      report.resolvedAt = new Date();
    }

    await report.save();

    res.json({ message: 'স্ট্যাটাস আপডেট হয়েছে', report });
  } catch (error) {
    console.error('Update report status error:', error);
    res.status(500).json({ message: 'সার্ভার ত্রুটি' });
  }
});

// Set lastProfitDate to today (use after manually distributing profit to prevent double distribution)
router.post('/set-profit-date', adminAuth, async (req, res) => {
  try {
    const Settings = (await import('../models/Settings.js')).default;
    const todayBD = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString().slice(0, 10);
    await Settings.findOneAndUpdate({}, { lastProfitDate: todayBD, profitDistributionFailed: false }, { upsert: true });
    res.json({ success: true, message: `lastProfitDate set to ${todayBD}` });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Manual profit distribution trigger
router.post('/trigger-profit', adminAuth, async (req, res) => {
  try {
    const Settings = (await import('../models/Settings.js')).default;
    const settings = await Settings.findOne() || new Settings();

    const users = await User.find({
      $or: [
        { capital: { $gt: 0 } },
        { depositTotal: { $gt: 0 } }
      ]
    });

    let processed = 0;
    let totalDistributed = 0;
    const errors = [];

    for (const user of users) {
      try {
        const userCapital = user.capital || user.depositTotal || 0;
        if (userCapital > 0) {
          const dailyProfit = Math.floor((userCapital * 0.16) / 30);
          user.balance = (user.balance || 0) + dailyProfit;
          user.totalProfit = (user.totalProfit || 0) + dailyProfit;
          user.profitTotal = (user.profitTotal || 0) + dailyProfit;
          await user.save();
          totalDistributed += dailyProfit;
          processed++;
        }
      } catch (err) {
        errors.push(`${user.email || user.phone}: ${err.message}`);
      }
    }

    // Mark today as distributed so the auto-retry doesn't double-distribute
    const todayBD = new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString().slice(0, 10);
    settings.lastProfitDate = todayBD;
    settings.profitDistributionFailed = false;
    await settings.save();

    res.json({
      success: true,
      message: `Profit distributed to ${processed} users`,
      totalDistributed,
      errors
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ─── Trade Control — Admin override per user ─────────────────────────────────

// GET /api/admin/trade-control/:userId — get current trade control state
router.get('/trade-control/:userId', adminAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('name email phone tradeControl');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, tradeControl: user.tradeControl, user: { name: user.name, email: user.email, phone: user.phone } });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// POST /api/admin/trade-control/:userId — set admin override
// Body: { override: 'force_loss' | 'force_win' | null, trades: 0 }
// trades: 0 = permanent, N = apply for next N trades then auto-clear
router.post('/trade-control/:userId', adminAuth, async (req, res) => {
  try {
    const { override, trades = 0 } = req.body;
    const valid = ['force_loss', 'force_win', null];
    if (!valid.includes(override)) {
      return res.status(400).json({ success: false, message: 'override must be force_loss, force_win, or null' });
    }
    await User.findByIdAndUpdate(req.params.userId, {
      $set: {
        'tradeControl.adminOverride':  override,
        'tradeControl.overrideTrades': parseInt(trades) || 0,
      },
    });
    res.json({ success: true, message: `Trade override set to: ${override || 'auto (cleared)'}` });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// POST /api/admin/trade-control/:userId/reset-cycle — reset 12h cycle for a user
router.post('/trade-control/:userId/reset-cycle', adminAuth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.userId, {
      $set: {
        'tradeControl.houseTaken': 0,
        'tradeControl.userProfit': 0,
        'tradeControl.lastReset':  new Date(0), // force reset on next trade
      },
    });
    res.json({ success: true, message: '12h cycle reset' });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// ─── Trade Control — Admin override per user ─────────────────────────────────

// GET /api/admin/trade-control/:userId
router.get('/trade-control/:userId', adminAuth, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('name email phone tradeControl');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, tradeControl: user.tradeControl, user: { name: user.name, email: user.email, phone: user.phone } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/admin/trade-control/:userId — set admin override
router.post('/trade-control/:userId', adminAuth, async (req, res) => {
  try {
    const { override, trades = 0 } = req.body;
    if (!['force_loss', 'force_win', null].includes(override))
      return res.status(400).json({ success: false, message: 'Invalid override value' });
    await User.findByIdAndUpdate(req.params.userId, {
      $set: { 'tradeControl.adminOverride': override, 'tradeControl.overrideTrades': parseInt(trades) || 0 },
    });
    res.json({ success: true, message: `Override set: ${override || 'cleared'}` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// POST /api/admin/trade-control/:userId/reset-cycle
router.post('/trade-control/:userId/reset-cycle', adminAuth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.userId, {
      $set: { 'tradeControl.houseTaken': 0, 'tradeControl.userProfit': 0, 'tradeControl.lastReset': new Date(0) },
    });
    res.json({ success: true, message: '12h cycle reset' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// GET /api/admin/trade-live — all currently open trades with user info
router.get('/trade-live', adminAuth, async (req, res) => {
  try {
    const Trade = (await import('../models/Trade.js')).default;
    const trades = await Trade.find({ status: 'open' })
      .populate('user', 'name email phone')
      .sort({ openedAt: -1 })
      .lean();
    res.json({ success: true, trades, count: trades.length });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// In-memory candle schedule store
const _candleSchedule = []; // [{ from, to, direction, createdAt }]

// GET /api/admin/candle-schedule — get active schedule
router.get('/candle-schedule', adminAuth, (req, res) => {
  const now = Date.now();
  const active = _candleSchedule.filter(s => s.to > now);
  res.json({ success: true, schedule: active });
});

// POST /api/admin/candle-schedule — set a time window with forced direction
// Body: { from: "2026-06-27T06:43:00Z", to: "2026-06-27T06:44:00Z", direction: "up" | "down" }
router.post('/candle-schedule', adminAuth, (req, res) => {
  try {
    const { from, to, direction } = req.body;
    if (!['up', 'down'].includes(direction))
      return res.status(400).json({ success: false, message: 'direction must be up or down' });
    const fromMs = new Date(from).getTime();
    const toMs   = new Date(to).getTime();
    if (isNaN(fromMs) || isNaN(toMs) || fromMs >= toMs)
      return res.status(400).json({ success: false, message: 'Invalid time range' });
    _candleSchedule.push({ from: fromMs, to: toMs, direction, startPrice: null, createdAt: Date.now() });
    res.json({ success: true, message: `Candle scheduled: ${direction.toUpperCase()} from ${new Date(fromMs).toISOString()} to ${new Date(toMs).toISOString()}` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// DELETE /api/admin/candle-schedule — clear all schedules
router.delete('/candle-schedule', adminAuth, (req, res) => {
  _candleSchedule.length = 0;
  res.json({ success: true, message: 'All schedules cleared' });
});

// ─── Broadcast Notification to All Users ──────────────────────────────────────
router.post('/broadcast', adminAuth, async (req, res) => {
  try {
    const { title, body } = req.body;

    if (!title?.trim() || !body?.trim()) {
      return res.status(400).json({ message: 'Title and body are required' });
    }

    // Get all active users with email or push token
    const users = await User.find({ isActive: { $ne: false } })
      .select('_id name email pushToken')
      .lean();

    if (!users.length) {
      return res.status(400).json({ message: 'No users found' });
    }

    let notifCount = 0;
    let emailCount = 0;

    // 1. Send in-app notification to every user (saved to DB + push)
    const notifPromises = users.map(async (user) => {
      try {
        await pushNotificationService.createAndSendNotification(
          user._id,
          'admin_broadcast',
          title.trim(),
          body.trim(),
          { type: 'broadcast' }
        );
        notifCount++;
      } catch (_) {}
    });
    await Promise.allSettled(notifPromises);

    // 2. Send email to users who have an email address
    const { sendBroadcastEmail } = await import('../services/emailService.js');
    const emailUsers = users.filter((u) => u.email);
    const emailPromises = emailUsers.map(async (user) => {
      try {
        await sendBroadcastEmail(user.email, user.name, title.trim(), body.trim());
        emailCount++;
      } catch (_) {}
    });
    await Promise.allSettled(emailPromises);

    console.log(`📢 Broadcast sent: ${notifCount} notifications, ${emailCount} emails`);

    res.json({
      message: `Broadcast sent successfully`,
      count: notifCount,
      emailCount,
    });
  } catch (error) {
    console.error('Broadcast error:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Export schedule for use in price engine
export { _candleSchedule };

export default router;

// Support Tickets Routes for Admin — NOTE: uses mongoose already imported above

// Get all support tickets
router.get('/support/tickets', adminAuth, async (req, res) => {
  try {
    const SupportTicket = mongoose.model('SupportTicket');
    const { status } = req.query;
    
    const filter = status ? { status } : {};
    
    const tickets = await SupportTicket.find(filter)
      .populate('userId', 'name phone email')
      .sort({ lastMessageAt: -1 });

    // Get unread count and last message for each ticket
    const SupportMessage = mongoose.model('SupportMessage');
    const ticketsWithDetails = await Promise.all(
      tickets.map(async (ticket) => {
        const unreadCount = await SupportMessage.countDocuments({
          ticketId: ticket._id,
          sender: 'user',
          read: false
        });

        const lastMessage = await SupportMessage.findOne({ ticketId: ticket._id })
          .sort({ createdAt: -1 });

        return {
          _id: ticket._id,
          userId: ticket.userId,
          status: ticket.status,
          priority: ticket.priority,
          subject: ticket.subject,
          lastMessageAt: ticket.lastMessageAt,
          createdAt: ticket.createdAt,
          unreadCount,
          lastMessage: lastMessage?.message || 'No messages yet',
          lastMessageType: lastMessage?.messageType || 'text'
        };
      })
    );

    res.json({ tickets: ticketsWithDetails });
  } catch (error) {
    console.error('Get support tickets error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get messages for a specific ticket
router.get('/support/tickets/:ticketId/messages', adminAuth, async (req, res) => {
  try {
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');
    
    const ticket = await SupportTicket.findById(req.params.ticketId)
      .populate('userId', 'name phone email');

    if (!ticket) {
      return res.status(404).json({ message: 'Ticket not found' });
    }

    const messages = await SupportMessage.find({ ticketId: req.params.ticketId })
      .sort({ createdAt: 1 });

    // Mark user messages as read
    await SupportMessage.updateMany(
      { ticketId: req.params.ticketId, sender: 'user', read: false },
      { read: true, readAt: new Date() }
    );

    res.json({ ticket, messages });
  } catch (error) {
    console.error('Get ticket messages error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Send reply to ticket
router.post('/support/tickets/:ticketId/reply', adminAuth, async (req, res) => {
  try {
    const SupportTicket = mongoose.model('SupportTicket');
    const SupportMessage = mongoose.model('SupportMessage');
    const { message } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ message: 'Message cannot be empty' });
    }

    const ticket = await SupportTicket.findById(req.params.ticketId);
    if (!ticket) {
      return res.status(404).json({ message: 'Ticket not found' });
    }

    const newMessage = new SupportMessage({
      ticketId: req.params.ticketId,
      userId: ticket.userId,
      sender: 'admin',
      message: message.trim(),
      messageType: 'text',
      read: true
    });

    await newMessage.save();

    // Update ticket
    ticket.lastMessageAt = new Date();
    if (ticket.status === 'open') {
      ticket.status = 'in_progress';
    }
    await ticket.save();

    res.json({ message: 'Reply sent', data: newMessage });
  } catch (error) {
    console.error('Send reply error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});
